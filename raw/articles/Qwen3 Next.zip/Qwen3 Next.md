> Blog：[Qwen3-Next](https://qwen.ai/blog?id=4074cca80393150c248e508aa62983f9cb7d27cd\&from=research.latest-advancements-list)
>
> 模型仓库：[Qwen3-Next](https://huggingface.co/collections/Qwen/qwen3-next-68c25fd6838e585db8eeea9d)

&#x20;Qwen3 Next 包含两个模型：

* [Qwen/Qwen3-Next-80B-A3B-Instruct](https://huggingface.co/Qwen/Qwen3-Next-80B-A3B-Instruct)：非思维链的版本

* [Qwen/Qwen3-Next-80B-A3B-Thinking](https://huggingface.co/Qwen/Qwen3-Next-80B-A3B-Thinking)：思维链的版本

Qwen3-Next-80B-A3B 技术特点：

* **Hybrid Attention**：组合 **Gated DeltaNet** 与 **Gated Attention&#x20;**&#x66FF;代标准注意力，支持256K长上下文。

* **High-Sparsity Mixture-of-Experts (MoE)**：在 MoE 层实现极低的激活比例，在保持模型容量的同时大幅降低每个 token 的 FLOPs。

* **Stability Optimizations**：引入 **zero-centered** 与带权衰减的 **layernorm** 等技术，以及其他稳定性增强，以确保预训练与后训练阶段的鲁棒性。

* **Multi-Token Prediction (MTP)**：提升预训练阶段的模型性能并加速推理。

对比非Thinking模型，<span style="color: rgb(216,57,49); background-color: inherit">Qwen3-Next-80B-A3B-Instruct</span> 显著优于 Qwen3-<span style="color: rgb(216,57,49); background-color: inherit">30B</span>-A3B-Instruct-2507 和 Qwen3-<span style="color: rgb(216,57,49); background-color: inherit">32B</span>-Non-thinking，几乎与 Qwen3-<span style="color: rgb(216,57,49); background-color: inherit">235B</span>-A22B-Instruct-2507 相近的结果。

对比Thinking模型，<span style="color: rgb(216,57,49); background-color: inherit">Qwen3-Next-80B-A3B-Thinking</span> 超过 Qwen3-30B-A3B-Thinking-2507 和 Qwen3-32B-thinking，超过了闭源的模型 Gemini-2.5-Flash-Thinking，并在部分指标上接近了最新的旗舰模型 Qwen3-235B-A22B-Thinking-2507。

![](<images/Qwen3 Next-Qwen3-Next-80B-A3B-Instruct.001.jpeg>)

![](<images/Qwen3 Next-thinking_performance.jpeg>)



## 1. 模型结构

![](<images/Qwen3 Next-archtecture.png>)



### 1.1 **Hybrid Attention**

模型使用了两种混合的Attention：Gated DeltaNet + Gated Attention，并&#x4E14;**<span style="color: rgb(216,57,49); background-color: inherit">使用 3:1 的混合比例（即 75% 层使用 Gated DeltaNet，25% 层保留标准注意力）策略。</span>**

* **Gated Attention**

![](<images/Qwen3 Next-archtecture-1.png>)

Gated Attention受到的[ MiniMax-01](https://swfvqxo30ma.feishu.cn/wiki/OAlUwyURZi5KyEk8UhccVxpPnxx?from=from_copylink)的Linear Attention的启发，使用了门控单元，可以看到`q_proj`合并了两个MLP分别时`q projection`和`gated projection`：

```python
class Qwen3NextAttention(nn.Module):
    """Multi-headed attention from 'Attention Is All You Need' paper"""
    def __init__(self, config: Qwen3NextConfig, layer_idx: int):
        ...
        self.q_proj = nn.Linear(
            config.hidden_size, config.num_attention_heads * self.head_dim * 2, bias=config.attention_bias
        )
        self.k_proj = nn.Linear(
            config.hidden_size, config.num_key_value_heads * self.head_dim, bias=config.attention_bias
        )
        self.v_proj = nn.Linear(
            config.hidden_size, config.num_key_value_heads * self.head_dim, bias=config.attention_bias
        )
        self.o_proj = nn.Linear(
            config.num_attention_heads * self.head_dim, config.hidden_size, bias=config.attention_bias
        ...

    @deprecate_kwarg("past_key_value", new_name="past_key_values", version="4.58")
    def forward(
        self,
        hidden_states: torch.Tensor,
        ...
    ) -> tuple[torch.Tensor, Optional[torch.Tensor]]:
        input_shape = hidden_states.shape[:-1]
        hidden_shape = (*input_shape, -1, self.head_dim)

        query_states, gate = torch.chunk(
            self.q_proj(hidden_states).view(*input_shape, -1, self.head_dim * 2), 2, dim=-1
        )
        gate = gate.reshape(*input_shape, -1)
        ....
        attn_output = attn_output * torch.sigmoid(gate)

        attn_output = self.o_proj(attn_output)
        return attn_output, attn_weights
```

还有一个关键改进是 Partial RoPE：即<span style="color: rgb(216,57,49); background-color: inherit">仅对注意力头前 25% </span>的位置维度添加旋转位置编码，提高长度外推效果。



* **Gated DeltaNet**

![](<images/Qwen3 Next-archtecture-2.png>)

Gated DeltaNe&#x74;**&#x20;**&#x7528;门控（gate）与可学习指数衰减（decay）把历史信息写入一个递推状态，再用查询读出。这样把原本 $$O\left(T^2\right)$$ 的 Softmax Attention 换成 $$O(T \cdot d)$$ 的递推形式，核心递推（每个 value-head，每个时刻 $$t$$）可写成：

$$s_t=\lambda_t \odot s_{t-1}+\beta_t \odot\left(\Phi\left(k_t\right) \otimes v_t\right), \quad y_t=\Phi\left(q_t\right) \cdot s_t$$

其中 $$0<\lambda_t<1$$ 是遗忘因子（由 $$g_t \leq 0$$ 决定，$$\left.\lambda_t=e^{g_t}\right), \beta_t \in(0,1)$$ 是输入门，$$\Phi(\cdot)$$ 是对 $$q, k$$ 的特征映射／归一化。

核心gated\_delta\_rule代码：

```python
def torch_recurrent_gated_delta_rule(
    query, key, value, g, beta, initial_state, output_final_state, use_qk_l2norm_in_kernel=False
):
    initial_dtype = query.dtype
    if use_qk_l2norm_in_kernel:
        query = l2norm(query, dim=-1, eps=1e-6)
        key = l2norm(key, dim=-1, eps=1e-6)
    query, key, value, beta, g = [
        x.transpose(1, 2).contiguous().to(torch.float32) for x in (query, key, value, beta, g)
    ]

    batch_size, sequence_length, num_heads, k_head_dim = key.shape
    v_head_dim = value.shape[-1]
    scale = 1 / (query.shape[-1] ** 0.5)
    query = query * scale

    core_attn_out = torch.zeros(batch_size, sequence_length, num_heads, v_head_dim).to(value)
    last_recurrent_state = (
        torch.zeros(batch_size, sequence_length, k_head_dim, v_head_dim).to(value)
        if initial_state is None
        else initial_state.to(value)
    )

    for i in range(num_heads):
        q_t = query[:, :, i]
        k_t = key[:, :, i]
        v_t = value[:, :, i]
        g_t = g[:, :, i].exp().unsqueeze(-1).unsqueeze(-1)
        beta_t = beta[:, :, i].unsqueeze(-1)

        last_recurrent_state = last_recurrent_state * g_t
        kv_mem = (last_recurrent_state * k_t.unsqueeze(-1)).sum(dim=-2)
        delta = (v_t - kv_mem) * beta_t
        last_recurrent_state = last_recurrent_state + k_t.unsqueeze(-1) * delta.unsqueeze(-2)
        core_attn_out[:, :, i] = (last_recurrent_state * q_t.unsqueeze(-1)).sum(dim=-2)

    if not output_final_state:
        last_recurrent_state = None
    core_attn_out = core_attn_out.transpose(1, 2).contiguous().to(initial_dtype)
    return core_attn_out, last_recurrent_state
```



### 1.2 **High-Sparsity Mixture-of-Experts (MoE)**

相比Qwen3 MoE的128个总专家和8个路由专家0共享专家，Qwen3-Next使用512总专家10路由专家与1共享专家：

```python
class Qwen3NextSparseMoeBlock(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.num_experts = config.num_experts
        self.top_k = config.num_experts_per_tok
        self.norm_topk_prob = config.norm_topk_prob

        # gating
        self.gate = nn.Linear(config.hidden_size, config.num_experts, bias=False)
        self.experts = nn.ModuleList(
            [Qwen3NextMLP(config, intermediate_size=config.moe_intermediate_size) for _ in range(self.num_experts)]
        )

        self.shared_expert = Qwen3NextMLP(config, intermediate_size=config.shared_expert_intermediate_size)
        self.shared_expert_gate = torch.nn.Linear(config.hidden_size, 1, bias=False)
...
```



### 1.3 **Zero-Centered LayerNorm**

代码实现如下，之所以叫**Zero-Centered**，是因为`self.weight = nn.Parameter(torch.zeros(dim))`是进行0初始化的，这样一来，初始时就类似<span style="color: rgb(216,57,49); background-color: inherit">恒等映射（scale=1）</span>，即标准化，不会因为RMSNorm未减均值造成训练不稳定：

```python
class Qwen3NextRMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.zeros(dim))

    def _norm(self, x):
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)

    def forward(self, x):
        output = self._norm(x.float())
        # Llama does x.to(float16) * w whilst Qwen3Next is (x * w).to(float16)
        # See https://github.com/huggingface/transformers/pull/29402
        output = output * (1.0 + self.weight.float())
        return output.type_as(x)

    def extra_repr(self):
        return f"{tuple(self.weight.shape)}, eps={self.eps}"
```

对比[ 为什么最新的大模型普遍用RMSNorm？](https://swfvqxo30ma.feishu.cn/wiki/FyiMwG0BAiDT5Qk3Z0Ecs6CvnFb?from=from_copylink)中的LayerNorm实现：

```python
import torch
import torch.nn as nn

class RMSNorm(nn.Module):
    """Root-Mean-Square Normalization"""
    def __init__(self, features, eps: float = 1e-6):
        super(RMSNorm, self).__init__()
        self.gamma = nn.Parameter(torch.ones(features)) 
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        rms = x.pow(2).mean(dim=-1, keepdim=True).add(self.eps).sqrt()
        return self.gamma * x / rms

# Example usage
features = 768  
rms_norm = RMSNorm(features)

# Dummy input tensor (batch_size, seq_length, features)
x = torch.randn(10, 20, features)
normalized_x = rms_norm(x)
print(normalized_x)
```



### 1.4 Multi-Token Prediction

Multi-Token Prediction让模型在一次前向中，同时预测未来的 k 个 token，而不是只预测下一个 token。但是目前Multi-Token Prediction (MTP) 不在Hugging Face Transformers支持.



## 2. 预训练

Qwen3-Next 采用训练数据时的是 Qwen3（36T） 预训练语料的一个<span style="color: rgb(216,57,49); background-color: inherit">均匀采样子集</span>，仅包含 15T tokens。



## 3. 后训练

Qwen3-Next 采用 GSPO 进行 RL 训练，但是并未披露数据来源。
