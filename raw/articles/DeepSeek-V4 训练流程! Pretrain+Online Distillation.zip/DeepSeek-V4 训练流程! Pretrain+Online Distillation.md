> **前置推荐阅读：**
>
> * [ DeepSeek-V4 架构：技术报告/源码解析](https://my.feishu.cn/wiki/UsuawakRYiqacxkD9vxcKzylnoe?from=from_copylink)
>
> * [ DeepSeek V4 Infra：KV Cache/FLOPs 计算](https://my.feishu.cn/wiki/XqyWwkQXMixVDKk5NEtcUF8AnZb)
>
> * [ Muon 优化器](https://my.feishu.cn/wiki/Hcj2wGTJEiohTikkdEKc7H4Nnlb)
>
> * [ On-Policy Distillation 是什么？工作脉络梳理 ](https://my.feishu.cn/wiki/J5iOw7jRxi3tjSkNDSMcTJwmn5d?from=from_copylink)

> 论文：[《DeepSeek-V4: Towards Highly Efficient Million-Token Context Intelligence》](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/DeepSeek_V4.pdf)
>
> 模型仓库：[deepseek-ai/DeepSeek-V4](https://huggingface.co/collections/deepseek-ai/deepseek-v4)
>
> **<span style="color: rgb(216,57,49); background-color: inherit">包含知识点：</span>**
>
> * **预训练：**&#x46;lash/Pro 训练配置、超长上下文渐进训练、稀疏注意力两阶段引入（Sparse Attention 冷启动）、训练防 Spike：Anticipatory Routing 与 SwiGLU Clamping、Muon update RMS rescale
>
> * **后训练：**<span style="color: rgb(216,57,49); background-color: inherit">替换 Mixed RL 为 On-Policy Distillation（OPD），Specialist Training + OPD Merged</span>。Specialist Training 使用 self-Generative Reward Model，在 1M 上下文工程上优化了 Tool Call Schema、Interleaved Thinking 格式、Quick Instruction。

模型架构我们之前在 [ DeepSeek-V4 架构：技术报告/源码解析](https://my.feishu.cn/wiki/UsuawakRYiqacxkD9vxcKzylnoe?from=from_copylink) 已经完整解析，本节直接解析 V4 训练流程。

## 1. 预训练（Pre-Training）

V4 的 pre-training 相比 V3/V3.2 系列在数据、配置、稳定性三个维度均有改进，下面分别阐述。

### 1.1 训练数据

V4 的预训练数据 32T tokens，核心关注数据质量，在各个维度上的 tricks：

* **去模板/去机器生成数据**：用专门的 filtering 去掉批量自动生成的、模板化的网页内容，规避 [How to synthesize text data without model collapse](https://arxiv.org/abs/2412.14689) 所讨论的 model collapse 风险。

* **数学/代码保持训练数据高占比**：作为 reasoning 主力的两类数据在 V4 训练中仍然是主体。

* **<span style="color: rgb(216,57,49); background-color: inherit">加入 agentic 数据</span>**：目标是提升代码 agent 能力（对比传统reasoning数据进行补充），在 mid-training 而非 pre-training 阶段引入，避免污染早期 base model 表征。

* **多语言扩容**：提升长尾语言/文化的覆盖。

* **<span style="color: rgb(216,57,49); background-color: inherit">长文档专项</span>**：科学论文、技术报告、长文当作高优先级数据，提升 1M context 下的任务性能。

* **Sample-level attention masking**：和 V3 不同，V4 在 packing 多个 sample 到同一序列时，强制不同 sample 之间不可见（V3 是 cross-sample 可见）。这一改动减少 sample 之间的虚假关联，对长文档的语义独立性更友好。

Tokenizer/训练任务配置上的沿用：

* **Tokenizer配置：**&#x5728; V3 的 vocab（128K）基础上加入几个 special token。

* **FIM 策略配置：**&#x74;oken-splitting（支持 FIM 训练的 token 序列切分） 和 Fill-in-Middle (FIM，即`<PRE> Prefix <SUF> Suffix <MID> Middle <EOS>`补全任务，参考[ 大模型 FIM 预训练任务是什么？ ](https://my.feishu.cn/wiki/J4CQwxPruisyFXk599AcIdDInPh?from=from_copylink)) 沿用 V3 配置。

  > <span style="color: rgb(216,57,49); background-color: inherit">示例：FIM任务原文和对应分割：</span>
  >
  > ![](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2025-05-20 23.38.25.png>)
  >
  > <span style="color: rgb(216,57,49); background-color: inherit">其PSM格式为：</span>
  >
  > ![](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2025-05-20 23.38.05.png>)



### 1.2 模型与训练配置

两个不同量级模型 Flash/Pro 的<span style="color: inherit; background-color: rgba(183,237,177,0.8)">结构配置</span>/<span style="color: inherit; background-color: rgba(254,212,164,0.8)">训练配置</span>：

<table><colgroup><col width="244"><col width="272"><col width="282"></colgroup>
<thead>
<tr>
<th><strong>Hyperparameter</strong></th>
<th><strong>DeepSeek-V4-Flash</strong></th>
<th><strong>DeepSeek-V4-Pro</strong></th>
</tr>
</thead>
<tbody>
<tr>
<td><strong><span style="color: rgb(216,57,49); background-color: inherit">Parameter Total / Activated</span></strong></td>
<td>284B / 13B</td>
<td>1.6T / 49B</td>
</tr>
<tr>
<td><strong><span style="color: rgb(216,57,49); background-color: inherit">Layers/Hidden_Dim</span></strong></td>
<td>43/4096</td>
<td>61/7168</td>
</tr>
<tr>
<td><strong><span style="color: rgb(216,57,49); background-color: inherit">Experts/Activated Experts</span></strong></td>
<td>1 shared + 256 routed / 6 Activated</td>
<td>1 shared + 384 routed / 6 Activated</td>
</tr>
<tr>
<td><strong><span style="color: rgb(216,57,49); background-color: inherit">CSA attention top-k</span></strong></td>
<td>512</td>
<td>1024</td>
</tr>
<tr>
<td><strong><span style="color: rgb(216,57,49); background-color: inherit">训练语料 token 数</span></strong></td>
<td>32T</td>
<td>33T</td>
</tr>
<tr>
<td><strong><span style="color: rgb(216,57,49); background-color: inherit">最大 batch size（tokens）</span></strong></td>
<td>75.5M</td>
<td>94.4M</td>
</tr>
<tr>
<td><strong>Optimizer（AdamW）</strong></td>
<td>\beta_1=0.9, \beta_2=0.95, \varepsilon=10^{-20}, \text{weight\_decay}=0.1</td>
<td>\beta_1=0.9, \beta_2=0.95, \varepsilon=10^{-20}, \text{weight\_decay}=0.1</td>
</tr>
<tr>
<td><strong>Optimizer（Muon）</strong></td>
<td>\text{momentum} = 0.95, \text{weight\_decay}=0.1</td>
<td>\text{momentum} = 0.95, \text{weight\_decay}=0.1</td>
</tr>
<tr>
<td><strong>LR：Peak / End</strong></td>
<td>2.7 \times 10^{-4} / 2.7 \times 10^{-5}</td>
<td>2.0 \times 10^{-4} / 2.0 \times 10^{-5}</td>
</tr>
<tr>
<td><strong>LR Schedule</strong></td>
<td>linear warmup 2000 步 → peak LR 常数 → cosine 衰减到 end LR</td>
<td>linear warmup 2000 步 → peak LR 常数 → cosine 衰减到 end LR</td>
</tr>
<tr>
<td><strong><span style="color: rgb(216,57,49); background-color: inherit">Sequence length 渐进阶段</span></strong></td>
<td>4K → 16K → 64K → 1M</td>
<td>4K → 16K → 64K → 1M（4K 阶段更长）</td>
</tr>
<tr>
<td><strong><span style="color: rgb(216,57,49); background-color: inherit">Sparse attention 引入时机</span></strong></td>
<td>前 1T token 全 dense attention → 64K 时引入 lightning indexer warmup → 切到 sparse</td>
<td>相比Flash，dense 阶段更长，再走两阶段</td>
</tr>
<tr>
<td><strong>MTP loss weight</strong></td>
<td>0.3 → 0.1（衰减期）</td>
<td>0.3 → 0.1（衰减期）</td>
</tr>
<tr>
<td><strong>负载均衡：bias update / loss</strong></td>
<td>speed=0.001 / weight=0.0001</td>
<td>speed=0.001 / weight=0.0001</td>
</tr>
</tbody>
</table>

**<span style="color: rgb(216,57,49); background-color: inherit">关键设计点：</span>**

* **Muon update RMS rescale = 0.18**：目标是为了让 Muon 输出的更新幅度匹配 AdamW 的量级，从而能复用 AdamW 的 LR 经验值，具体来看下 V4 的 Muon 算法中相比标准 Muon 增加了 Rescale factor $$\gamma$$。

![V4 的 Muon 算法 ](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-29 02.04.45.png>)

![标准 Muon 算法](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-muon_algo.png>)

* **Sparse attention 两阶段切换**：<span style="color: rgb(216,57,49); background-color: inherit">直接从 0 开始训练 sparse attention 会让 indexer 崩溃</span>，所以先用 dense attention 训到 64K（V4-Flash 是 1T token，V4-Pro 更长），再做 lightning indexer 的短期 warmup（dense 推理但只更新 indexer 参数），最后才切到全 sparse。

* **Routing 节点数取消限制**：V3 限制每个 token 最多被路由到固定数量的节点，V4 取消了这个约束，配合 anticipatory routing 让并行策略更灵活。



### 1.3 训练稳定性 Trick

100B以上的 MoE 模型训练会出现 loss spike 现象（loss 值突然急剧上升出现尖峰）。

DeepSeek V4 认为 spike 总是和 MoE 层的 outlier 相关，routing 机制的不稳定会产生 outlier。使用 rollback（把训练状态退回到之前保存的某个 checkpoint）不能根本性解决这个问题，所以 V4 从两个方面进行 outlier 抑制：routing 抑制恶性反馈循环 + 直接抑制 outlier 异常值。

#### 技巧 1：Anticipatory Routing

**<span style="color: rgb(216,57,49); background-color: inherit">动机：标准同步 routing 存在的问题：</span>**

Routing 用当前参数 $$\theta_t$$ 算专家分配，但 expert 的更新也用 $$\theta_t$$，二者高度耦合。一旦某个 token 在某个 expert 上出现 outlier 激活，routing 的 score 和 expert 自身的 weight 会**同步**朝着该 outlier 方向调整，形成正反馈，最终触发 loss spike。

**<span style="color: rgb(216,57,49); background-color: inherit">实现：解耦 routing 和 backbone 的更新时刻。</span>**

在第 $$t$$ 步 feature 计算仍用 $$\theta_t$$，但 routing index 用历史参数 $$\theta_{t-\Delta t}$$ 计算，实操上为了避开两次加载 model parameter 的开销，在 step $$t-\Delta t$$ 提前 fetch 数据预计算（Anticipatory）并 cache 好后续 step $$t$$ 要用的 routing index。

工程上还做了两层优化：

* 流水线 overlap：把 anticipatory 计算和 EP 通信 overlap。

* **<span style="color: rgb(216,57,49); background-color: inherit">兜底触发：</span>**&#x9ED8;认走标准训练，只有检测到 loss spike 才触发短暂 rollback + 启用 anticipatory routing，无触发一段时间后再切回标准同步 Routing。

#### 技巧 2：SwiGLU Clamping

**<span style="color: rgb(216,57,49); background-color: inherit">动机：SwiGLU 数值范围爆炸</span>**

SwiGLU 的 linear 分量在长尾上偶尔会出现极大值，过大的激活是 routing outlier 的源头。

**<span style="color: rgb(216,57,49); background-color: inherit">实现：直接把 SwiGLU 的 linear 部分 clamp 到 [-10, 10]，gate 部分上限 10</span>**

[config.json](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/inference/config.json) 里 `swiglu_limit=10.0`**，**&#x5373;对 SwiGLU 的线性分量 clamp 到 $$[-10, 10]$$、gate 分量限制上界 10：

```python
if self.swiglu_limit > 0:
    up = torch.clamp(up, min=-self.swiglu_limit, max=self.swiglu_limit)
    gate = torch.clamp(gate, max=self.swiglu_limit)
```

> 参考 [OpenAI 2025 在 gpt-oss 里的实践](https://arxiv.org/abs/2508.10925) 也使用了SwiGLU Clamping，对最终性能没有可观测的损害。



### 1.4 预训练评估结果

![统一 internal framework、严格一致设置下的 base model 对比。](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-29 02.35.55.png>)

重点看 V4-Flash-Base（13B 激活） 对比 V3.2-Base（37B 激活），V4-Flash-Base（13B 激活）在绝大多数 benchmark 上反超 V3.2-Base（37B 激活），尤其世界知识和长上下文任务（V4-Pro-Base 再上一个台阶）：

* V4-Flash-Base 用 13B 激活就能在 MMLU、C-Eval、Simple-QA、HumanEval、LongBench-V2 等多个维度上超 V3.2-Base（37B 激活）。<span style="color: rgb(216,57,49); background-color: inherit">说明 V4 的架构和数据改进对参数效率有实际提升，不仅来自 token scaling。</span>

* 但 V4-Flash 在 BBH、GSM8K、MATH 这几项上略输 V3.2，说明<span style="color: rgb(216,57,49); background-color: inherit">纯 reasoning 上 13B 激活仍是劣势（需要后训练增强）。</span>

* V4-Pro-Base（49B 激活）比 V3.2-Base（37B 激活）只多 32% 激活参数，但在 Simple-QA verified 从 28.3 拉到 55.2、FACTS Parametric 从 27.1 拉到 62.6，即世界知识维度上有 2 倍以上的飞跃。<span style="color: rgb(216,57,49); background-color: inherit">这说明 V4 的多语言/长文档/科学论文数据收集对知识储备有质变。</span>



## 2. 后训练（Post-Training）

V4 的 post-training 关键改进：<span style="color: rgb(216,57,49); background-color: inherit">把 V3.2 时代的 mixed RL 阶段替换成两阶段 On-Policy Distillation（OPD）：</span>

* **Specialist Training：**&#x9488;对 math / code / agent / instruction following 等每个域，独立训练一个 expert 模型

* **On-Policy Distillation：**&#x5B66;生模型在自己采样的 trajectory，从 10+ teacher 全词表 logits 分布拟合 reverse KL

![](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-diagram.png>)

每个 specialist 训练仍然使用 SFT + RL（GRPO） 的传统路径，**<span style="color: rgb(216,57,49); background-color: inherit">关键改进在合并阶段：OPD（对比传统的 weight averaging、mixed RL）。</span>**

### 2.1 Specialist Training

#### Reasoning Efforts：三档思考预算

V4-Pro 和 V4-Flash 都支持 Non-think / Think High / Think Max 三档思考模式。实现方式是在 specialist training 阶段训练/储存三个不同 RL 配置的 checkpoint（不是通过开关/提示词实现的）：

| 模式         | 特点               | 典型场景              | 格式                                                           |
| ---------- | ---------------- | ----------------- | ------------------------------------------------------------ |
| Non-think  | 直接基于习惯/简单规则响应    | 日常任务、应急、低风险决策     | `</think>` summary                                           |
| Think High | 显式逻辑分析           | 复杂问题、规划、中风险决策     | `<think>` thinking `</think>` summary                        |
| Think Max  | 把 reasoning 推到极限 | 探索模型 reasoning 边界 | system prompt 强制思考指令 + `<think>` thinking `</think>` summary |

「Think Max」会在 system prompt 前面注&#x5165;**<span style="color: rgb(216,57,49); background-color: inherit">强制深思指令</span>**：

![](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-29 03.10.57.png>)

在 RL 配置上三档思考之间的区别：

* 每档对应不同的 length penalty 和 context window（论文没给训练时的具体数字）。

* Evaluation 时为对应推理预算，三档分别用 8K / 128K / 384K context window。

#### Generative Reward Model（GRM）

**<span style="color: rgb(216,57,49); background-color: inherit">动机：传统 scalar reward model 在 hard-to-verify 任务上遇到瓶颈</span>**

* 易验证任务（数学、代码）直接用 rule-based verifier 就足够。

* 难验证任务（写作、规划、推理）训练 scalar reward model（RLHF 路线）需要大量人类标注。

**<span style="color: rgb(216,57,49); background-color: inherit">实现：让 actor 自己当 reward model，joint optimization</span>**

DeepSeek V4 不再训独立的 scalar reward model，<span style="color: rgb(216,57,49); background-color: inherit">用 actor network 自己充当 Generative Reward Model（GRM）</span>：actor 一边生成 response，一边学评估自己的 trajectory，评估能力（judging proficiency）和生成能力（generative capability）联合优化。这一设计的好处：

* 模型 internal reasoning 直接进入评估流程，scoring 更鲁棒。

* 只需要小量 diverse human annotation，利用模型泛化能力。

* 统一了 actor / reward model 的角色，避免训练两个模型的资源开销和分布漂移。

#### Tool-Call Schema

V4 引入了一个新 tool-call schema，用 special token `<|DSML|>` 包裹 tool 调用，避开 JSON 输出的脆弱性：

![](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-29 03.11.05.png>)

实验显示 XML 比 JSON 在 tool-call 错误率上更低，escape 失败更少。

#### Interleaved Thinking

V3.2 在 agent 场景下保留 reasoning trace 跨 tool result，但 user message 一来就清空所有 reasoning。V4 利用 1M context 把策略改成两套：

* **Tool-Calling Scenarios**：所有 reasoning content 完整保留，跨 user message 边界也保留，让模型在 long-horizon agent 任务上有连贯的 chain-of-thought。

* **General Conversation**：保持 V3.2 策略，新 user message 一来就清空 reasoning，保持上下文紧凑。

下面是两类场景对应的 Thinking 管理示意。左图是 tool-calling 场景：每一轮的 thinking + tool call + tool result 都在 input 里持续累积；右图是普通对话场景：上一轮的 thinking 在新 user message 到来时被丢掉：

![Tool-Calling Scenarios：Thinking with tools](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-29 03.14.41.png>)

![General Conversation：Thinking without tools](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-29 03.14.47.png>)

#### Quick Instruction：避开辅助任务的额外 prefilling

Chatbot 场景下，模型经常要做一堆辅助任务（判断要不要触发 web search、识别用户意图、生成搜索 query 等）。传统做法是用一个独立的小模型，但小模型不能复用主模型的 KV cache，每次都要重新 prefilling。

V4 的实现：<span style="color: rgb(216,57,49); background-color: inherit">直接在主模型的输入序列后追加 special token 触发对应辅助任务</span>，复用已有 KV cache，把 TTFT（time to first token）压到最低：

![](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-29 03.13.16.png>)

### 2.2 On-Policy Distillation：把 10+ specialists 合成一个模型

推荐前置阅读：[ On-Policy Distillation 是什么？工作脉络梳理 ](https://my.feishu.cn/wiki/J5iOw7jRxi3tjSkNDSMcTJwmn5d?from=from_copylink)

#### 替换 Mixed RL 到 OPD

**<span style="color: rgb(216,57,49); background-color: inherit">动机：传统多专家融合方法存在的问题：</span>**

* **Weight averaging / Model soup**：直接平均参数，不同 specialist 之间的能力会相互稀释/矛盾。

* **Mixed RL**：用一个统一的 reward 函数同时优化所有 domain，容易 reward hacking 且不同 domain 互相干扰。

**<span style="color: rgb(216,57,49); background-color: inherit">实现：full-vocabulary On-Policy Distillation</span>**

V4 沿用了 [Thinking Machines](https://thinkingmachines.ai/blog/on-policy-distillation/) 的 OPD 框架，目标函数：

$$\mathcal{L}_{\mathrm{OPD}}(\theta) = \sum_{i=1}^N w_i \cdot D_{\mathrm{KL}}\left( \pi_\theta \,\Vert\, \pi_{E_i} \right)$$

* $$π_θ$$ 是 student，也就是最终统一模型。

* $$π_{E_i}$$ 是第 $$i$$ 个 domain expert（teacher）。

* $$w_i$$ 是分配给该 expert 的重要性权重。

* $$D_{KL}$$ 是 reverse KL（注意是 student 对 teacher 的 KL）。

* <span style="color: rgb(216,57,49); background-color: inherit">计算 reverse KL 时，trajectory 来自 student 自己采样，这就是「on-policy」的来源。</span>

> **<span style="color: rgb(216,57,49); background-color: inherit">两个关键点需要注意（在</span>[<span style="color: rgb(216,57,49); background-color: inherit"> On-Policy Distillation 是什么？工作脉络梳理 </span>](https://my.feishu.cn/wiki/J5iOw7jRxi3tjSkNDSMcTJwmn5d?from=from_copylink)<span style="color: rgb(216,57,49); background-color: inherit">有详细解析）：</span>**
>
> * **为什么用 reverse KL 而不是 forward KL？**
>
> 参考 [Thinking Machines 的 blog](https://thinkingmachines.ai/blog/on-policy-distillation/)：reverse KL 是 mode-seeking 的，**强制 student 收敛到 teacher 的某个具体行为模式**而非分散在多个次优模式上；同时 reverse KL 是 unhackable 的，因为 teacher 的低 KL 总对应 desired behavior 的高概率。
>
> ![Forward KL: Mean-Seeking Behaviour](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-13 02.14.40.png>)
>
> ![Reverse KL: Mode-Seeking Behaviour](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-13 02.14.57.png>)
>
> * **为什么 用 full-vocabulary KL 而非 token-level estimate？**
>
> Full-vocabulary 把 teacher 在每个位置上的整条 logit 分布都对齐过来，gradient estimate variance 显著降低、训练更稳定。代价是计算 / 显存压力大（尤其 V4 是 10+ teachers 场景）。详细参考[<span style="color: rgb(216,57,49); background-color: inherit"> On-Policy Distillation 是什么？工作脉络梳理 </span>](https://my.feishu.cn/wiki/J5iOw7jRxi3tjSkNDSMcTJwmn5d?from=from_copylink)。



#### OPD 工程实现

上面说了由于 10+ teacher 使用 full-vocabulary KL ，储存全 logit 显存压力大，因此 V4 的实现链路：

* **Teacher weight centralized storage：**&#x6240;有 teacher weight 卸到中心化分布式存储，按需 load + ZeRO-like sharding，缓解 I/O 和 DRAM 压力。

* **只 cache teacher 的 last-layer hidden state：**&#x53EA;缓存中央 buffer 里的 last-layer hidden state，训练时 retrieve 这些 hidden state，临时跑对应的 prediction head 重建 logits（类似MLA）。

* **Order training samples by teacher index：**&#x8C03;度上把同一 teacher 的样本聚到一起 dispatch，保证每个 distinct teacher head 在一个 mini-batch 内只 load 一次，任意时刻 device memory 最多一个 teacher head。

* **TileLang kernel 算 KL：**&#x73;tudent / teacher logits 之间的精确 KL divergence 由优化的 TileLang kernel 完成，加速计算并避开动态显存分配。

* **Background async I/O：**&#x6240;有参数 / hidden state 的加载和卸载在 critical path 之外异步完成，不阻塞 training compute。

**<span style="color: rgb(216,57,49); background-color: inherit">本质优化思路是用调度换显存：</span>**&#x74;eacher 多但每次用才加载 head 计算完整 logits，hidden state 比 logits 小两个数量级所以可以缓存，prediction head 即用即 load。



### 2.3 RL/OPD Infra

除了 OPD Scheduling，V4 在 post-training infra 还需要注意的 Infra 工程细节：

* **Rollout 集成 FP4（MXFP4）**：rollout 和所有 inference-only forward pass（包括 teacher 和 reference model）都直接用 FP4，降低 rollout 阶段的显存和 latency。

* **Preemptible & Fault-Tolerant Rollout**：每个 generation request 维护 token-level Write-Ahead Log，每生成一个 token 立刻 append。preemption 时 pause inference engine 保存 KV cache，resumption 时用 WAL + KV cache 继续解码生成。

* **Million-Token Context RL 拆分加载**：rollout data 被拆成 metadata + 重 per-token field，后者走 shared-memory loader 避免节点内重复、用完立刻释放。on-device mini-batch 数动态调节，平衡吞吐与 I/O。token 粒度 WAL 保证重启不 regeneration from scratch（否则有 length bias，短响应更容易存活让模型偏向短输出）。

* **DeepSeek Elastic Compute（DSec）**：DeepSeek Elastic Compute（DSec）是一套 Rust 写的沙箱平台（Function Call / Container / microVM / fullVM），底层用 [3FS](https://github.com/deepseek-ai/3FS) + EROFS layered storage，是 V4 agentic RL 训练能 scale 的核心基础设施。实现大规模管理 RL sandbox，每个 sandbox 留存 trajectory log，可以做确定性 replay和 fast-forwarding（preemption 后用 cached 结果加速恢复）。



## 3. 实验

DeepSeek V4 的 Evaluation 主要分两类：

* **标准 Benchmark：**&#x516C;开数据集

* **Real-world Tasks：**

  * <span style="color: rgb(216,57,49); background-color: inherit">中文写作 Chinese Writing：</span>覆盖功能性写作(报告、邮件、文案等)和创意写作(小说、散文、诗歌等)，主要对标 Gemini-3.1-Pro，从指令遵循和写作质量两个维度评估。

  * <span style="color: rgb(216,57,49); background-color: inherit">搜索 Search：</span>DeepSeek Chatbot 的联网问答能力,分为 RAG(非思考模式,一次性检索)和 Agentic Search(思考模式,多轮主动调用搜索工具)。评测涵盖客观问答(查事实、找实体)和主观问答(分析、对比、推荐、规划)。

  * <span style="color: rgb(216,57,49); background-color: inherit">白领任务 White-Collar Task：</span>模拟企业办公场景的 30 个复杂中文专业任务,跨 13 个行业,涵盖信息分析、文档生成和文档编辑三类。由人工盲评,从任务完成度、指令遵循、内容质量、排版美观四个维度对比 Claude Opus 4.6-Max。

  * <span style="color: rgb(216,57,49); background-color: inherit">代码智能体 Code Agent：</span>从 DeepSeek 内部研发工作中收集的 30 个编程任务,涵盖功能开发、bug 修复、重构、诊断，技术栈包括 PyTorch、CUDA、Rust、C++。在多轮工具调用环境下评测,对标 Claude 系列模型。

### 3.1 标准 Benchmark：V4-Pro-Max 与闭源 / 开源旗舰对比

下表是 V4-Pro-Max 与当前SoTA开源/闭源模型的对比：

![](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-30 01.18.15.png>)

* **<span style="color: rgb(216,57,49); background-color: inherit">Reasoning 维度 Coding 竞赛水平领先</span>**<span style="color: rgb(216,57,49); background-color: inherit">：</span>LiveCodeBench 与 Codeforces Rating、Apex Shortlist 均为 SOTA 水平。 论文提到 Codeforces leaderboard 上 V4-Pro-Max 排到人类选手第 23 位。

* **<span style="color: rgb(216,57,49); background-color: inherit">Agentic 任务落后</span>**：技术报告认为 Terminal Bench 的环境本身有问题，其次就是在 SWE Pro 上水平低于 Kimi K2.6 和 GLM 5.1。

* **数学能力接近 SOTA**：HMMT 2026 Feb 95.2，落后最佳的 GPT-5.4 xHigh（97.7）和 Opus-4.6 Max（96.2）但都在 2\~3 分之内，IMOAnswerBench 89.8 也接近 GPT-5.4 的 91.4。

* **知识维度落后闭源模型、优于开源模型**：SimpleQA-Verified 57.9 vs Gemini-3.1-Pro 75.6，差距明显。但相对 K2.6 Thinking（36.9）和 GLM-5.1 Thinking（38.1）这两个开源模型 V4-Pro-Max 仍然有很大优势。这意味着 V4 在开源里已经把 SimpleQA 拉到一个新台阶，但和闭源 frontier 仍有差距。

* **<span style="color: rgb(216,57,49); background-color: inherit">Long-Context 表现中等</span>**：MRCR 1M 上 V4-Pro-Max 83.5 落后 Opus-4.6 Max 的 92.9，但比 Gemini-3.1-Pro 的 76.3 高出约 7 分。<span style="color: rgb(216,57,49); background-color: inherit">说明虽然 DeepSeek V4 支持 1M 上下文，但是召回能力距离 SOTA 仍有距离。</span>

* **HLE w/ tools 表现不佳**：<span style="color: rgb(216,57,49); background-color: inherit"> </span>DeepSeek V4<span style="color: rgb(216,57,49); background-color: inherit"> </span>在「工具 + 长链推理」组合上 V4 仍有提升空间。



### 3.2 Reasoning Effort 的边际收益

DeepSeek V4 对三档思考预算（8K、128K、384K）进行消融实验，比对不同思考预算能带来多少提升：

![](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-30 01.32.18.png>)

* **Reasoning 任务对思考预算极度敏感：**&#x4E0E; [OpenAI o1 ](https://arxiv.org/abs/2412.16720)结论一致，即 reasoning 性能在很大程度上由 test-time compute 决定。HLE 从 Non-Think 到 High 直接从 7.7 涨到 34.5（4x），LiveCodeBench 从 56.8 到 89.8。

* **Knowledge 任务对思考预算不敏感**。MMLU-Pro Non-Think 已经 82.9，High 增加到 87.1，再到 Max 只到 87.5。这是因为 knowledge tasks 主要靠 parametric memory，思考预算影响有限。

* **High → Max 的边际收益小**。Codeforces 从 High 到 Max 是 2919 → 3206、HLE 是 34.5 → 37.7。Max 的代价是 384K context，边际收益逐步降低。

* **<span style="color: rgb(216,57,49); background-color: inherit">V4-Flash-Max 在 reasoning 任务上接近 V4-Pro-Max</span>**。LiveCodeBench 91.6 vs 93.5、Codeforces 3052 vs 3206、HLE 34.8 vs 37.7。这意味着对 reasoning 主导的任务，13B 激活的 Flash 配长 thinking 已经够用，主要差距来自于 knowledge 任务（SimpleQA、MMLU-Pro）上，这部分是参数容量决定的。



### 3.3 Long-Context：1M token 上的真实表现

V4 系列原生 1M context，但 1M 上的实际 retrieval / understanding 能力测评看 MRCR 8-needle 的曲线：

| **输入长度**  | V4-Pro-Max | V4-Flash-Max |
| --------- | ---------- | ------------ |
| **8K**    | 0.90       | 0.91         |
| **16K**   | 0.85       | 0.84         |
| **32K**   | **0.94**   | 0.87         |
| **64K**   | 0.90       | 0.85         |
| **128K**  | 0.92       | 0.87         |
| **256K**  | 0.82       | 0.76         |
| **512K**  | 0.66       | 0.60         |
| **1024K** | 0.59       | 0.49         |

![](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-30 01.47.01.png>)



**<span style="color: rgb(216,57,49); background-color: inherit">128K 以内 retrieval 表现很好</span>**<span style="color: rgb(216,57,49); background-color: inherit">（均在 0.85 以上），</span>**<span style="color: rgb(216,57,49); background-color: inherit">256K 开始可见衰减</span>**<span style="color: rgb(216,57,49); background-color: inherit">，</span>**<span style="color: rgb(216,57,49); background-color: inherit">1M 退化到约 0.59</span>**<span style="color: rgb(216,57,49); background-color: inherit">。</span>这和MRCR 1M 上 V4-Pro-Max 83.5 落后 Opus-4.6 Max 的 92.9 结论一致：V4 的 1M上下文远不是 perfect retrieval。。



### 3.4 Real-World Tasks：真实工作场景测评

为了解决"标准 benchmark 和真实使用差距"的问题，V4 在4个维度自建数据上测试真实场景的 pairwise 评测（win vs. lose）：

* <span style="color: rgb(216,57,49); background-color: inherit">中文写作 Chinese Writing：</span>覆盖功能性写作(报告、邮件、文案等)和创意写作(小说、散文、诗歌等)，主要对标 Gemini-3.1-Pro，从指令遵循和写作质量两个维度评估。

* <span style="color: rgb(216,57,49); background-color: inherit">搜索 Search：</span>DeepSeek Chatbot 的联网问答能力,分为 RAG(非思考模式,一次性检索)和 Agentic Search(思考模式,多轮主动调用搜索工具)。评测涵盖客观问答(查事实、找实体)和主观问答(分析、对比、推荐、规划)。

* <span style="color: rgb(216,57,49); background-color: inherit">白领任务 White-Collar Task：</span>模拟企业办公场景的 30 个复杂中文专业任务,跨 13 个行业,涵盖信息分析、文档生成和文档编辑三类。由人工盲评,从任务完成度、指令遵循、内容质量、排版美观四个维度对比 Claude Opus 4.6-Max。

* <span style="color: rgb(216,57,49); background-color: inherit">代码智能体 Code Agent：</span>从 DeepSeek 内部研发工作中收集的 30 个编程任务,涵盖功能开发、bug 修复、重构、诊断，技术栈包括 PyTorch、CUDA、Rust、C++。在多轮工具调用环境下评测,对标 Claude 系列模型。

#### 中文写作 <span style="color: rgb(216,57,49); background-color: inherit">Chinese Writing</span>

* **功能写作**（Functional writing）：V4-Pro vs Gemini-3.1-Pro，**胜率 62.7% vs 34.1%**。论文给的解释是 Gemini 偶尔会用自己的 stylistic preference 覆盖用户显式要求，V4 在 instruction-following 上指令遵循更好。

* **创意写作**（Creative writing）：V4-Pro 在 instruction following 上 60.0% 胜率，writing quality 上 77.5% 胜率。但在「最具挑战的 prompt」的多约束 / 多轮场景，**Claude Opus 4.5 的胜率 52.0% vs V4-Pro 的 45.9%**，仍是 Claude 能力更强。

#### 搜索 <span style="color: rgb(216,57,49); background-color: inherit">Search</span>

DeepSeek 的 web/app 上 non-think 用 RAG，think 用 agentic search。

* **RAG 模式**（V4-Pro vs V3.2）：内部综合评估 V4 win 28.1%、V3.2 win 10.4%、tie 61.5%。<span style="color: rgb(216,57,49); background-color: inherit">V4 在 single-value search 和 planning &amp; strategy 上提升最大，</span>comparison 和 recommendation 类任务上 V3.2 仍有竞争力。

  ![Comparative Evaluation of DeepSeek-V4-Pro and DeepSeek-V3.2 on Search Q\&A Tasks.](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-30 02.02.22.png>)

* **Agentic Search vs RAG**：agentic search 总胜率 61.7%、RAG 18.3%、tie 20.0%，agentic search 全方位领先。代价上 agentic 平均 16.2 个 tool call、prefill 13649 tokens、output 1526 tokens；RAG 是 prefill 10453 tokens、output 1308 tokens。<span style="color: rgb(216,57,49); background-color: inherit">Agentic 成本略高但效果显著好。</span>

  ![Agentic Search vs. Retrieval Augmented Search for DeepSeek-V4-Pro.](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-30 02.03.08.png>)

#### 中文白领任务 <span style="color: rgb(216,57,49); background-color: inherit">White-Collar Task</span>

V4-Pro-Max vs Opus-4.6-Max，跨 13 个行业、30 个复杂中文专业（公司）任务：

* 总体胜率：53% win / 10% tie / 37% lose。

* 分项：分析 55%、生成 52%、编辑 47%。

* 分维度评分：Task Completion 98.32 vs 96.68（V4 略优）、Content Quality 83.32 vs 78.00（V4 优）、Instruction Following 87.78 vs 88.76（V4 略输）、Formatting Aesthetics 76.68 vs 72.68（V4 优）、Overall 86.52 vs 84.06（V4 优）。

<span style="color: rgb(216,57,49); background-color: inherit">V4 的弱项在 Instruction Following 偶尔会忽略具体 formatting 约束和长文本压缩成精炼摘要的能力，PPT 类视觉设计也仍有进步空间。</span>

#### 代码智能体 <span style="color: rgb(216,57,49); background-color: inherit"> Code Agent</span>

DeepSeek 自己用 \~200 个真实内部研发任务做 benchmark，30 个用作 evaluation set：

![](<images/DeepSeek-V4 训练流程! Pretrain+Online Distillation-截屏2026-04-30 01.57.12.png>)

**V4-Pro-Max 67% 显著超过 Sonnet 4.5（47%）、接近 Opus 4.5（70%）**，<span style="color: rgb(216,57,49); background-color: inherit">但仍然落后 Opus 4.6 Thinking。</span>

有个有意思的，DeepSeek 内部对 85 个开发者做了调研：**52% 完全愿意把 V4-Pro 作为日常代码主力，39% 倾向于愿意，不到 9% 说不**。<span style="color: rgb(216,57,49); background-color: inherit">开发者普遍反馈 V4 在大多数任务上结果令人满意，但在 trivial mistakes、模糊 prompt 误解、occasional over-thinking 上仍有问题。</span>
