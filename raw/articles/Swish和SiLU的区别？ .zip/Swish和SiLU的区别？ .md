> SiLU 作为<span style="color: rgb(216,57,49); background-color: inherit">现代大语言模型</span>架构（参考[ 现代大语言模型架构导论](https://swfvqxo30ma.feishu.cn/wiki/P7UPw5xwCikBvEkJCVac1Xw8nB0?from=from_copylink)）最常用的激活函数，常常在一些<span style="color: rgb(216,57,49); background-color: inherit">论文和代码</span>中和 Swish激活函数同时出现。本期来解析Swish和SiLU的区别。
>
> 总结Swish和SiLU的区别：
>
> * **<span style="color: rgb(216,57,49); background-color: inherit">SiLU 形式上是</span>$$\beta$$<span style="color: rgb(216,57,49); background-color: inherit"> 值为 1 的 Swish 激活函数，Swish包含了SiLU。</span>**
>
> * [transformers库](https://github.com/huggingface/transformers/blob/1bc75db9bdb54c3fe1042c298690cf37132fe2bc/src/transformers/activations.py#L93)中的Swish和SiLU是同义的，都是SiLU实现，但是SiLU可以支持内核加速，Swish为一般pytorch实现。

## 1. Swish

Swish是一种Google Brain通过[自动搜索技术](https://arxiv.org/pdf/1710.05941)发现的激活函数（参考[论文](https://arxiv.org/pdf/1710.05941)），其定义为：

$$f(x)=x \cdot \sigma(\beta x)$$

其中 $$\sigma(\cdot)$$ 是sigmoid函数，$$\beta$$ 可以是固定参数（如 $$\beta=1$$ ）或可训练参数。

其核心包括：

1. **<span style="color: rgb(216,57,49); background-color: inherit">平滑性与非单调性</span>**

* Swish是非单调的函数，与ReLU的硬截断特性 ($$x<0$$ 时输出截断为 $$0$$)不同，Swish在 $$x<0$$ 区域存在非单调的＂凸起＂（bump），能够保留负值信息。

![](<images/Swish和SiLU的区别？ -截屏2025-10-04 13.02.06.png>)

并且，Swish是平滑函数，并且导数包含sigmoid函数的平滑过渡：

$$\begin{aligned}
f^{\prime}(x) & =\sigma(\beta x)+\beta x \cdot \sigma(\beta x)(1-\sigma(\beta x)) \\
& =\sigma(\beta x)+\beta x \cdot \sigma(\beta x)-\beta x \cdot \sigma(\beta x)^2 \\
& =\beta x \cdot \sigma(x)+\sigma(\beta x)(1-\beta x \cdot \sigma(\beta x)) \\
& =\beta f(x)+\sigma(\beta x)(1-\beta f(x))
\end{aligned}$$

这种特性避免了ReLU在 $$x=0$$ 处的梯度不连续问题。

当 $$\beta=1$$时，其梯度在 $$x<1.25$$ 时小于 1 ，但实验表明这并未影响深层网络的优化能力，说明现代模型架构（残差连接）降低了对梯度保持特性的依赖。

* **<span style="color: rgb(216,57,49); background-color: inherit">参数灵活性</span>**

- 训练后的 $$\beta$$ 值分布在 0-1.5 之间，峰值接近 1 ，表明模型能有效利用可训练 $$\beta$$ 的灵活性。

- 在实际使用中，一般直接指定$$\beta$$ 值，如之后要介绍的 SiLU 激活函数，则直接将$$\beta$$ 值设为 1。

![](<images/Swish和SiLU的区别？ -截屏2025-10-04 13.17.07.png>)

Swish通过结合平滑性、非单调性和参数可调性，在多种任务中表现出<span style="color: rgb(216,57,49); background-color: inherit">优于ReLU的泛化能力</span>，且实现简单，成为替代ReLU的有效选择。



## 2. SiLU

SiLU（Sigmoid-weighted Linear Unit）最早在[论文](https://arxiv.org/pdf/1702.03118)中是一种用于强化学习中的激活函数，其数学表达式为：

$$f(x)=x \cdot \sigma(x)$$

其中 $$\sigma(\cdot)$$ 是sigmoid函数，**<span style="color: rgb(216,57,49); background-color: inherit">SiLU 形式上是</span>$$\beta$$<span style="color: rgb(216,57,49); background-color: inherit"> 值为 1 的 Swish 激活函数。</span>**

其特性包括：

1. 作为特殊的Swish函数，SiLU保留了Swish&#x7684;**<span style="color: rgb(216,57,49); background-color: inherit">平滑性与非单调性</span>**，SiLU作为在 $$z_k \approx-1.28$$ 处存在全局最小值（约 -0.28 ），起到隐式正则化作用。

2. **<span style="color: rgb(216,57,49); background-color: inherit">近似 ReLU：</span>**

当输入 $$x$$ 的绝对值较大时，SiLU 的激活值趋近于 ReLU（负输入趋近于 0，正输入趋近于线性）。

![](<images/Swish和SiLU的区别？ -截屏2025-10-04 13.26.40.png>)

3. **<span style="color: rgb(216,57,49); background-color: inherit">自稳定性质</span>**：在[论文](https://arxiv.org/pdf/1702.03118)中的实验表明，SiLU 在训练中能稳定权重更新，避免梯度爆炸。



## 3. Transformers 中的实现

[transformers库](https://github.com/huggingface/transformers/blob/1bc75db9bdb54c3fe1042c298690cf37132fe2bc/src/transformers/activations.py#L93)中的激活函数实现，silu和swish都是映射到silu：

```sql
ACT2CLS = {
    ...
    "silu": SiLUActivation,
    "swish": nn.SiLU,
    ...
}
```

但是`SiLUActivation` 被 `@use_kernel_forward_from_hub("SiLU")` 装饰：如果“内核 Hub”里存在名为 `"SiLU"` 的加速实现（比如 Triton/CUDA/FP8/融合算子），就把 `forward` 动态替换为该内核；否则回退到 `torch._C.`*`nn.silu`*：

```python
@use_kernel_forward_from_hub("SiLU")
class SiLUActivation(nn.Module):
    """
    See Gaussian Error Linear Units (Hendrycks et al., https://arxiv.org/abs/1606.08415) where the SiLU (Sigmoid Linear
    Unit) was originally introduced and coined, and see Sigmoid-Weighted Linear Units for Neural Network Function
    Approximation in Reinforcement Learning (Elfwing et al., https://arxiv.org/abs/1702.03118) and Swish: a Self-Gated
    Activation Function (Ramachandran et al., https://arxiv.org/abs/1710.05941v1) where the SiLU was experimented with
    later.
    """

    def forward(self, input: Tensor) -> Tensor:
        return nn.functional.silu(input)
```

swish走的是nn.SiLU的实现，本质上也是映射回`nn.functional.silu`，即回退到 `torch._C.`*`nn.silu`* ：

```python
class SiLU(Module):
    r"""Applies the Sigmoid Linear Unit (SiLU) function, element-wise.

    The SiLU function is also known as the swish function.

    .. math::
        \text{silu}(x) = x * \sigma(x), \text{where } \sigma(x) \text{ is the logistic sigmoid.}

    .. note::
        See `Gaussian Error Linear Units (GELUs) <https://arxiv.org/abs/1606.08415>`_
        where the SiLU (Sigmoid Linear Unit) was originally coined, and see
        `Sigmoid-Weighted Linear Units for Neural Network Function Approximation
        in Reinforcement Learning <https://arxiv.org/abs/1702.03118>`_ and `Swish:
        a Self-Gated Activation Function <https://arxiv.org/abs/1710.05941v1>`_
        where the SiLU was experimented with later.

    Shape:
        - Input: :math:`(*)`, where :math:`*` means any number of dimensions.
        - Output: :math:`(*)`, same shape as the input.

    .. image:: ../scripts/activation_images/SiLU.png

    Examples::

        >>> m = nn.SiLU()
        >>> input = torch.randn(2)
        >>> output = m(input)
    """

    __constants__ = ["inplace"]
    inplace: bool

    def __init__(self, inplace: bool = False):
        super().__init__()
        self.inplace = inplace

    def forward(self, input: Tensor) -> Tensor:
        return F.silu(input, inplace=self.inplace)

    def extra_repr(self) -> str:
        inplace_str = "inplace=True" if self.inplace else ""
        return inplace_str
```
