> **论文**：[《DeepSeek-V4: Towards Highly Efficient Million-Token Context Intelligence》](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/DeepSeek_V4.pdf)
>
> **模型仓库**：[deepseek-ai/DeepSeek-V4-Pro](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro)、[deepseek-ai/DeepSeek-V4-Flash](https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash)
>
> **模型代码**：[DeepSeek-V4-Pro](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/tree/main/inference)、[DeepSeek-V4-Flash](https://huggingface.co/deepseek-ai/DeepSeek-V4-Flash)

> **推荐阅读：**
>
> 🌟🌟🌟🌟🌟 [ Muon 优化器](https://my.feishu.cn/wiki/Hcj2wGTJEiohTikkdEKc7H4Nnlb)
>
> 🌟🌟🌟🌟🌟 [ mHC：Manifold-Constrained Hyper-Connections](https://my.feishu.cn/wiki/WsaawrdO3ifrmTk3ab4cSgjBnRb)
>
> 🌟🌟🌟🌟 [ Residuals 工作对比：mHC/AttenRes/MoDA ](https://my.feishu.cn/wiki/FUu9w6i0siOzowkRSTPcTz4Nn6d?from=from_parent_docx)
>
> 🌟🌟 [ Engram ](https://my.feishu.cn/wiki/JwXTw0oUeimyoBk2QIgcSfBfn9g)
>
> 🌟🌟 [ DualPath](https://my.feishu.cn/wiki/Y19YwzlUPi3vX5k9lRycm8cKnAb)

> **DeepSeek-V4 架构核心改进：**
>
> * **<span style="color: rgb(216,57,49); background-color: inherit">混合稀疏注意力</span>**<span style="color: rgb(216,57,49); background-color: inherit">：</span>CSA（Compressed Sparse Attention）+ HCA（Heavily Compressed Attention）交错分布（除了前两层连续HCA）。CSA 压缩率设置为 4 并且使用Lightning Indexer 做 top-K 稀疏 KV 选择。HCA 设置高压缩率128、不做KV稀疏直接Dense MQA。<span style="color: rgb(216,57,49); background-color: inherit">这是DS V4 实现 1M 上下文下低 FLOPs / KV cache 的核心技术。</span>
>
> * **<span style="color: rgb(216,57,49); background-color: inherit">mHC 残差</span>**<span style="color: rgb(216,57,49); background-color: inherit">：</span>把 Hyper-Connections 的残差矩阵 $$B_l$$ 约束到双重随机矩阵流形（Birkhoff polytope），相比原版 Residual Connection、Hyper-Connections，解决了表达能力受限、数值不稳定的问题。
>
> * **<span style="color: rgb(216,57,49); background-color: inherit">MoE 侧</span> <span style="color: rgb(216,57,49); background-color: inherit">改进</span>**<span style="color: rgb(216,57,49); background-color: inherit">：</span>Gate 激活从 $$\mathrm{sigmoid}$$ 改成 $$\sqrt{\mathrm{softplus}(\cdot)}$$、前 3 个 MoE 层用 **Hash routing**（按 token ID 决定专家）。
>
> * **<span style="color: rgb(216,57,49); background-color: inherit">使用 Muon 优化器</span>**<span style="color: rgb(216,57,49); background-color: inherit">：</span>使用 Muon 10 步 hybrid Newton-Schulz 正交化降低优化器开销，Embedding / Head / mHC static bias / RMSNorm 维持 AdamW。MoE expert 权重全程 FP4，CSA indexer 的 QK 路径也 FP4，其余部分保持 FP8。

目前 DeepSeek V4 开源的 4 个Checkpoint参数量/激活量/上下文长度/精度参考：

| **Model**                  | **#Total Params** | **#Activated Params** | **Context Length** | **Precision**     |
| -------------------------- | ----------------- | --------------------- | ------------------ | ----------------- |
| **DeepSeek-V4-Flash-Base** | 284B              | 13B                   | 1M                 | FP8 Mixed         |
| **DeepSeek-V4-Flash**      | 284B              | 13B                   | 1M                 | FP4 + FP8 Mixed\* |
| **DeepSeek-V4-Pro-Base**   | 1.6T              | 49B                   | 1M                 | FP8 Mixed         |
| **DeepSeek-V4-Pro**        | 1.6T              | 49B                   | 1M                 | FP4 + FP8 Mixed\* |

> *FP4 + FP8 Mixed: MoE expert parameters use FP4 precision; most other parameters use FP8.*

## 1. 模型架构

DeepSeek V4 相比 DeepSeek V3 / V3.2 是从残差机制、注意力层结构、MoE gate 激活函数、优化器改进集中在：

| **维度**              | V3 / V3.2                                       | V4                                                                                                                                                                                                                                                                        |
| ------------------- | ----------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **FFN**<br />       | DeepSeekMoE（fine-grained routed + shared）       | **<span style="color: rgb(216,57,49); background-color: inherit">Gate 改为 Sqrt(Softplus(·)) + 前 3 层 Hash routing</span>**                                                                                                                                                  |
| **Attention**<br /> | MLA（V3）/<br />MLA + DSA Lightning Indexer（V3.2） | Hybrid Attention: **<span style="color: rgb(216,57,49); background-color: inherit">CSA + HCA 交错</span>**<br />                                                                                                                                                            |
| **Residual&#x20;**  | 标准 Residual                                     | [**<span style="color: rgb(216,57,49); background-color: inherit"> mHC：Manifold-Constrained Hyper-Connections</span>**](https://my.feishu.cn/wiki/WsaawrdO3ifrmTk3ab4cSgjBnRb)                                                                                            |
| **Optimizer**       | AdamW                                           | **<span style="color: rgb(216,57,49); background-color: inherit"> </span>[<span style="color: rgb(216,57,49); background-color: inherit"> Muon 优化器</span>](https://my.feishu.cn/wiki/Hcj2wGTJEiohTikkdEKc7H4Nnlb)**，embedding / head / mHC static bias / RMSNorm 保留 AdamW |

![](<images/DeepSeek-V4 架构：技术报告!源码解析-截屏2026-04-24 13.17.09.png>)

Pre-training 这次直接用 32T/33T token 语料训练 V4-Flash / V4-Pro，原生支持 1M 上下文（DS V4 最重要的点，相比利用 [YaRN](https://my.feishu.cn/wiki/XCfLw15JoiAcyhkFElccpoiDnLf) 进行的上下文拓展）。

### 1.1 混合注意力（Hybrid Attention）：CSA + HCA 的长文本方案

#### 1.1.1 CSA（Compressed Sparse Attention）：压缩 + 稀疏选择

![DS V3.2 的 DSA](<images/DeepSeek-V4 架构：技术报告!源码解析-截屏2026-02-25 21.38.35.png>)

![DS V4 的 Compressed Sparse Attention](<images/DeepSeek-V4 架构：技术报告!源码解析-img_csa-1.jpg>)

**<span style="color: rgb(216,57,49); background-color: inherit">动机</span>**<span style="color: rgb(216,57,49); background-color: inherit">：V3.2 的 DSA 直接在原始 KV 上用 Lightning Indexer 做 top-K Selection，每个 query 的 KV 候选大小仍是 </span>$$O(n)$$<span style="color: rgb(216,57,49); background-color: inherit">。V4 先进行 KV Sparse 压缩到 </span>$$O(n/m)$$<span style="color: rgb(216,57,49); background-color: inherit"> 再进行 Selection，因此 indexer 排序候选集变为之前的 </span>$$1/m$$<span style="color: rgb(216,57,49); background-color: inherit">。</span>

**<span style="color: rgb(216,57,49); background-color: inherit">实现：</span>**<span style="color: rgb(216,57,49); background-color: inherit">分两步实现，先KV Compress把</span>$$O(n)$$<span style="color: rgb(216,57,49); background-color: inherit">序列压缩到</span>$$O(n/m)$$<span style="color: rgb(216,57,49); background-color: inherit">，后Lightning Indexer进行Top-K选择。</span>

##### **<span style="color: rgb(216,57,49); background-color: inherit">KV Compress</span>**

输入 $$H \in \mathbb{R}^{n \times d}$$，首先用两个可学习的 KV projection $$W^{aKV}, W^{bKV} \in \mathbb{R}^{d \times c}$$映射到 Latent（这里和 MLA 的逻辑是一样的），但是需要注意这里映射了 2 个 Latent 表示为的是压缩的时候进行窗口平滑（Sliding Window）：

$$C^a = H \cdot W^{aKV}, \quad C^b = H \cdot W^{bKV}$$

此外，需要对应的另外两个可学习的 KV projection $$W^{aZ}, W^{bZ} \in \mathbb{R}^{d \times c}$$映射另外一组 Gate Latent，映射维度和上面一样，用来计算压缩时候的加权率（Gating）：

$$Z^a = H \cdot W^{aZ}, \quad Z^b = H \cdot W^{bZ}$$

然后 $$m$$ 个连续 token 计算两个压缩加权比率（<span style="color: rgb(216,57,49); background-color: inherit">论文里面取 </span>$$m=4$$）：

$$[S^a_{mi:m(i+1)-1}; S^b_{m(i-1):mi-1}] = \mathrm{Softmax}_{\mathrm{row}}\big([Z^a_{mi:m(i+1)-1} + B^a;\ Z^b_{m(i-1):mi-1} + B^b]\big)$$

用上面的加权比率就可以将 $$m$$ 个连续 token 合成一个 compressed entry $$C_i^{\mathrm{Comp}}$$，注意 $$C^a$$ 用当前窗口 $$[mi, m(i+1)-1]$$，$$C^b$$ 用**前一个**窗口 $$[m(i-1), mi-1]$$，<span style="color: rgb(216,57,49); background-color: inherit">两个窗口 overlap 一半，这是 CSA 平滑的关键</span>：

$$C_i^{\mathrm{Comp}} = \sum_{j=mi}^{m(i+1)-1} S^a_j \odot C^a_j + \sum_{j=m(i-1)}^{mi-1} S^b_j \odot C^b_j$$

* $$B^a, B^b \in \mathbb{R}^{m \times c}$$：可学习的位置偏置（<span style="color: rgb(216,57,49); background-color: inherit">相当于滑动窗口的 Absolute Position Embedding</span>）。

* $$\odot$$：Hadamard 积，即对应位置相乘，结果 shape 不变。

对应到[代码](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/inference/model.py)里 `Compressor.forward`:

```python
kv = self.wkv(x)        # C^a / C^b stacked, wkv 输出 coff*head_dim 即 2d
score = self.wgate(x)   # Z^a / Z^b stacked
# ...
score = score.unflatten(1, (-1, ratio)) + self.ape   # +B^a/B^b
if overlap:
    kv = self.overlap_transform(kv, 0)                 # 错位 concat 前后窗口
    score = self.overlap_transform(score, float("-inf"))
kv = (kv * score.softmax(dim=2)).sum(dim=2)            # C_i^Comp
```

> * $$W^{aKV}; W^{bKV}$$ 对应 `self.wkv`（`Linear(dim, 2*head_dim)`）
>
> * $$W^{aZ}; W^{bZ}$$ 对应 `self.wgate`
>
> * $$B^a; B^b$$对应  `self.ape`（`Parameter(ratio, 2*head_dim)`）
>
> * `overlap_transform` 对应 $$C^a_{\text{当前}}$$、$$C^b_{\text{前一}}$$ 的错位 Concat

<span style="color: rgb(216,57,49); background-color: inherit">压缩得到 </span>$$C^{\mathrm{Comp}} \in \mathbb{R}^{n/m \times c}$$<span style="color: rgb(216,57,49); background-color: inherit">，序列长度是原本的 </span>$$1/m$$<span style="color: rgb(216,57,49); background-color: inherit">。</span>

##### **<span style="color: rgb(216,57,49); background-color: inherit">Lightning Indexer</span>**

> 这里的 Indexer 风格直接参考的 DeepSeek V3.2（可以参考 [ GLM-5 完整技术报告解读](https://my.feishu.cn/wiki/O51ew78XEimUL6ksgZscbKwonaf)里面的详细代码解析）

对 query token $$t$$，先生成低秩 Latent 再生成 indexer queries（本质上仍然是 MLA）：

$$\mathbf{c}^Q_t = \mathbf{h}_t W^{DQ} $$（注意看这里是行向量右乘风格，本质上和 [ GLM-5 完整技术报告解读](https://my.feishu.cn/wiki/O51ew78XEimUL6ksgZscbKwonaf)的列向量左乘风格一样）

$$[\mathbf{q}^I_{t,1};\ldots;\mathbf{q}^I_{t,n^I_h}] = \mathbf{q}^I_t = \mathbf{c}^Q_t W^{IUQ}$$

同时需要生成 query head 之间的加权权重（$$n^I_h$$ 表示 Indexer 的 query 的 head 数量）：

$$\left[w_{t, 1}^I ; w_{t, 2}^I ; \ldots ; w_{t, n_h^I}^I\right]=\mathbf{w}_t^I=\mathbf{h}_t \cdot W^w,$$

然后应用 ReLU 风格的 index score（需要在多 head 之间求和）：

$$I_{t,s} = \sum_{h=1}^{n^I_h} w^I_{t,h} \cdot \mathrm{ReLU}(\mathbf{q}^I_{t,h} \cdot K^{\mathrm{IComp}}_s)$$

Top-k 选择：$$C_t^{\text {SprsComp }}=\left\{C_s^{\text {Comp }} \mid I_{t, s} \in \operatorname{Top}-\mathrm{k}\left(I_{t,:}\right)\right\}$$。

对应到[代码](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/inference/model.py)里 `Indexer.forward`：

```python
q = self.wq_b(qr)                        # c^Q_t * W^IUQ
apply_rotary_emb(q[..., -rd:], ...)
q = rotate_activation(q)                 # Hadamard rotation 为 FP4 做准备
fp4_act_quant(q, fp4_block_size, True)   # q 走 FP4
self.compressor(x, start_pos)            # 压缩 indexer keys, 内部处理 k 到 FP4
weights = self.weights_proj(x) * self.softmax_scale  # w^I_{t,h}
index_score = torch.einsum("bshd,btd->bsht", q, self.kv_cache[...])
index_score = (index_score.relu_() * weights.unsqueeze(-1)).sum(dim=2)  # I_{t,s}
topk_idxs = index_score.topk(min(self.index_topk, ...))[1]
```

> * $$W^{IUQ}$$ 对应 `self.wq_b`（`ColumnParallelLinear(q_lora_rank, index_n_heads * index_head_dim)`）
>
> * $$W^w$$ 对应 `self.weights_proj`
>
> * Indexer 的 compressed KV 对应 `self.compressor`，写入 `self.kv_cache[...]`
>
> * $$\mathrm{ReLU}(\mathbf{q} \cdot K)$$ 对应 `index_score.relu_()`
>
> * **Indexer 的 QK 全走 FP4**：`fp4_act_quant(q, ...)`，减少 indexer 本身的 memory traffic 和算力。
>
> * **top-K 规模比 V3.2 小**：V4-Pro 的 `index_topk=512`。
>
> * **query 压缩&#x20;**$$\mathbf{c}^Q_t$$**&#x20;是 indexer 和 attention 共享的**：省去一次 down-proj 计算。

##### **<span style="color: rgb(216,57,49); background-color: inherit">Shared KV MQA </span>**

选出 top-k compressed entries 之后做 MQA：

$$[\mathbf{q}_{t,1};\ldots;\mathbf{q}_{t,n_h}] = \mathbf{q}_t = \mathbf{c}^Q_t W^{UQ}$$

$$\mathbf{o}_{t,i} = \mathrm{CoreAttn}\big(\mathrm{query}=\mathbf{q}_{t,i},\ \mathrm{key}=C^{\mathrm{SprsComp}}_t,\ \mathrm{value}=C^{\mathrm{SprsComp}}_t\big)$$

最后把多个 head 的 $$\mathbf{o}_{t,i}$$ 拼起来得到 $$\mathbf{o}_t=\left[\mathbf{o}_{t, 1} ; \mathbf{o}_{t, 2} ; \ldots ; \mathbf{o}_{t, n_h}\right] \in \mathbb{R}^{c n_h}$$。

##### **<span style="color: rgb(216,57,49); background-color: inherit">Grouped Output Projection</span>**

**<span style="color: rgb(216,57,49); background-color: inherit">动机：</span>**&#x4E0A;一步合并的 $$\mathbf{o}_t$$的 hidden dim $$cn_h$$ 非常大，如果直接进行 $$w_o$$投影，投影矩阵是 $$cn_h \times d$$，参数量和计算量都很夸张。

**<span style="color: rgb(216,57,49); background-color: inherit">实现：</span>**&#x5148;分组降维,再合并投影。

* **分组**

把 $$n_h$$ 个头平均分成 $$g$$ 组,每组有 $$n_h/g$$ 个头。每组拼起来的向量是: $$\mathbf{o}_{t,i}^G \in \mathbb{R}^{c \cdot n_h/g}$$

* **组内降维&#x20;**

每一组各自用一个小的投影矩阵,把 $$c \cdot n_h/g$$ 维压到 $$d_g$$ 维:$$\mathbf{o}_{t,i}^GW^{\mathrm{o\_a}}_g = \mathbf{o}_{t,i}^{G'} \in \mathbb{R}^{d_g}$$

* **合并后再投影到 $$d$$**

把 $$g$$ 个降维后的小向量拼起来(总共 $$d_g \cdot g$$ 维),再用一个投影矩阵送到最终的 $$d$$ 维: $$\mathbf{o}_{t,i}^{G'} = \hat{\mathbf{o}}_tW^{\mathrm{o\_b}} \in \mathbb{R}^d$$

对应到[代码](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/inference/model.py)里 `Attention.__init__` 和 `forward`：

```python
self.wo_a = ColumnParallelLinear(self.n_heads * self.head_dim // self.n_groups,
                                 self.n_groups * args.o_lora_rank,
                                 dtype=torch.bfloat16)
self.wo_b = RowParallelLinear(self.n_groups * args.o_lora_rank, self.dim)
# ...
o = o.view(bsz, seqlen, self.n_local_groups, -1)
wo_a = self.wo_a.weight.view(self.n_local_groups, self.o_lora_rank, -1)
o = torch.einsum("bsgd,grd->bsgr", o, wo_a)  # 每组独立降维
x = self.wo_b(o.flatten(2))                  # 再拼起来投到 dim
```

* $$W^{\mathrm{o\_a}}_g$$ 对应 `self.wo_a.weight.view(n_groups, o_lora_rank, -1)` 按组切片

* $$W^{\mathrm{o\_b}}$$ 对应 `self.wo_b`



#### 1.1.2 HCA（Heavily Compressed Attention）：极端压缩 + dense MQA

![DS V4 的 Compressed Sparse Attention](<images/DeepSeek-V4 架构：技术报告!源码解析-img_csa.jpg>)

![DS V4 的 Heavily Compressed Attention](<images/DeepSeek-V4 架构：技术报告!源码解析-截屏2026-04-24 13.46.32.png>)

##### **<span style="color: rgb(216,57,49); background-color: inherit">KV Compress 与 CSA 共用实现</span>**

**<span style="color: rgb(216,57,49); background-color: inherit">动机</span>**<span style="color: rgb(216,57,49); background-color: inherit">：</span>CSA 设置$$m=4$$ 的 KV 压缩率不够，在极长文本（如目标的 1M 上下文）下仍有巨大开销。DeepSeek V4 希望有一层<span style="color: rgb(216,57,49); background-color: inherit">全局的、非稀疏 KV 通道</span>，补充 CSA 丢掉的全局信号。

**<span style="color: rgb(216,57,49); background-color: inherit">实现：</span>**&#x48;CA（Heavily Compressed Attention）设置更激进的$$m'=128$$，不做稀疏选择，直接 dense MQA。

由于没有 CSA 的滑动窗口策略（overlap），因此只有一路 KV：$$C = H \cdot W^{KV},\quad Z = H \cdot W^Z$$

计算压缩重要性权重：

$$S_{m'i:m'(i+1)-1} = \mathrm{Softmax}_{\mathrm{row}}(Z_{m'i:m'(i+1)-1} + B)$$

加权获得压缩 KV：

$$C_i^{\mathrm{Comp}} = \sum_{j=m'i}^{m'(i+1)-1} S_j \odot C_j$$

对应到[代码](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/inference/model.py)里直接复用`Compressor` 类，设置 `compress_ratio=128`、`overlap=False`：

```python
class Compressor:
    def __init__(self, ..., compress_ratio=4):
        ...
        self.overlap = compress_ratio == 4  # 只有 ratio=4 时才 overlap
```

**<span style="color: rgb(216,57,49); background-color: inherit">Shared KV MQA / Grouped Output Projection 与 CSA 共用实现</span>**

对应到[代码](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/inference/model.py)里 `Attention` 类（compress\_ratio != 4 时 `self.indexer = None`）：

```python
if self.compress_ratio:
    self.compressor = Compressor(args, self.compress_ratio, self.head_dim)
    if self.compress_ratio == 4:
        self.indexer = Indexer(args, self.compress_ratio)
    else:
        self.indexer = None
```

Grouped Output Projection 参考 CSA 实现。



#### 1.1.3 CSA / HCA 排布设置（Interleaved 布层）

可以注意到 V4-Pro 的 [config.json](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/config.json) 文件内有一个 `compress_ratios` 参数，是一个长度 62 的列表。这个就是决定每一层是 CSA / HCA 的关键参数（61 层 + 1 MTP 层）：

```plain&#x20;text
"compress_ratios": [128, 128, 4, 128, 4, 128, 4, 128, 4, 128, 4, 128, 4, ..., 4, 128, 4, 0]
```

* **Layer 0-1**：HCA only（$$m=128$$）。最底层（非抽象特征）需要全局粗粒度视野，不需要 Indexer。

* **Layer 2-60**：CSA 和 HCA 交替排列。

* **Layer 61 (MTP block)**：$$m=0$$，退化为纯 sliding window attention。

**<span style="color: rgb(216,57,49); background-color: inherit">直观理解CSA / HCA 排布设置：</span>**&#x5E95;层保持全局视野，之后交替 fine-grained 局部细节（CSA 的 top-k 稀疏 + 4x 压缩）和 coarse 全局汇总（HCA 的 128x dense）。



#### 1.1.4 Hybrid Attention 中的其他重要 Tricks

* **Query / KV RMSNorm：** 每个head 的 Q、共享的 KV 都单独做 RMSNorm，目的是防止 attention logits 爆炸：

```python
qr = q = self.q_norm(self.wq_a(x)) # latent RMSNorm
q = self.wq_b(q).unflatten(-1, (self.n_local_heads, self.head_dim))
q *= torch.rsqrt(q.square().mean(-1, keepdim=True) + self.eps) # 真正的 q norm
# ...
kv = self.kv_norm(kv) # kv norm
```

* **Partial RoPE：** 只对 last 64 dims（`rope_head_dim=64`）做 RoPE，其余 448 维走 FP8/FP4 量化：

```python
apply_rotary_emb(q[..., -rd:], freqs_cis)
apply_rotary_emb(kv[..., -rd:], freqs_cis)
# rope 维度保留 BF16，非 rope 维度走 FP8 simulate
act_quant(kv[..., :-rd], 64, scale_fmt, scale_dtype, True)
```

* **Attention Sink：** 给每个 head 加一个可学习 logit $$z'_h$$ 到 softmax 分母：$$s_{h,i,j} = \frac{\exp(z_{h,i,j})}{\sum_k \exp(z_{h,i,k}) + \exp(z'_h)}$$

让逐 head 的 attention 可以选择"不对任何token施加注意力"，实现上由 `sparse_attn` 核融合进 softmax 分母：

```python
self.attn_sink = nn.Parameter(torch.empty(self.n_local_heads, dtype=torch.float32))
...
o = sparse_attn(q, self.kv_cache[:bsz], self.attn_sink, topk_idxs, self.softmax_scale)
```

* **<span style="color: rgb(216,57,49); background-color: inherit">Sliding Window branch</span>：** 每层保留 `n_win=128` 个 uncompressed KV，跟压缩 KV 拼在一起做 attention：

```python
self.register_buffer("kv_cache", torch.zeros(args.max_batch_size, kv_cache_size, self.head_dim))
# kv_cache_size = args.window_size + (max_seq_len // compress_ratio if compress_ratio else 0)
# 前 window_size 行放 SWA KV，后面 max_seq_len/m 行放 compressed KV
```

**<span style="color: rgb(216,57,49); background-color: inherit">这其实是对 CSA/HCA 的漏洞修复，有两个动机：</span>**

1. 维持严格因果性带来的块内盲区：CSA/HCA 的 query 只能 select "已经完成的"压缩块，跟query 同属一个压缩块的 m-1 个邻居彼此看不见（CSA 的 m=4、HCA 的 m'=128都有这个问题）。

2. 最近邻优先：最近 token相关性最强，留未压缩的精确版本比压缩后的更精确。



### 1.2 mHC： 替换 Residual 为稳定、自适应表达的受约束连接结构

> 详细介绍可以参考[ mHC：Manifold-Constrained Hyper-Connections](https://my.feishu.cn/wiki/WsaawrdO3ifrmTk3ab4cSgjBnRb?from=space_search)

**<span style="color: rgb(216,57,49); background-color: inherit">动机：</span>**&#x52;esidual Connections 表达能力受限、且存在 Seesaw 效应。作为 Residual Connections 的改进 Hyper-Connections（HC）也存在数值不稳定、系统开销大的问题。

![](<images/DeepSeek-V4 架构：技术报告!源码解析-截屏2026-03-16 00.47.32.png>)

#### 1.2.1 HC 的形式化表示

HC（Hyper-Connections）的思路是把残差流从 $$C$$ 维扩宽到 $$nC$$ 维，$$n$$ 是 expansion rate，相当于有 $$n$$ 条并行残差流。单层 HC 的公式：$$\mathbf{x}_{l+1} = \mathcal{H}_l^{res}\mathbf{x}_l + \mathcal{H}_l^{post\top} \mathcal{F}(\mathcal{H}_l^{pre}\mathbf{x}_l, \mathcal{W}_l)$$，其中：

* $$\mathbf{x}_l \in \mathbb{R}^{n \times C}$$ 是 $$n$$ 流拓展的残差状态（相比原始残差连接多了 $$n$$ 倍宽度）

* $$\mathcal{H}_l^{res} \in \mathbb{R}^{n \times n}$$ 是残差流内的可学习特征混合矩阵

* $$\mathcal{H}_l^{pre} \in \mathbb{R}^{1 \times n}$$ 把 $$nC$$ 维残差流聚合成 $$C$$ 维送进 Layer（保证原始变换$$\mathcal{F}$$不变）

* $$\mathcal{H}_l^{post} \in \mathbb{R}^{1 \times n}$$ 把 Layer 的 $$C$$ 维输出映射回 $$nC$$ 维残差流

参考上图，可以看到 HC 在 Pre Mapping 和 Post Mapping 上引入了<span style="color: inherit; background-color: rgba(254,212,164,0.8)">可学习矩阵（橙色）</span>，mHC 在此基础上对 Res Mapping 和 Pre/Post Mapping 都加了<span style="color: inherit; background-color: rgba(183,237,177,0.8)">流形投影（绿色）</span>。HC 的三个 Mapping可学习矩阵计算方法：

$$\begin{cases}
\tilde{\mathbf{x}}_l = \text{RMSNorm}(\mathbf{x}_l) \\
\mathcal{H}_l^{pre} = \alpha_l^{pre} \cdot \tanh(\theta_l^{pre}\tilde{\mathbf{x}}_l^\top) + \mathbf{b}_l^{pre} \\
\mathcal{H}_l^{post} = \alpha_l^{post} \cdot \tanh(\theta_l^{post}\tilde{\mathbf{x}}_l^\top) + \mathbf{b}_l^{post} \\
\mathcal{H}_l^{res} = \alpha_l^{res} \cdot \tanh(\theta_l^{res}\tilde{\mathbf{x}}_l^\top) + \mathbf{b}_l^{res}
\end{cases} \tag{1}$$

其中：

* $$\alpha_l^{pre}, \alpha_l^{post}, \alpha_l^{res} \in \mathbb{R}$$ 是可学习的 gating 因子，初始化为小值（论文中 $$\alpha = 0.01$$）

* $$\theta_l^{pre}, \theta_l^{post} \in \mathbb{R}^{1 \times C}$$，$$\theta_l^{res} \in \mathbb{R}^{n \times C}$$ 是动态映射（dynamic mapping）的线性投影参数

* $$\mathbf{b}_l^{pre}, \mathbf{b}_l^{post} \in \mathbb{R}^{1 \times n}$$，$$\mathbf{b}_l^{res} \in \mathbb{R}^{n \times n}$$ 是静态偏置（static mapping）

> 这里有个细节：HC 的 mapping 由两部分组成：动态部分（依赖当前输入 $$\mathbf{x}_l$$）和静态部分（全局可学习偏置）。初始化时 $$\alpha$$ 接近 0，所以主要是静态偏置在起作用，接近标准残差网络的 identity mapping。



#### 1.2.2 mHC 核心约束 / 代码实现

还是最上面的对比图，mHC 在 HC 的基础上做出的改进：**限制&#x20;**$$\mathcal{H}_l^{res}$$**&#x20;是双随机矩阵（doubly stochastic matrix）**。

双随机矩阵流形的定义（Birkhoff polytope $$\mathcal{M}^{res}$$）：

$$\mathcal{P}_{\mathcal{M}^{res}}(\mathcal{H}_l^{res}) := \left\{\mathcal{H}_l^{res} \in \mathbb{R}^{n \times n} \mid \mathcal{H}_l^{res}\mathbf{1}_n = \mathbf{1}_n,\ \mathbf{1}_n^\top \mathcal{H}_l^{res} = \mathbf{1}_n^\top,\ \mathcal{H}_l^{res} \geq 0 \right\} \tag{2}$$

其中，$$\mathbf{1}_n$$ 是 n 维全 1 向量；条件 $$\mathcal{H}_l^{res}\mathbf{1}_n = \mathbf{1}_n$$ 要求每行之和为 1；条件 $$\mathbf{1}_n^\top \mathcal{H}_l^{res} = \mathbf{1}_n^\top$$ 要求每列之和为 1；条件 $$\mathcal{H}_l^{res} \geq 0$$ 要求元素非负。$$n=1$$时，双随机矩阵退化为标量 1，整个 HC 退化为标准残差连接 identity mapping。

双随机矩阵流形约束通过以下三个性质解决 HC 的问题：

1. **Norm Preservation（范数保持）**：双随机矩阵的谱范数 $$\|\mathcal{H}_l^{res}\|_2 \leq 1$$。这意味着学习到的映射是 non-expansive 的，梯度爆炸问题得到缓解。

2. **Compositional Closure（乘法封闭）**：双随机矩阵对矩阵乘法封闭。也就是说，复合映射 $$\prod_{i=1}^{L-l} \mathcal{H}_{L-i}^{res}$$ 仍然是双随机矩阵，整个深度方向的稳定性都得到了保证。

3) **Birkhoff Polytope 几何解释**：$$\mathcal{M}^{res}$$ 是所有置换矩阵的凸包。因此 $$\mathcal{H}_l^{res}\mathbf{x}_l$$ 本质上是各 stream 特征的 **凸组合**（convex combination），均值守恒、方差有界，很自然地防止了信号漂移。

> 简单例子：设 $$n=2$$，$$\mathcal{H}_l^{res} = \begin{pmatrix} 0.7 & 0.3 \\ 0.3 & 0.7 \end{pmatrix}$$这就是一个合法的双随机矩阵。它的优势：每条stream输出 = 自身的 0.7 倍 + 另一条流的 0.3 份。信息有了混合，但每条流的总强度没有放大，就是"稳定且有信息交换"。

另外，论文还对 $$\mathcal{H}_l^{pre}$$ 和 $$\mathcal{H}_l^{post}$$ 加了非负性约束，防止正负系数合成时信号相消。

mHC 中三个 mapping 的计算分两步：

**Step 1: 计算未约束的 $$\tilde{\mathcal{H}}$$**

给定第 $$l$$ 层的输入隐层矩阵 $$\mathbf{x}_l \in \mathbb{R}^{n \times C}$$，先 flatten 成 $$\tilde{\mathbf{x}}_l = \text{vec}(\mathbf{x}_l) \in \mathbb{R}^{1 \times nC}$$，然后：

$$\begin{cases}
\tilde{\mathbf{x}}_l' = \text{RMSNorm}(\tilde{\mathbf{x}}_l) \\
\tilde{\mathcal{H}}_l^{pre} = \alpha_l^{pre} \cdot (\tilde{\mathbf{x}}_l'\varphi_l^{pre}) + \mathbf{b}_l^{pre} \\
\tilde{\mathcal{H}}_l^{post} = \alpha_l^{post} \cdot (\tilde{\mathbf{x}}_l'\varphi_l^{post}) + \mathbf{b}_l^{post} \\
\tilde{\mathcal{H}}_l^{res} = \alpha_l^{res} \cdot \text{mat}(\tilde{\mathbf{x}}_l'\varphi_l^{res}) + \mathbf{b}_l^{res}
\end{cases} \tag{3}$$

* $$\varphi_l^{pre}, \varphi_l^{post} \in \mathbb{R}^{nC \times n}$$，$$\varphi_l^{res} \in \mathbb{R}^{nC \times n^2}$$ 是线性投影参数

* $$\text{mat}(\cdot)$$ 是从 $$\mathbb{R}^{1 \times n^2}$$到 $$\mathbb{R}^{n \times n}$$ 的 reshape 函数

> **<span style="color: rgb(216,57,49); background-color: inherit">mHC 和 HC 在参数化上的关键区别</span>**：HC 用的是各流独立的 $$n \times C$$ 状态（每条流单独 RMSNorm），mHC 先把所有流 **flatten 拼接**成 $$1 \times nC$$ 的向量，再做 RMSNorm 和投影。这样 mHC 在计算三个 mapping 时能利用**跨流**的完整信息。

**Step 2: 将$$\tilde{\mathcal{H}}$$投影到流形约束**

$$\begin{cases}
\mathcal{H}_l^{pre} = \sigma(\tilde{\mathcal{H}}_l^{pre}) \\
\mathcal{H}_l^{post} = 2\sigma(\tilde{\mathcal{H}}_l^{post}) \\
\mathcal{H}_l^{res} = \text{Sinkhorn-Knopp}(\tilde{\mathcal{H}}_l^{res})
\end{cases} \tag{4}$$

* $$\sigma(\cdot)$$ 是 Sigmoid 函数，保证 $$\mathcal{H}_l^{pre}$$ 元素非负，值域 $$(0, 1)$$

* $$\sigma(\tilde{\mathcal{H}}_l^{post})$$ 乘以 2 的两个目的：

  * 是为了让 $$\mathcal{H}_l^{post}$$ 的期望值约为 1（$$2 \times \sigma(0) = 1$$），和 HC 初期静态偏置为 1 的设定对齐。

  * 为了让输出范围在 (0, 2)，保留更大表达空间。

* $$\text{Sinkhorn-Knopp}(\cdot)$$ 把任意正矩阵迭代投影为双随机矩阵：先对所有元素取 exp 保证正数，然后交替做行归一化和列归一化，下面详细介绍。

**Sinkhorn-Knopp 算法**

先做指数变换让所有元素为正：$$\mathbf{M}^{(0)} = \exp(\tilde{\mathcal{H}}_l^{res})$$，然后交替做行归一化和列归一化：

$$\mathbf{M}^{(t)} = \mathcal{T}_r\left(\mathcal{T}_c(\mathbf{M}^{(t-1)})\right) \tag{5}$$

* $$\mathcal{T}_r$$ 表示行归一化（每行除以行和）

* $$\mathcal{T}_c$$ 表示列归一化（每列除以列和）

当 $$t \to \infty$$ 时，$$\mathbf{M}^{(t)}$$ 收敛到双随机矩阵 $$\mathcal{H}_l^{res} = \mathbf{M}^{(t_{max})}$$。实验中取 $$t_{max} = 20$$。

> 直观理解：每次行归一化让每行和为 1（满足行条件），但可能破坏列条件。每次列归一化修复列条件，但可能破坏行条件。交替迭代，两个条件同时收敛。收敛速度很快，20 步足以达到很高精度。

对应[代码](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/inference/kernel.py)实现（`Block.hc_pre`）：

```python
class Block(nn.Module):
    """Transformer block with Hyper-Connections (HC) mixing.
    Instead of a simple residual, HC maintains `hc_mult` copies of the hidden state.
    hc_pre: reduces hc copies -> 1 via learned weighted sum (pre-weights from Sinkhorn).
    hc_post: expands 1 -> hc copies via learned post-weights + combination matrix."""
    def __init__(self, layer_id: int, args: ModelArgs):
        super().__init__()
        self.layer_id = layer_id
        self.norm_eps = args.norm_eps
        self.attn = Attention(layer_id, args)
        self.ffn = MoE(layer_id, args)
        self.attn_norm = RMSNorm(args.dim, self.norm_eps)
        self.ffn_norm = RMSNorm(args.dim, self.norm_eps)
        self.hc_mult = hc_mult = args.hc_mult
        self.hc_sinkhorn_iters = args.hc_sinkhorn_iters
        self.hc_eps = args.hc_eps
        mix_hc = (2 + hc_mult) * hc_mult
        hc_dim = hc_mult * args.dim
        with set_dtype(torch.float32):
            self.hc_attn_fn = nn.Parameter(torch.empty(mix_hc, hc_dim))
            self.hc_ffn_fn = nn.Parameter(torch.empty(mix_hc, hc_dim))
            self.hc_attn_base = nn.Parameter(torch.empty(mix_hc))
            self.hc_ffn_base = nn.Parameter(torch.empty(mix_hc))
            self.hc_attn_scale = nn.Parameter(torch.empty(3))
            self.hc_ffn_scale = nn.Parameter(torch.empty(3))

    def hc_pre(self, x: torch.Tensor, hc_fn: torch.Tensor, hc_scale: torch.Tensor, hc_base: torch.Tensor):
        # x: [b,s,hc,d], hc_fn: [mix_hc,hc*d], hc_scale: [3], hc_base: [mix_hc], y: [b,s,hc,d]
        shape, dtype = x.size(), x.dtype
        x = x.flatten(2).float()
        rsqrt = torch.rsqrt(x.square().mean(-1, keepdim=True) + self.norm_eps)
        mixes = F.linear(x, hc_fn) * rsqrt
        pre, post, comb = hc_split_sinkhorn(mixes, hc_scale, hc_base, self.hc_mult, self.hc_sinkhorn_iters, self.hc_eps)
        y = torch.sum(pre.unsqueeze(-1) * x.view(shape), dim=2)
        return y.to(dtype), post, comb

    def hc_post(self, x: torch.Tensor, residual: torch.Tensor, post: torch.Tensor, comb: torch.Tensor):
        # x: [b,s,d], residual: [b,s,hc,d], post: [b,s,hc], comb: [b,s,hc,hc], y: [b,s,hc,d]
        y = post.unsqueeze(-1) * x.unsqueeze(-2) + torch.sum(comb.unsqueeze(-1) * residual.unsqueeze(-2), dim=2)
        return y.type_as(x)

    def forward(self, x: torch.Tensor, start_pos: int, input_ids: Optional[torch.Tensor]) -> torch.Tensor:
        residual = x
        x, post, comb = self.hc_pre(x, self.hc_attn_fn, self.hc_attn_scale, self.hc_attn_base)
        x = self.attn_norm(x)
        x = self.attn(x, start_pos)
        x = self.hc_post(x, residual, post, comb)

        residual = x
        x, post, comb = self.hc_pre(x, self.hc_ffn_fn, self.hc_ffn_scale, self.hc_ffn_base)
        x = self.ffn_norm(x)
        x = self.ffn(x, input_ids)
        x = self.hc_post(x, residual, post, comb)
        return x
```



### 1.3 MoE：Anticipatory Routing + Hash Routing

#### 1.3.1 Hash routing

<span style="color: rgb(216,57,49); background-color: inherit">DeepSeek V4 的前 3 个 MoE 层换成 Hash routing，Hash routing 具体来说就是：每个 token ID 用一个固定 hash 函数映射到固定的 expert 集合，不需要任何学习。即 token ID → expert indices，训练前预计算。</span>

V4-Pro/V4-Flash 都设置 `n_hash_layers=3`，只用前 3 层的原因：

* 底层是词形特征（底层特征，即基本语法属性），不需要语义级别的路由。

* Hash 路由零 gating cost、零 load imbalance，用在底层可以省掉学习开销，帮助后期层收敛。

参考[代码](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/inference/model.py)`Gate.__init__` + `forward` 实现：

```python
self.hash = layer_id < args.n_hash_layers  # 前 n_hash_layers 层为 hash
if self.hash:
    self.tid2eid = nn.Parameter(
        torch.empty(args.vocab_size, args.n_activated_experts, dtype=torch.int32),
        requires_grad=False,
    )
    self.bias = None
else:
    self.bias = nn.Parameter(torch.empty(args.n_routed_experts, dtype=torch.float32))
# ...
if self.hash:
    indices = self.tid2eid[input_ids]
else:
    indices = scores.topk(self.topk, dim=-1)[1]
```

#### 1.3.2 Sqrt(Softplus(·))&#x20;

V3/V3.2 系列 gate 用 sigmoid 计算：$$s_i = \sigma(\mathbf{w}_i^T \mathbf{x})$$。

V4 改成 $$s_i = \sqrt{\mathrm{softplus}(\mathbf{w}_i^T \mathbf{x})} = \sqrt{\log(1 + e^{\mathbf{w}_i^T \mathbf{x}})}$$。

如何理解 $$\sqrt{\mathrm{softplus}(x)}$$ 相比 $$\sigma(x)$$的优势，我们先看两个极限：

* 当 $$x \to -\infty$$：$$\sigma(x) \to 0$$（exp 指数衰减），$$\sqrt{\mathrm{softplus}(x)} \to \sqrt{e^x} = e^{x/2}$$（更平缓）

* 当 $$x \to +\infty$$：$$\sigma(x) \to 1$$（饱和），$$\sqrt{\mathrm{softplus}(x)} \to \sqrt{x}$$（**<span style="color: rgb(216,57,49); background-color: inherit">发散</span>**）

所以 sqrtsoftplus 的一大特性是在高分区仍有梯度，区分度更强。V3 的 sigmoid 在 logit 很大时 score 都被压到 1 附近，top-k 选择基本由 bias 主导。V4 改用 sqrtsoftplus 后，score 本身就能表达高分优先级。

对应[代码](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/inference/model.py)实现参考`Gate.forward`：

```python
elif self.score_func == "sigmoid":
    scores = scores.sigmoid()
else:   # "sqrtsoftplus"
    scores = F.softplus(scores).sqrt()
```

#### 1.3.3 Anticipatory Routing

作者发现 loss spike 跟 MoE 路由的同步有关，路由机制会放大 outlier。做法是用不同步更新：在第 $$t$$ 步用**当前**参数 $$\theta_t$$ 做 feature 计算，但路由 index 用$$\theta_{t-\Delta t}$$ 提前算好的版本，即路由滞后一步。但是这个只作为 rescue 策略，只在检测到 loss spike 时短期激活，稳定后切回同步更新。

#### 1.3.4 SwiGLU Clamping

[config.json](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/inference/config.json) 里 `swiglu_limit=10.0`**，**&#x5373;对 SwiGLU 的线性分量 clamp 到 $$[-10, 10]$$、gate 分量限制上界 10：

```python
if self.swiglu_limit > 0:
    up = torch.clamp(up, min=-self.swiglu_limit, max=self.swiglu_limit)
    gate = torch.clamp(gate, max=self.swiglu_limit)
```

#### 1.3.5 其他 MoE 配置

* 384 routed + 1 shared expert，V4-Pro 每 token 激活 6 个 routed + 1 shared。

* auxiliary-loss-free load balancing 保留（bias 控制 top-k），加一个低权的 sequence-level balance loss。

* V4 把 MoE expert 权重全程 FP4（MXFP4 格式），CSA indexer 的 QK 路径也 FP4，其余部分保持 FP8。



### 1.4 Muon 优化器

> 详细解析参考[ Muon 优化器](https://my.feishu.cn/wiki/Hcj2wGTJEiohTikkdEKc7H4Nnlb)

#### 1.4.1 Muon：Newton-Schulz 正交化代替 AdamW 的二阶矩

我们直接来看伪代码，因为<span style="color: rgb(216,57,49); background-color: inherit">Muon的伪代码真的非常简单</span>：

![](<images/DeepSeek-V4 架构：技术报告!源码解析-muon_algo.png>)

<span style="color: rgb(216,57,49); background-color: inherit">除开NewtonSchulz5这个函数看不懂</span>，整体逻辑非常简单：

* 计算Gradient

* 滑动平均计算Momentum

* NewtonSchulz5计算一个梯度变化量$$O_t$$

* 直接用$$\eta O_t$$更新参数

而这里的<span style="color: rgb(216,57,49); background-color: inherit">NewtonSchulz5是指Newton-Schulz (NS)迭代</span>，NewtonSchulz5是指迭代了5次，NS迭代的意义是：

$$\operatorname{Ortho}(B_t)=\arg \min _O\left\{\|O-B_t\|_F: \text { either } O^{\top} O=I \text { or } O O^{\top}=I\right\}$$

即 NS 迭代会寻找一个与动量矩阵$$B_t$$其最接近的半正交矩阵$$O_t$$用来更新权重。

而这也是和 $$UV^\top$$等价的，其中 $$B_t$$ 的奇异值分解是 $$U S V^{\top}$$，但是我们因为奇异值分解的计算复杂，而使用了其他求 $$O_t$$的方式，Newton-Schulz (NS)迭代就是Muon使用的近似策略。

DeepSeek V4 给出的核心的 Hybrid Newton-Schulz 迭代：

$$M_k = a M_{k-1} + b (M_{k-1} M_{k-1}^T) M_{k-1} + c (M_{k-1} M_{k-1}^T)^2 M_{k-1}$$

* 前 8 步用激进系数 $$(a, b, c) = (3.4445, -4.7750, 2.0315)$$：快速把奇异值推向 1

* 后 2 步用稳态系数 $$(a, b, c) = (2, -1.5, 0.5)$$：把奇异值锁死在 1 附近

> **<span style="color: rgb(216,57,49); background-color: inherit">Hybrid Newton-Schulz 迭代两阶段的原因? </span>**&#x5355;一激进系数可能 overshoot（奇异值震荡），单一稳态系数又收敛太慢。
>
> **<span style="color: rgb(216,57,49); background-color: inherit">为什么要找半正交矩阵？</span>**&#x56E0;为为 SGD-momentum 和 Adam 计算得到的参数变化量（$$\Delta W$$）一般是低秩矩阵，也就是说权重的更新仅由少数几个方向主导。而正交化有效地平衡了各个“方向”的更新幅度。有的更新方向在更新中幅度较小，但对整体的优化很重要。
>
> **<span style="color: rgb(216,57,49); background-color: inherit">为什么 V4 不再需要 QK-Clip？</span>** V4 对 Q 和 KV 直接做 RMSNorm，attention logits 本身就不会爆炸，所以 Muon 不用 QK-Clip。



#### 1.4.2 Muon vs AdamW 的参数分配

需要注意的是，在实际训练中并非所有参数都走 Muon：

| **模块**                                              | 优化器      |
| --------------------------------------------------- | -------- |
| **Embedding**                                       | AdamW    |
| **Prediction head**                                 | AdamW    |
| **mHC 的静态 bias $$S_l$$、gating factor $$\alpha_l$$** | AdamW    |
| **RMSNorm**                                         | AdamW    |
| **其他所有参数（attention, MoE expert, mHC等）**             | **Muon** |

* embedding / head 稀疏更新（每次只更新 batch 里出现的 token 行），走 AdamW。

* RMSNorm、mHC 是 1D 向量，Muon 对标量/向量没有意义。
