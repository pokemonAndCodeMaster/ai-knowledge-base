> 之前在[《从 Position Interpolation 到 YaRN：RoPE外推之路》](https://appttaswqlt5080.h5.xet.citv.cn/xe.community.community_service/v2/feedDetail?app_id=appttaswqlt5080\&community_id=c_68afda25fc3aa_opARMaig2204\&feed_id=d_68c229ffdd4cf_7ZjVWsVjCoOk\&share_user_id=\&share_type=) 仔细介绍过 RoPE 外推的常见方法：
>
> * PI（Position Interpolation）
>
> * NTK-aware
>
> * NTK-by-parts
>
> * Dynamic NTK
>
> * YaRN
>
> 其中 YaRN 在最近的大模型架构中几乎是长度外推的标配，包括 Qwen-3、DeepSeek-V3、GPT-OSS 中均有使用，本期通过 Qwen-3 源码来解析 YaRN 代码实现！

> 推荐读者前置阅读：
>
> * [ RoPE代码实现和公式不一致 !？从0手撕RoPE](https://my.feishu.cn/wiki/Pz1UwfhoHi5Hr9kCCuScSa6Bnuc)
>
> * &#x20;[从 Position Interpolation 到 YaRN：RoPE外推之路](https://appttaswqlt5080.h5.xet.citv.cn/xe.community.community_service/v2/feedDetail?app_id=appttaswqlt5080\&community_id=c_68afda25fc3aa_opARMaig2204\&feed_id=d_68c229ffdd4cf_7ZjVWsVjCoOk\&share_user_id=\&share_type=)&#x20;



## 1. YarN 的原理

一般在现代模型架构中不会单独使用 YaRN，huggingface官方实现的 `_compute_yarn_parameters` 函数就是同时使用了 NTK-by-parts 和 YaRN 两种策略的。

另外，NTK-by-parts、YaRN、dynamic NTK 三种策略是可以同时使用的，但是这个取决于推理框架是否适用，比如 vLLM 实现的是 static RoPE，transformers 需要配置`rope_type` 参数，因此支持dynamic NTK视情况而定（本质上是动态拓展比）。

我们先来回顾下这三种策略：

### 1.1 NTK-by-parts（按照维度不同分段确定插值程度）

> 先介绍一下波长的概念，波长$$\lambda_d$$ 为第 $$d$$ 个隐藏维度上 RoPE 嵌入的波长：$$\lambda_d=\frac{2 \pi}{\theta_d}=2 \pi b^{\frac{2 d}{|D|}}$$，波长代表了 $$d$$ 维RoPE嵌入执行完整旋转（ $$2 \pi$$ ）所需的token长度。
>
> NTK-by-parts 则根据波长来对不同维度（不同频段）分段处理，引入原始上下文长度$$L$$和波长之间比率：
>
> $$r(d)=\frac{L}{\lambda_d}=\frac{L}{2 \pi b^{\prime \frac{2 d}{|D|}}}$$
>
> 为了定义中高低频的边界，引入两个额外的参数 $$\alpha 、 \beta$$ ：
>
> 如果 $$r(d)<\alpha$$ ，即低频维度，使用线性插值
>
> 如果 $$r(d)>\beta$$ ，即高频维度，不进行插值
>
> 对于介于上述两种情况之间的维度，使用一个映射策略：
>
> $$g(m)=m$$
>
> $$h\left(\theta_d\right)=(1-\gamma(r(d))) \frac{\theta_d}{s}+\gamma(r(d)) \theta_d$$
>
> 其中引入了一个 ramp 函数 $$\gamma(r)$$ 来确定插值程度：
>
> $$\gamma(r)= \begin{cases}0 & \text { if } \quad r(d)<\alpha \\ 1 & \text { if } \quad r(d) \geq \beta \\ \frac{r-\alpha}{\beta-\alpha} & \text { otherwise }\end{cases}$$
>
> > 参数 $$\alpha 、 \beta$$ 取值逻辑可以参考Qwen3：α=1 和 β=32。

### 1.2 dynamic NTK（根据 seq\_len 改变旋转角）

> 之前的NTK-aware方法使用的是固定的扩展比 $$s$$：
>
> $$s=\frac{L^{\prime}}{L}$$
>
> 但是事实上，扩展上下文长度 $$L^{\prime}$$ 应该是动态变化的，因此我们使用映射：
>
> $$g(m)=m$$
>
> $$h\left(\theta_d\right)= [b(\alpha\cdot s-\alpha+1)]^{-2 d /|D|}$$
>
> 其中$$\alpha$$为超参数。

### 1.3 YaRN（放缩Q\K）

> <span style="color: rgb(216,57,49); background-color: inherit">当使用插值去调整</span>$$Q,K$$<span style="color: rgb(216,57,49); background-color: inherit">后，注意力里的点积</span>$$Q\cdot K$$<span style="color: rgb(216,57,49); background-color: inherit">会系统性变大，导致 softmax 更尖锐</span>，从而降低Attention的性能表现，因此，Yarn在 NTK-by-parts 基础上，引入注意力温度因子$$t$$ 来调整注意力分布：
>
> $$\operatorname{softmax}\left(\frac{\mathbf{q}_m^{\top} \mathbf{k}_n}{t \sqrt{|D|}}\right)$$
>
> 对于LLaMA和Llama 2模型，使用以下方式计算 $$\sqrt{\frac{1}{t}}$$ ：
>
> $$\sqrt{\frac{1}{t}}=0.1 \ln (s)+1$$
>
> 其中 $$s$$ 是扩展比，为扩展上下文长度 $$L^{\prime}$$ 与原始上下文长度 $$L$$ 之间的比率：$$s=\frac{L^{\prime}}{L}$$



## 2. Qwen3 的 YaRN 代码是怎么实现的？

我们选取[Qwen3-8B](https://huggingface.co/Qwen/Qwen3-8B/discussions/17)，首先参考技术报告可以看到支持的上下文长度是128K，**<span style="color: rgb(216,57,49); background-color: inherit">这是经过 YaRN 拓展得到的长度</span>**：

![](<images/从 Qwen3 源码学习 YaRN 代码实现-截屏2026-01-17 20.49.22.png>)

的原始训练长度是 32K，拓展因子是4，因此可以拓展到32K\*4=128K的上下文：

```json
{    
    ...,    
    "max_position_embeddings": 131072,    
    "rope_scaling": {        
        "rope_type": "yarn",        
        "factor": 4.0,        
        "original_max_position_embeddings": 32768    
    }
}
```

查看[模型架构源码](https://github.com/huggingface/transformers/blob/main/src/transformers/models/qwen3/modeling_qwen3.py#L40)，可以看到应用 YaRN 的模式分为两步：

* 应用`rope_init_fn`计算`inv_freq` （`dim//2`的旋转角）和`self.attention_scaling`（$$\sqrt{1/t}$$）

* cos\sin 分别乘上`self.attention_scaling`

```python
# Line 85
class Qwen3RotaryEmbedding(nn.Module):
    inv_freq: torch.Tensor  # fix linting for `register_buffer`

    def __init__(self, config: Qwen3Config, device=None):
        super().__init__()
        self.max_seq_len_cached = config.max_position_embeddings
        self.original_max_seq_len = config.max_position_embeddings

        self.config = config

        self.rope_type = self.config.rope_parameters["rope_type"]
        rope_init_fn: Callable = self.compute_default_rope_parameters
        if self.rope_type != "default":
            rope_init_fn = ROPE_INIT_FUNCTIONS[self.rope_type]
        inv_freq, self.attention_scaling = rope_init_fn(self.config, device)

        self.register_buffer("inv_freq", inv_freq, persistent=False)
        self.register_buffer("original_inv_freq", inv_freq.clone(), persistent=False)

    @staticmethod
    def compute_default_rope_parameters(
        config: Qwen3Config | None = None,
        device: Optional["torch.device"] = None,
        seq_len: int | None = None,
    ) -> tuple["torch.Tensor", float]:
        ...
    @torch.no_grad()
    @dynamic_rope_update  # power user: used with advanced RoPE types (e.g. dynamic rope)
    def forward(self, x, position_ids):
        inv_freq_expanded = self.inv_freq[None, :, None].float().expand(position_ids.shape[0], -1, 1).to(x.device)
        position_ids_expanded = position_ids[:, None, :].float()
        device_type = x.device.type if isinstance(x.device.type, str) and x.device.type != "mps" else "cpu"
        with maybe_autocast(device_type=device_type, enabled=False):  # Force float32
            freqs = (inv_freq_expanded.float() @ position_ids_expanded.float()).transpose(1, 2)
            emb = torch.cat((freqs, freqs), dim=-1)
            cos = emb.cos() * self.attention_scaling
            sin = emb.sin() * self.attention_scaling
        return cos.to(dtype=x.dtype), sin.to(dtype=x.dtype)
```

**<span style="color: rgb(216,57,49); background-color: inherit">先来解释第二步，</span>**&#x4E3A;什么`self.attention_scaling`乘在cos\sin上可以应用RoPE需要明白RoPE的应用方式：

```python
@use_kernel_func_from_hub("rotary_pos_emb")
def apply_rotary_pos_emb(q, k, cos, sin, unsqueeze_dim=1):
    """Applies Rotary Position Embedding to the query and key tensors.

    Args:
        q (`torch.Tensor`): The query tensor.
        k (`torch.Tensor`): The key tensor.
        cos (`torch.Tensor`): The cosine part of the rotary embedding.
        sin (`torch.Tensor`): The sine part of the rotary embedding.
        unsqueeze_dim (`int`, *optional*, defaults to 1):
            The 'unsqueeze_dim' argument specifies the dimension along which to unsqueeze cos[position_ids] and
            sin[position_ids] so that they can be properly broadcasted to the dimensions of q and k. For example, note
            that cos[position_ids] and sin[position_ids] have the shape [batch_size, seq_len, head_dim]. Then, if q and
            k have the shape [batch_size, heads, seq_len, head_dim], then setting unsqueeze_dim=1 makes
            cos[position_ids] and sin[position_ids] broadcastable to the shapes of q and k. Similarly, if q and k have
            the shape [batch_size, seq_len, heads, head_dim], then set unsqueeze_dim=2.
    Returns:
        `tuple(torch.Tensor)` comprising of the query and key tensors rotated using the Rotary Position Embedding.
    """
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed
```

即设带YaRN策略的RoPE函数为$$\operatorname{RoPE}_t(\mathbf{x})$$，标准RoPE为$$\operatorname{RoPE}(\mathbf{x})$$，则有：

$$\operatorname{RoPE}_t(\mathbf{x}) =\big(\mathbf{x}\odot(\sqrt{1/t}\cos)\big)+\big(\operatorname{rot}(\mathbf{x})\odot(\sqrt{1/t}\sin)\big) =\sqrt{1/t}\operatorname{RoPE}(\mathbf{x}),$$

因此在 scaled dot-product attention 中：

$$\operatorname{softmax}_n\left(\frac{\operatorname{RoPE}_t(\mathbf{q}_m)^\top \operatorname{RoPE}_t(\mathbf{k}_n)}{\sqrt{|D|}}\right) =\operatorname{softmax}_n\left(\frac{\big(\sqrt{1/t},\operatorname{RoPE}(\mathbf{q}_m)\big)^\top \big(\sqrt{1/t},\operatorname{RoPE}(\mathbf{k}_n)\big)}{\sqrt{|D|}}\right) =\operatorname{softmax}_n\left(\frac{\mathbf{q}_m^\top \mathbf{k}_n}{t\sqrt{|D|}}\right).$$

**<span style="color: rgb(216,57,49); background-color: inherit">现在再来解释第一步，</span>**&#x67E5;看[util文件](https://github.com/huggingface/transformers/blob/main/src/transformers/modeling_rope_utils.py)中的函数映射关系，发现实际上生效的`rope_init_fn`&#x662F;**`_compute_yarn_parameters`**：

```python
# This maps the "rope_type" string field in rope config to the corresponding function to compute the RoPE parameters
# from the model config. You can append new {'rope_type': callable} pairs to this rope_parameters to enable custom RoPE
# parameterizations, as long as the callable has the same signature.
ROPE_INIT_FUNCTIONS = {
    "linear": _compute_linear_scaling_rope_parameters,
    "dynamic": _compute_dynamic_ntk_parameters,
    "yarn": _compute_yarn_parameters,
    "longrope": _compute_longrope_parameters,
    "llama3": _compute_llama3_parameters,}
```

查&#x770B;**`_compute_yarn_parameters`<span style="color: rgb(216,57,49); background-color: inherit"> </span>**&#x5C31;可以发现他实现了NTK-by-parts 和 YaRN 的混合策略：

```python
# Line 256
def _compute_yarn_parameters(
    config: "PreTrainedConfig",
    device: Optional["torch.device"] = None,
    seq_len: int | None = None,
    layer_type: str | None = None,
) -> tuple["torch.Tensor", float]:
    ...
    if factor is None:
        factor = config.max_position_embeddings / original_max_position_embeddings
    
    #YaRN####################################################
    # 计算 YaRN 里面的 sqrt(1/t)
    def get_mscale(scale, mscale=1):
        # 如果 scale <= 1，表示没有扩展（或缩短），那就不需要额外缩放
        if scale <= 1:
            return 1.0
        # 论文/经验公式：attention_scale = 0.1 * mscale * log(scale) + 1
        # scale 越大，attention_factor 越大（但增长是 log 的，比较平滑）
        return 0.1 * mscale * math.log(scale) + 1.0
    attention_factor = get_mscale(factor)
    ######################################################


    #NTK-by-parts####################################################
    # NTK-by-parts中的 beta、 alpha  
    beta_fast = rope_parameters_dict.get("beta_fast") or 32
    beta_slow = rope_parameters_dict.get("beta_slow") or 1

    def find_correction_dim(num_rotations, dim, base, max_position_embeddings):
        # 计算NTK-by-parts中的 r(d)
        return (dim * math.log(max_position_embeddings / (num_rotations * 2 * math.pi))) / (2 * math.log(base))

    def find_correction_range(low_rot, high_rot, dim, base, max_position_embeddings, truncate):
        # 计算NTK-by-parts中的应用维度
        low = find_correction_dim(low_rot, dim, base, max_position_embeddings)
        high = find_correction_dim(high_rot, dim, base, max_position_embeddings)
        if truncate:
            low = math.floor(low)
            high = math.ceil(high)
        return max(low, 0), min(high, dim - 1)

    def linear_ramp_factor(min, max, dim):
        if min == max:
            max += 0.001  # 防止除零
        linear_func = (torch.arange(dim, dtype=torch.float32) - min) / (max - min)
        # clamp
        ramp_func = torch.clamp(linear_func, 0, 1)
        return ramp_func

    # 经典 RoPE 的 pos_freqs
    pos_freqs = base ** (torch.arange(0, dim, 2).to(device=device, dtype=torch.float) / dim)

    # 经典 RoPE 的 inv_freq，对应 \theta_d 项
    inv_freq_extrapolation = 1.0 / pos_freqs

    # 插值用的 inv_freq，对应 \theta_d/s 项
    inv_freq_interpolation = 1.0 / (factor * pos_freqs)

    truncate = config.rope_parameters.get("truncate", True)
    # low/high：在哪些频率维度范围内进行“从外推过渡到插值”或反过来
    low, high = find_correction_range(
        beta_fast, beta_slow, dim, base, original_max_position_embeddings, truncate
    )

    # 对应 NTK by parts 的分段函数，用 1 - ramp 得到 inv_freq_extrapolation_factor：
    #   - 在高频区（索引 < low） => extrapolation_factor=1（更偏外推）
    #   - 在低频区（索引 > high）=> extrapolation_factor=0（更偏插值）
    #   - 中间线性过渡
    inv_freq_extrapolation_factor = 1 - linear_ramp_factor(low, high, dim // 2).to(
        device=device, dtype=torch.float
    )

    # 最终 inv_freq 是两者的加权和：
    #   inv_freq = interpolation * (1 - inv_freq_extrapolation_factor) + extrapolation * inv_freq_extrapolation_factor
    inv_freq = (
        inv_freq_interpolation * (1 - inv_freq_extrapolation_factor)
        + inv_freq_extrapolation * inv_freq_extrapolation_factor
    )
    ######################################################
    return inv_freq, attention_factor
```

完整`_compute_yarn_parameters`实现：

```python
# Line 256
def _compute_yarn_parameters(
    config: "PreTrainedConfig",
    device: Optional["torch.device"] = None,
    seq_len: int | None = None,
    layer_type: str | None = None,
) -> tuple["torch.Tensor", float]:
    """
    目标：计算 YaRN (NTK scaling 变体) 下 RoPE 的 inverse frequencies（inv_freq）
         以及一个用于后处理 cos/sin 的 attention_factor（幅度缩放因子）。

    你可以把 RoPE 想成：对每个 head 的 q/k 向量做“按维度不同频率的旋转”。
    inv_freq 决定每个旋转频率对应的角速度；attention_factor 决定最后 cos/sin 的整体缩放强度。
    """

    # -------------------------
    # 1) 兼容旧配置：统一 rope_parameters 的字段格式
    # -------------------------
    # 某些模型/老版本 transformers 可能用旧字段名或结构；
    # standardize_rope_params() 会把它整理成当前代码预期的形式。
    config.standardize_rope_params()

    # 如果 layer_type 不为空，说明 rope 参数按层/模块类型分别配置（例如不同 block 用不同 rope）；
    # 否则直接用全局 config.rope_parameters。
    rope_parameters_dict = config.rope_parameters[layer_type] if layer_type is not None else config.rope_parameters

    # -------------------------
    # 2) 取出 RoPE/YaRN 相关基础超参
    # -------------------------
    # rope_theta：RoPE 的 base（论文/实现里常写作 θ 或 base），决定频率的指数底数
    base = rope_parameters_dict["rope_theta"]

    # partial_rotary_factor：只对 head_dim 的前一部分维度应用 RoPE（有些模型这样做）
    partial_rotary_factor = rope_parameters_dict.get("partial_rotary_factor", 1.0)

    # head_dim：每个注意力 head 的维度
    # 如果 config 没提供 head_dim，就用 hidden_size // num_attention_heads 推出来
    head_dim = getattr(config, "head_dim", config.hidden_size // config.num_attention_heads)

    # dim：实际参与 RoPE 的维度（可能小于 head_dim）
    dim = int(head_dim * partial_rotary_factor)

    # factor：用于“插值扩展上下文”的缩放因子（>1 时通常表示扩展上下文长度）
    factor = rope_parameters_dict["factor"]

    # attention_factor：对最终 cos/sin 的幅度缩放；有些配置直接给，有些需要推导
    attention_factor = rope_parameters_dict.get("attention_factor")

    # mscale / mscale_all_dim：论文建议用来推 attention_factor 的两个可选超参
    mscale = rope_parameters_dict.get("mscale")
    mscale_all_dim = rope_parameters_dict.get("mscale_all_dim")

    # original_max_position_embeddings：预训练时的最大长度（用于推导“纠正范围”）
    original_max_position_embeddings = rope_parameters_dict["original_max_position_embeddings"]

    # -------------------------
    # 3) 兼容某些模型：factor 可能为 None，用 max_position_embeddings / original_max 推出来
    # -------------------------
    # 注释里提到 DeepSeek-V3：他们用“当前最大长度 / 预训练最大长度”的比例推默认缩放
    # 而不是直接写 factor。
    if factor is None:
        factor = config.max_position_embeddings / original_max_position_embeddings

    # -------------------------
    # 4) 定义 get_mscale：把 factor 映射成 attention_factor 的建议公式
    # -------------------------
    def get_mscale(scale, mscale=1):
        # 如果 scale <= 1，表示没有扩展（或缩短），那就不需要额外缩放
        if scale <= 1:
            return 1.0
        # 论文/经验公式：attention_scale = 0.1 * mscale * log(scale) + 1
        # scale 越大，attention_factor 越大（但增长是 log 的，比较平滑）
        return 0.1 * mscale * math.log(scale) + 1.0

    # -------------------------
    # 5) 如果没显式给 attention_factor，则按论文建议推导
    # -------------------------
    if attention_factor is None:
        if mscale and mscale_all_dim:
            # 如果同时给了 mscale 和 mscale_all_dim：
            # attention_factor = get_mscale(factor, mscale) / get_mscale(factor, mscale_all_dim)
            # 理解：分子分母分别用不同 mscale 产生两个“缩放”，取比值作为最终缩放
            attention_factor = float(get_mscale(factor, mscale) / get_mscale(factor, mscale_all_dim))
        else:
            # 否则就用默认 mscale=1 的版本
            attention_factor = get_mscale(factor)

    # -------------------------
    # 6) beta_fast / beta_slow：定义“纠正区间”的边界（论文建议默认 32 / 1）
    # -------------------------
    # 它们用于决定哪些频率维度使用“插值”(interpolation) vs “外推”(extrapolation)
    beta_fast = rope_parameters_dict.get("beta_fast") or 32
    beta_slow = rope_parameters_dict.get("beta_slow") or 1

    # -------------------------
    # 7) 下面开始正式计算 inv_freq（逆频率）
    # -------------------------

    def find_correction_dim(num_rotations, dim, base, max_position_embeddings):
        """
        作用：根据“在最大位置 max_position_embeddings 处旋转了 num_rotations 圈”
             反推“对应的是哪一个维度位置”。

        RoPE 的频率通常随维度指数变化：
            freq(i) ~ base^(i/dim)
        在位置 t 时的角度 ~ t * freq(i) （略去常数）
        这里的推导把“达到某个旋转圈数”的条件倒过来解 i。
        """
        return (dim * math.log(max_position_embeddings / (num_rotations * 2 * math.pi))) / (2 * math.log(base))

    def find_correction_range(low_rot, high_rot, dim, base, max_position_embeddings, truncate):
        """
        作用：用两个旋转阈值 low_rot / high_rot 推出一个维度区间 [low, high]，
             表示从哪个维度开始/结束需要做纠正（ramp 混合）。
        """
        low = find_correction_dim(low_rot, dim, base, max_position_embeddings)
        high = find_correction_dim(high_rot, dim, base, max_position_embeddings)

        # truncate=True 时，把边界取整：
        # low 向下取整、high 向上取整，让区间更“离散对齐”
        if truncate:
            low = math.floor(low)
            high = math.ceil(high)

        # 保证范围落在合法维度索引内
        return max(low, 0), min(high, dim - 1)

    def linear_ramp_factor(min, max, dim):
        """
        作用：生成一个从 0 到 1 的线性 ramp（长度为 dim），并 clamp 到 [0,1]。
             当索引 < min 时为 0；> max 时为 1；中间线性过渡。
        """
        if min == max:
            max += 0.001  # 防止除零（避免 min==max 造成奇异）

        # 线性函数：i 从 min 到 max 映射到 0..1
        linear_func = (torch.arange(dim, dtype=torch.float32) - min) / (max - min)
        # clamp 后得到 ramp
        ramp_func = torch.clamp(linear_func, 0, 1)
        return ramp_func

    # -------------------------
    # 8) “插值 vs 外推”的两套 inv_freq
    # -------------------------
    # 经典 RoPE：pos_freqs = base^(i/dim)，i 取偶数维（0,2,4,...）
    # 注意：RoPE 只需要 dim/2 个频率，因为每个频率对应一对维度 (2k,2k+1) 做二维旋转
    pos_freqs = base ** (torch.arange(0, dim, 2).to(device=device, dtype=torch.float) / dim)

    # 外推用的 inv_freq：不缩放 position（相当于 factor=1）
    inv_freq_extrapolation = 1.0 / pos_freqs

    # 插值用的 inv_freq：把频率再除以 factor（等价于把 position IDs 除以 factor）
    # 直觉：factor>1 时，同样的位置 t 会被“压缩”到 t/factor，从而支持更长上下文
    inv_freq_interpolation = 1.0 / (factor * pos_freqs)

    # -------------------------
    # 9) 计算纠正区间，并做 ramp 混合
    # -------------------------
    # truncate 配置从全局 config.rope_parameters 取（注意这里没用 rope_parameters_dict）
    # 含义：是否对纠正范围边界做取整/截断（更硬一些）
    truncate = config.rope_parameters.get("truncate", True)

    # low/high：在哪些频率维度范围内进行“从外推过渡到插值”或反过来
    low, high = find_correction_range(
        beta_fast, beta_slow, dim, base, original_max_position_embeddings, truncate
    )

    # linear_ramp_factor(low, high, dim//2) 产出一个 0->1 的 ramp
    # 这里 dim//2 对应频率个数（因为频率张量长度是 dim/2）
    #
    # 再用 1 - ramp 得到 inv_freq_extrapolation_factor：
    #   - 在低频区（索引 < low）ramp=0 => extrapolation_factor=1（更偏外推）
    #   - 在高频区（索引 > high）ramp=1 => extrapolation_factor=0（更偏插值）
    #   - 中间线性过渡
    inv_freq_extrapolation_factor = 1 - linear_ramp_factor(low, high, dim // 2).to(
        device=device, dtype=torch.float
    )

    # 最终 inv_freq 是两者的加权和：
    #   inv_freq = interpolation * (1 - w) + extrapolation * w
    # 其中 w = inv_freq_extrapolation_factor
    #
    # 直觉：低频（更长周期）更适合外推，高频（更短周期）更适合插值；
    # 用 ramp 在某个区间内平滑切换，避免突变导致训练/推理不稳定。
    inv_freq = (
        inv_freq_interpolation * (1 - inv_freq_extrapolation_factor)
        + inv_freq_extrapolation * inv_freq_extrapolation_factor
    )

    # -------------------------
    # 10) 返回：inv_freq（用于生成 cos/sin） + attention_factor（用于对 cos/sin 再缩放）
    # -------------------------
    return inv_freq, attention_factor
```



## 3. Qwen3 如何应用 YaRN？

由于大家一定是在推理框架中使用 YaRN，因此在不同推理框架也会有不同的支持，这里讲解比较常用的两个框架：

* Transformers

* vLLM

### 3.1 Transformers

Transformers 是最基础和常见的模型框架，默认是不使用上下文长度拓展的，可以通过修改模型文件或在加载模型时覆盖默认参数来启用。

* **<span style="color: rgb(216,57,49); background-color: inherit">为了适配 YaRN 需要自行修改 </span>`config.json`<span style="color: rgb(216,57,49); background-color: inherit"> 中的配置，</span>**&#x9700;要增加长[上下文配置](https://qwen.readthedocs.io/zh-cn/latest/inference/transformers.html)，添加 rope\_scaling 字段：

```json
{    
    ...,    
    "max_position_embeddings": 131072,    
    "rope_scaling": {        
        "rope_type": "yarn",        
        "factor": 4.0,        
        "original_max_position_embeddings": 32768    
    }
}
```

* 在`pipeline`&#x4E2D;**<span style="color: rgb(216,57,49); background-color: inherit">覆盖默认参数</span>**：

```python
from transformers import pipeline
model_name_or_path = "Qwen/Qwen3-8B"
generator = pipeline(
    "text-generation", 
    model_name_or_path, 
    torch_dtype="auto", 
    device_map="auto",
    model_kwargs={
        "max_position_embeddings": 131072,
        "rope_scaling": {
            "rope_type": "yarn",
            "factor": 4.0,
            "original_max_position_embeddings": 32768,
        },
    }
)
```



### 3.2 vLLM

参考[教程](https://qwen.readthedocs.io/zh-cn/latest/deployment/vllm.html)，vLLM 实现了静态 YaRN，即缩放因子都保持不变，只需要处理长上下文&#x65F6;**<span style="color: rgb(216,57,49); background-color: inherit">添加 </span>`rope_scaling`<span style="color: rgb(216,57,49); background-color: inherit"> 配置</span>**&#x5373;可实现：

```python
vllm serve Qwen/Qwen3-8B --rope-scaling '{"rope_type":"yarn","factor":4.0,"original_max_position_embeddings":32768}' --max-model-len 131072  
```
