> Qwen3支持混合推理模式（**Hybrid Thinking Modes**）。简单来说，Qwen3 模型引入双模式混合推理机制，通过“思考模式”处理复杂问题、“非思考模式”应对简单提问，实现深度与速度的兼顾。
>
> **<span style="color: rgb(216,57,49); background-color: inherit">但是Qwen3是如何控制“思考”和“非思考”的呢，我们来详细解析一下。</span>**

<span style="color: rgb(216,57,49); background-color: inherit">看</span>[<span style="color: rgb(216,57,49); background-color: inherit">Qwen3官方Blog</span>](https://qwenlm.github.io/zh/blog/qwen3/)<span style="color: rgb(216,57,49); background-color: inherit">的时候，会产生“模型支持自动对问题切换思考模式”的错觉。事实上，我们需要手动进行推理模式的切换，Qwen3支持两种混合推理的切换机制：</span>

● 硬开关机制：通过`enable_thinking`参数控制模型开启推理模式。

● 软开关机制：在`enable_thinking=True`时通过`/think`和`/no_think`指令来开启推理模式。



## 1. 硬开关机制

Qwen3可以通过指定enable\_thinking参数来控制模型是否进行思考，但是这个参数不是作用在模型架构上的，而是作用在模型的prompt处理上，类似DeepSeek R1 [ 答疑：蒸馏模型输出缺失 \<think> token](https://swfvqxo30ma.feishu.cn/wiki/WpqGwTb4ciu6g9kQhP3cUS8unOb)一样的做法：

```python
messages = [
    {"role": "user", "content": prompt}
]
text = tokenizer.apply_chat_template(
    messages,
    tokenize=False,
    add_generation_prompt=True,
    enable_thinking=True # Switches between thinking and non-thinking modes. Default is True.
)
```

具体来说，apply\_chat\_template会根据 [tokenizer\_config.json](https://huggingface.co/Qwen/Qwen3-8B/blob/main/tokenizer_config.json) 中的`"chat_template"`，来处理messages，这一部分是 jinja template 定义的，我们可以看到比较关键的一部分是：

```python
{%- if add_generation_prompt %}
    {{- '<|im_start|>assistant\n' }}
    {%- if enable_thinking is defined and enable_thinking is false %}
        {{- '<think>\n\n</think>\n\n' }}
    {%- endif %}
{%- endif %}
```

<span style="color: rgb(216,57,49); background-color: inherit">这表明当</span>`enable_thinking`<span style="color: rgb(216,57,49); background-color: inherit">是 False 时，会将 </span>`<think>\n\n</think>\n\n`<span style="color: rgb(216,57,49); background-color: inherit"> 这一段“空思考”过程 concat 到模型 prompt 中，以跳过模型的思考过程。</span>

举例来说，当`enable_thinking`是 False 时，prompt 为：

```python
<|im_start|>user
1+1=?<|im_end|>
<|im_start|>assistant
<think>

</think>



```

举例来说，当`enable_thinking`是 True 时，prompt 为：

```python
<|im_start|>user
1+1=?<|im_end|>
<|im_start|>assistant
```

前者因为有一个空思考过程，因此一定程度上不会再次生成\<think>开启思考。

**<span style="color: rgb(216,57,49); background-color: inherit">拓展思考：</span>**&#x5728;这里其实我们也可以对比DeepSeek R1强制生成第一个`<think>` token的方法（ [ 答疑：蒸馏模型输出缺失 \<think> token](https://swfvqxo30ma.feishu.cn/wiki/WpqGwTb4ciu6g9kQhP3cUS8unOb)），DeepSeek R1在一些时刻会自动跳过思考过程，但是并不是智能的根据问题难易程度进行跳过而是一个Bug。

那么现在有一个问题就是，为什么Qwen3的硬开关机制在`enable_thinking`是 True 时，不强制第一个token为`<think>` ，如下模版：

```python
<|im_start|>user
1+1=?<|im_end|>
<|im_start|>assistant
<think>
```

这其实就是为软开关机制留下空间，即在提示词或 system 消息中添加 `/think` 或 `/no_think` 来控制是否进行思考。



## 2. 软开关机制

Qwen3 提供了软切换机制，当 `enable_thinking=True` 时，用户可以动态控制模型的行为。具体来说，用户可以在提示词或 system 消息中添加 `/think` 或 `/no_think`，以在对话过程中逐轮切换模型的思考模式。在多轮对话中，模型将遵循最近的一条模式指令。

这里的 `/think` 或 `/no_think` 都不是special token，它们的编码分别是`[33100,  5854,   766]`和`[20439,   766]`。至于模型是如何通过这一段tokens学会思考模式的切换，是通过Stage 3（Thinking Mode Fusion）的思考数据、非思考数据的混合训练实现的，参考[官方博客](https://qwenlm.github.io/zh/blog/qwen3/)：

> ![](images/Qwen3的混合推理机制是怎么实现的？-post-training-1.png)
>
> 在第三阶段，我们在一份包括长思维链数据和常用的指令微调数据的组合数据上对模型进行微调，将非思考模式整合到思考模型中。确保了推理和快速响应能力的无缝结合。最后，在第四阶段，我们在包括指令遵循、格式遵循和 Agent 能力等在内的 20 多个通用领域的任务上应用了强化学习，以进一步增强模型的通用能力并纠正不良行为。

这里我们来测试下在 `enable_thinking=True` 时，通过`/no_think` 来跳过思考。

首先promt经过模版处理后为：

```python
text, <|im_start|>user
1+1=？/no_think<|im_end|>
<|im_start|>assistant
```

模型输出为：

```python
<think>

</think>

在标准的算术中，1 + 1 = 2。这是基本的加法运算，适用于整数、自然数等数系。如果是在特定的数学结构或上下文中（例如模运算、布尔代数等），结果可能会有所不同，但通常情况下，答案是2。
```

可以看到模型其实还是输出了`<think>...</think>`的格式，但是跳过了具体的思考内容。这个具体机制的实现主要是和训练相关，但是训练脚本没有开源且博客里面也没有具体说明，需要等之后的技术报告才能进一步解析。根据官方给第三方博主的宣传资料，这个机制会涉及训练策略、数据设计和损失函数几个方面的设计。
