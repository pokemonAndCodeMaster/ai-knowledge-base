> 本期带大家无痛理解 RoPE 并且从0实现一个 [ Qwen 3](https://ai.feishu.cn/wiki/Yzb0w1lKJi9EEIkeNHLcpdODnIc)的 RoPE 实现，核心知识：
>
> * **RoPE 的极简理解**
>
> * **RoPE 公式为什么和 [ Qwen 3](https://ai.feishu.cn/wiki/Yzb0w1lKJi9EEIkeNHLcpdODnIc) 的 RoPE 实现不一致？**

## 1. RoPE的原理

Transformer 中使用的自注意力机制（Self-Attention）并没有内在的顺序概念，因此需要附加一个含有位置信息的嵌入（embedding）。不同于《Attention is All You Need》中的sin/cos绝对位置编码（在模型最开始做完Input Embedding就通过加和方式进行Positional Encoding，如下图左），**<span style="color: rgb(216,57,49); background-color: inherit">RoPE通过旋转每一个Attention Block中的Query/Key 附加位置信息</span>**（如下图右）：

![原始Transformer结构](<images/RoPE代码实现和公式不一致 !？从0手撕RoPE-截屏2024-12-24 16.12.55.png>)

![MiniMax M2示例结构，RoPE在Attention Block中操作](<images/RoPE代码实现和公式不一致 !？从0手撕RoPE-minimaxm2.png>)

RoPE 的核心思想是通过在**查询向量（Query）和键向量（Key）进行点乘**之前，用一个**二维旋转变换**将它们映射到带有位置信息的空间中。但是由于查询向量（Query）和键向量（Key）本身是`head_dim`维度的，无法直接使用**二维旋转变换**，因此我们需要把`head_dim` 维拆成`head_dim//2` 个二维 pair  $$(x_1, x_2)$$，成对在二维平面做一个旋转：$$\begin{pmatrix}
x_1 \\
x_2
\end{pmatrix}
\rightarrow
\begin{pmatrix}
x_1 \cos \theta - x_2 \sin \theta \\
x_1 \sin \theta + x_2 \cos \theta
\end{pmatrix}$$，如下图所示，其中一种可能的做法就是取相邻位置的dim进行配对，比如$$(x_1,x_2)/(x_3,x_4)/(x_{2i+1},x_{2i+2})/\cdots)$$，而每一个对单独进行**二维旋转变换**：

![](<images/RoPE代码实现和公式不一致 !？从0手撕RoPE-Gemini_Generated_Image_44mvnd44mvnd44mv.png>)

这样，我们也就能理解RoPE那个看起来特别复杂的公式了，比如对于查询向量（Query），其RoPE变换可以写成：

$$\begin{gathered}
R^d=\left[\begin{array}{ccccccc}
\operatorname{cosm} \theta_0 & -\operatorname{sinm} \theta_0 & 0 & 0 & \cdots & 0 & 0 \\
\operatorname{sinm} \theta_0 & \operatorname{cosm} \theta_0 & 0 & 0 & \cdots & 0 & 0 \\
0 & 0 & \operatorname{cosm} \theta_1 & -\operatorname{sinm} \theta_1 & \cdots & 0 & 0 \\
0 & 0 & \operatorname{sinm} \theta_1 & \operatorname{cosm} \theta_1 & \cdots & 0 & 0 \\
\vdots & \vdots & \vdots & \vdots & \ddots & \vdots & \vdots \\
0 & 0 & 0 & 0 & \cdots & \operatorname{cosm} \theta_{d / 2-1} & -\operatorname{sinm} \theta_{d / 2-1} \\
0 & 0 & 0 & 0 & \cdots & \operatorname{sinm} \theta_{d / 2-1} & \operatorname{cosm} \theta_{d / 2-1}
\end{array}\right]\left[\begin{array}{c}
q_0 \\
q_1 \\
q_2 \\
q_3 \\
\vdots \\
q_{d-2} \\
q_{d-1}
\end{array}\right]
\end{gathered}$$

对于每两个配对维度，$$\theta_i=base^{-2(i-1) / d}, i \in[1,2, \ldots, d / 2]$$，为什么要有这个$$\theta$$的区别，其实是为了区分不同的配对维度，若$$\theta$$相同，就无法区别不同的维度对了。

进一步的，上述对于查询向量（Query）的RoPE变换可以写为如下形式，大家都不必进行推导，只需要记住$$(q_0,q_1)$$配对进行$$\theta_0$$二维旋转，$$(q_2,q_3)$$配对进行$$\theta_1$$二维旋转....，那么这个公式是必然成立的：

$$R_{\Theta, m}^d x=\left[\begin{array}{c}
q_0 \\
q_1 \\
q_2 \\
q_3 \\
\vdots \\
q_{d-2} \\
q_{d-1}
\end{array}\right] \otimes\left[\begin{array}{c}
\operatorname{cosm} \theta_0 \\
\operatorname{cosm} \theta_0 \\
\operatorname{cosm} \theta_1 \\
\operatorname{cosm} \theta_1 \\
\vdots \\
\operatorname{cosm} \theta_{d / 2-1} \\
\operatorname{cosm} \theta_{d / 2-1}
\end{array}\right]+\left[\begin{array}{c}
-q_1 \\
q_0 \\
-q_3 \\
q_2 \\
\vdots \\
-q_{d-1} \\
q_{d-2}
\end{array}\right] \otimes\left[\begin{array}{c}
\operatorname{sinm} \theta_0 \\
\operatorname{sinm} \theta_0 \\
\operatorname{sinm} \theta_1 \\
\operatorname{sinm} \theta_1 \\
\vdots \\
\operatorname{sinm} \theta_{d / 2-1} \\
\operatorname{sinm} \theta_{d / 2-1}
\end{array}\right]$$



## 2. RoPE 的实现和上面有区别吗？

答案是有，但是底层的原理没有变，我们慢慢道来。

首先我们参考 [ Qwen 3](https://ai.feishu.cn/wiki/Yzb0w1lKJi9EEIkeNHLcpdODnIc)的 RoPE 实现（现代LLM的RoPE实现几乎都是一致的），写了一个极简版本，大家可以自行下载，调试出真知[ rope.py](https://ai.feishu.cn/wiki/SXFowCjEoiMPWmkvaMRcVmW8nod)

在[ Qwen 3](https://ai.feishu.cn/wiki/Yzb0w1lKJi9EEIkeNHLcpdODnIc)的大模型架构中，由于每一个Attention Block都需要对Q/K进行旋转变换，而这个变换都需要一组相同的正弦/余弦向量（下面<span style="color: rgb(216,57,49); background-color: inherit">标红</span>的向量），因此会单独抽象出一个`RotaryEmbedding`类，用于计算这两个向量（下文称为sin/cos向量），计算完后直接传入每一个Attention Block复用即可：

$$R_{\Theta, m}^d q =
\begin{bmatrix}
q_0 \\
q_1 \\
\vdots \\
q_{d-1}
\end{bmatrix}
\odot
{\color{red}
\begin{bmatrix}
\cos(m\theta_0) \\
\cos(m\theta_1) \\
\vdots \\
\cos(m\theta_{d/2-1}) \\
\cos(m\theta_0) \\
\cos(m\theta_1) \\
\vdots \\
\cos(m\theta_{d/2-1})
\end{bmatrix}} +
\begin{bmatrix}
-q_{d/2} \\
-q_{d/2+1} \\
\vdots \\
-q_{d-1} \\
q_0 \\
q_1 \\
\vdots \\
q_{d/2-1}
\end{bmatrix}
\odot
{\color{red}
\begin{bmatrix}
\sin(m\theta_0) \\
\sin(m\theta_1) \\
\vdots \\
\sin(m\theta_{d/2-1}) \\
\sin(m\theta_0) \\
\sin(m\theta_1) \\
\vdots \\
\sin(m\theta_{d/2-1})
\end{bmatrix}}$$

**<span style="color: rgb(216,57,49); background-color: inherit">仔细看这个</span>[<span style="color: rgb(216,57,49); background-color: inherit"> Qwen 3</span>](https://ai.feishu.cn/wiki/Yzb0w1lKJi9EEIkeNHLcpdODnIc)<span style="color: rgb(216,57,49); background-color: inherit">的 RoPE 公式和上面的理论推导是不一样的！我们先看代码实现，再来解释这个原因！</span>**

RoPE存在**预计算sin/cos向量+RoPE应用**两个过程，我们来逐步拆解这个计算过程：

### 2.1 **预计算sin/cos向量**

* **Step 0: 基础参数配置：**

由于要计算旋转角$$\theta_i=base^{-2(i-1) / d}, i \in[1,2, \ldots, d / 2]$$以及位置索引$$m$$，需要提前定义“超参数”，主要是最大位置索引（支持的最大上下文长度）`max_position_embeddings`以及旋转角底数`rope_theta/base`：

```python
class SimpleRoPEConfig:
    # 你可以只改这几个参数就能观察到明显变化
    hidden_size: int = 64
    num_attention_heads: int = 8
    max_position_embeddings: int = 4096
    rope_theta: float = 10000.0  # RoPE base
    head_dim: Optional[int] = None  # 如果不填，就用 hidden_size // num_attention_heads
    attention_scaling: float = 1.0  # 额外缩放（vanilla Rope 是 1.0）
```

* **Step 1: 计算所有旋转角：**

根据公式$$\theta_i=base^{-2(i-1) / d}, i \in[1,2, \ldots, d / 2]$$提前计算出$$d / 2$$个旋转角：

```python
@staticmethod
def _compute_inv_freq(dim: int, base: float, device: Optional[torch.device]) -> torch.Tensor:
    # shape: [dim/2]
    half_idx = torch.arange(0, dim, 2, dtype=torch.float32, device=device)  # 0,2,4...
    inv_freq = 1.0 / (base ** (half_idx / dim))
    return inv_freq  # [dim/2]
```

计算结果为：

```python
inv_freq tensor([1.0000, 0.1000, 0.0100, 0.0010])
# 即 θ_0, θ_1, θ_2, θ_3
```

* **Step 2: 计算每一个位置pos\_id，并且和之前的角度相乘得到每一个位置、每一个维度上的角度：**

```python
# inv_freq: [D/2] -> [1, D/2, 1] -> expand 到 batch
inv_freq_expanded = self.inv_freq[None, :, None].to(device=x.device, dtype=torch.float32)
inv_freq_expanded = inv_freq_expanded.expand(position_ids.shape[0], -1, 1)  # [B, D/2, 1]

# position_ids: [B, S] -> [B, 1, S]
pos = position_ids[:, None, :].to(device=x.device, dtype=torch.float32)  # [B, 1, S]

# freqs: [B, D/2, 1] @ [B, 1, S] -> [B, D/2, S] -> transpose -> [B, S, D/2]
freqs = torch.matmul(inv_freq_expanded, pos).transpose(1, 2)  # [B, S, D/2]
```

结果为：

```python
freqs_1 tensor([[[    0.0000,     0.0000,     0.0000,     0.0000],
         [    1.0000,     0.1000,     0.0100,     0.0010],
         [    2.0000,     0.2000,     0.0200,     0.0020],
         ...,
         [ 4093.0000,   409.3000,    40.9300,     4.0930],
         [ 4094.0000,   409.4000,    40.9400,     4.0940],
         [ 4095.0000,   409.5000,    40.9500,     4.0950]]])
# 维度为 [B, S, D/2]，即从上到下是seq_len（位置m），从左到右是head_dim（隐藏维度）
# 即每一行都是 m*θ_0, m*θ_1, m*θ_2, m*θ_3
```

* **Step 3: 在head\_dim上复制一次freqs（观察原公式，每一个角度被使用了两次），并且计算sin/cos：**

```python
# emb: 把 freqs 复制拼起来得到 [B, S, D]
emb = torch.cat([freqs, freqs], dim=-1)  # [B, S, D]

# 按 x 的 dtype 返回
cos = cos.to(dtype=x.dtype)
sin = sin.to(dtype=x.dtype)
```

结果为（只看emb，sin/cos是每个位置上的正/余弦值，就不打印了）：

```python
freqs_2 tensor([[    0.0000,     0.0000,     0.0000,     0.0000,     0.0000,     0.0000, 0.0000,     0.0000],
        [    1.0000,     0.1000,     0.0100,     0.0010,     1.0000,     0.1000,
             0.0100,     0.0010],
        [    2.0000,     0.2000,     0.0200,     0.0020,     2.0000,     0.2000,
             0.0200,     0.0020],
        [    3.0000,     0.3000,     0.0300,     0.0030,     3.0000,     0.3000,
             0.0300,     0.0030],
         ...,
         [ 4093.0000,   409.3000,    40.9300,  ...,   409.3000,
             40.9300,     4.0930],
         [ 4094.0000,   409.4000,    40.9400,  ...,   409.4000,
             40.9400,     4.0940],
         [ 4095.0000,   409.5000,    40.9500,  ...,   409.5000,
             40.9500,     4.0950]]])
# 维度为 [B, S, D]，即从上到下是seq_len（位置m），从左到右是head_dim（隐藏维度）
# 即每一行都是 m*θ_0, m*θ_1, m*θ_2, m*θ_3，m*θ_0, m*θ_1, m*θ_2, m*θ_3 （复制一遍）
```



### 2.2 **RoPE应用**

既然我们已经计算了每一个位置$$m$$的sin/cos向量，现在就需要完成下面这个乘加：

$$R_{\Theta, m}^d q =
\begin{bmatrix}
q_0 \\
q_1 \\
\vdots \\
q_{d-1}
\end{bmatrix}
\odot
{\color{red}
\begin{bmatrix}
\cos(m\theta_0) \\
\cos(m\theta_1) \\
\vdots \\
\cos(m\theta_{d/2-1}) \\
\cos(m\theta_0) \\
\cos(m\theta_1) \\
\vdots \\
\cos(m\theta_{d/2-1})
\end{bmatrix}} +
\begin{bmatrix}
-q_{d/2} \\
-q_{d/2+1} \\
\vdots \\
-q_{d-1} \\
q_0 \\
q_1 \\
\vdots \\
q_{d/2-1}
\end{bmatrix}
\odot
{\color{red}
\begin{bmatrix}
\sin(m\theta_0) \\
\sin(m\theta_1) \\
\vdots \\
\sin(m\theta_{d/2-1}) \\
\sin(m\theta_0) \\
\sin(m\theta_1) \\
\vdots \\
\sin(m\theta_{d/2-1})
\end{bmatrix}}$$

我们也逐步来完成这个操作：

* **Step 1：rotate\_half 操作：**

观察上面的公式，后一乘积项的$$q$$要进行顺序调整，因此需&#x8981;**`rotate_half`操作完成这个过程：**

```python
def rotate_half(x):
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)
```

我们只看位置$$m=0$$处的$$q$$向量，其中变换可以表示为：

```python
[q_0,q_1,q_2,q_3,q_4,q_5,q_6,q_7] => [-q_4,-q_5,-q_6,-q_7,q_0,q_1,q_2,q_3]
```

* **Step 2：乘加得到最终结果：**

之后直接做乘积即可得到旋转后的$$q$$向量（完成了RoPE操作）：

```python
def apply_rotary_pos_emb(q, k, cos, sin, position_ids=None, unsqueeze_dim=1):
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed
```

### 2.3 为什么Qwen3 的实现和理论有差异？

**<span style="color: rgb(216,57,49); background-color: inherit">对比以上实现和理论会发现，这 </span>[<span style="color: rgb(216,57,49); background-color: inherit"> Qwen 3</span>](https://ai.feishu.cn/wiki/Yzb0w1lKJi9EEIkeNHLcpdODnIc)<span style="color: rgb(216,57,49); background-color: inherit">的RoPE实现和公式对不上</span>**：

$$R_{\Theta, m}^d x=\left[\begin{array}{c}
q_0 \\
q_1 \\
q_2 \\
q_3 \\
\vdots \\
q_{d-2} \\
q_{d-1}
\end{array}\right] \otimes\left[\begin{array}{c}
\operatorname{cosm} \theta_0 \\
\operatorname{cosm} \theta_0 \\
\operatorname{cosm} \theta_1 \\
\operatorname{cosm} \theta_1 \\
\vdots \\
\operatorname{cosm} \theta_{d / 2-1} \\
\operatorname{cosm} \theta_{d / 2-1}
\end{array}\right]+\left[\begin{array}{c}
-q_1 \\
q_0 \\
-q_3 \\
q_2 \\
\vdots \\
-q_{d-1} \\
q_{d-2}
\end{array}\right] \otimes\left[\begin{array}{c}
\operatorname{sinm} \theta_0 \\
\operatorname{sinm} \theta_0 \\
\operatorname{sinm} \theta_1 \\
\operatorname{sinm} \theta_1 \\
\vdots \\
\operatorname{sinm} \theta_{d / 2-1} \\
\operatorname{sinm} \theta_{d / 2-1}
\end{array}\right]$$

```python
rotate_half:[q_0,q_1,q_2,q_3,q_4,q_5,q_6,q_7] => [-q_4,-q_5,-q_6,-q_7,q_0,q_1,q_2,q_3]

cos: [cos(mθ_0),cos(mθ_1),cos(mθ_2),cos(mθ_3),cos(mθ_0),cos(mθ_1),cos(mθ_2),cos(mθ_3)]
sin: [sin(mθ_0),sin(mθ_1),sin(mθ_2),sin(mθ_3),sin(mθ_0),sin(mθ_1),sin(mθ_2),sin(mθ_3)]
```

然后这个原因可以参考下面：

![](<images/RoPE代码实现和公式不一致 !？从0手撕RoPE-截屏2024-02-28 15.30.21.png>)

翻译一下就是：从 RoPE 的数学推导看，旋转应该是对相邻维度成对进行的，例如$$\left(x_1, x_2\right),\left(x_3, x_4\right), \ldots$$

但在很多实际代码实现中（几乎全部的实现），并不是按相邻维度配对，而是：

1）先把向量一分为二

2）再把前半和后半配对旋转

3）等价于$$\left(x_1, x_{d / 2+1}\right),\left(x_2, x_{d / 2+2}\right), \ldots$$

但是其实这个不会造成什么问题。因为RoPE 中`哪两维进行配对`本质上是一个**坐标重排（permutation）问题**，
本质上维度之间是对称的，只要旋转结构一致，**相邻配对 vs 前后半配对在数学上是等价的**。<span style="color: rgb(216,57,49); background-color: inherit">而</span>`HuggingFace / FlashAttention / xFormers`<span style="color: rgb(216,57,49); background-color: inherit">使用现在的版本主要是考虑工程高效的原因。</span>

因此真正工程实现的时候的公式是：

$$R_{\Theta, m}^d q =
\begin{bmatrix}
q_0 \\
q_1 \\
\vdots \\
q_{d-1}
\end{bmatrix}
\odot
\begin{bmatrix}
\cos(m\theta_0) \\
\cos(m\theta_1) \\
\vdots \\
\cos(m\theta_{d/2-1}) \\
\cos(m\theta_0) \\
\cos(m\theta_1) \\
\vdots \\
\cos(m\theta_{d/2-1})
\end{bmatrix} +
\begin{bmatrix}
-q_{d/2} \\
-q_{d/2+1} \\
\vdots \\
-q_{d-1} \\
q_0 \\
q_1 \\
\vdots \\
q_{d/2-1}
\end{bmatrix}
\odot
\begin{bmatrix}
\sin(m\theta_0) \\
\sin(m\theta_1) \\
\vdots \\
\sin(m\theta_{d/2-1}) \\
\sin(m\theta_0) \\
\sin(m\theta_1) \\
\vdots \\
\sin(m\theta_{d/2-1})
\end{bmatrix}$$



## 3. 拓展阅读（可选）

原版 [ Qwen 3](https://ai.feishu.cn/wiki/Yzb0w1lKJi9EEIkeNHLcpdODnIc)的RoPE预计算代码：

```python
class Qwen3RotaryEmbedding(nn.Module):
    inv_freq: torch.Tensor  # fix linting for `register_buffer`

    def __init__(self, config: Qwen3Config, device=None):
        super().__init__()
        self.max_seq_len_cached = config.max_position_embeddings
        self.original_max_seq_len = config.max_position_embeddings

        self.config = config

        self.rope_type = self.config.rope_parameters["rope_type"]
        rope_init_fn: Callable = self.compute_default_rope_parameters
        if self.rope_type != "default":
            rope_init_fn = ROPE_INIT_FUNCTIONS[self.rope_type]
        inv_freq, self.attention_scaling = rope_init_fn(self.config, device)

        self.register_buffer("inv_freq", inv_freq, persistent=False)
        self.original_inv_freq = inv_freq

    @staticmethod
    def compute_default_rope_parameters(
        config: Optional[Qwen3Config] = None,
        device: Optional["torch.device"] = None,
        seq_len: Optional[int] = None,
    ) -> tuple["torch.Tensor", float]:
        """
        Computes the inverse frequencies according to the original RoPE implementation
        Args:
            config ([`~transformers.PreTrainedConfig`]):
                The model configuration.
            device (`torch.device`):
                The device to use for initialization of the inverse frequencies.
            seq_len (`int`, *optional*):
                The current sequence length. Unused for this type of RoPE.
        Returns:
            Tuple of (`torch.Tensor`, `float`), containing the inverse frequencies for the RoPE embeddings and the
            post-processing scaling factor applied to the computed cos/sin (unused in this type of RoPE).
        """
        base = config.rope_parameters["rope_theta"]
        dim = getattr(config, "head_dim", None) or config.hidden_size // config.num_attention_heads

        attention_factor = 1.0  # Unused in this type of RoPE

        # Compute the inverse frequencies
        inv_freq = 1.0 / (
            base ** (torch.arange(0, dim, 2, dtype=torch.int64).to(device=device, dtype=torch.float) / dim)
        )
        return inv_freq, attention_factor

    @torch.no_grad()
    @dynamic_rope_update  # power user: used with advanced RoPE types (e.g. dynamic rope)
    def forward(self, x, position_ids):
        inv_freq_expanded = self.inv_freq[None, :, None].float().expand(position_ids.shape[0], -1, 1).to(x.device)
        position_ids_expanded = position_ids[:, None, :].float()

        device_type = x.device.type if isinstance(x.device.type, str) and x.device.type != "mps" else "cpu"
        with maybe_autocast(device_type=device_type, enabled=False):  # Force float32
            freqs = (inv_freq_expanded.float() @ position_ids_expanded.float()).transpose(1, 2)
            emb = torch.cat((freqs, freqs), dim=-1)
            cos = emb.cos() * self.attention_scaling
            sin = emb.sin() * self.attention_scaling

        return cos.to(dtype=x.dtype), sin.to(dtype=x.dtype)
```

原版  [ Qwen 3](https://ai.feishu.cn/wiki/Yzb0w1lKJi9EEIkeNHLcpdODnIc) 的RoPE应用代码：

```python
@use_kernel_func_from_hub("rotary_pos_emb")
def apply_rotary_pos_emb(q, k, cos, sin, position_ids=None, unsqueeze_dim=1):
    """Applies Rotary Position Embedding to the query and key tensors.
    
    Args:
    q (`torch.Tensor`): The query tensor.
    k (`torch.Tensor`): The key tensor.
    cos (`torch.Tensor`): The cosine part of the rotary embedding.
    sin (`torch.Tensor`): The sine part of the rotary embedding.
    position_ids (`torch.Tensor`, *optional*):
    Deprecated and unused.
    unsqueeze_dim (`int`, *optional*, defaults to 1):
    The 'unsqueeze_dim' argument specifies the dimension along which to unsqueeze cos[position_ids] and
    sin[position_ids] so that they can be properly broadcasted to the dimensions of q and k. For example, note
    that cos[position_ids] and sin[position_ids] have the shape [batch_size, seq_len, head_dim]. Then, if q and
    k have the shape [batch_size, heads, seq_len, head_dim], then setting unsqueeze_dim=1 makes
    cos[position_ids] and sin[position_ids] broadcastable to the shapes of q and k. Similarly, if q and k have
    the shape [batch_size, seq_len, heads, head_dim], then set unsqueeze_dim=2.
    Returns:
    `tuple(torch.Tensor)` comprising of the query and key tensors rotated using the Rotary Position Embedding.
    """
    cos = cos.unsqueeze(unsqueeze_dim)
    sin = sin.unsqueeze(unsqueeze_dim)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed

def rotate_half(x):
    """Rotates half the hidden dims of the input."""
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)
```

