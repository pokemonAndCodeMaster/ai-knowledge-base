> > In the one-million-token context setting, DeepSeekV4-Pro requires only 27% of single-token inference FLOPs and 10% of KV cache compared with DeepSeek-V3.2.&#x20;
>
> DeepSeek V4 支持 1M 长上下文、以及极低的推理成本，原论文给出「1M上下文配置下，V4-Pro 单 token FLOPs 是 V3.2 的 27%、KV cache 是 V3.2 的 10%」，成为最近讨论里最容易被<span style="color: rgb(216,57,49); background-color: inherit">「转述但不验证」</span>的两个数字。这一节我们用 V3.2 / V4-Pro 各自的 Infrence 代码和论文中的全部架构参数，**<span style="color: rgb(216,57,49); background-color: inherit">拆解 DeepSeek V4 Pro 背后的 Infra 设计、KV Cache/FLOPs 计算。</span>**

![](<images/DeepSeek V4 Infra：KV Cache!FLOPs 计算-截屏2026-04-27 23.42.09-1.png>)

![](<images/DeepSeek V4 Infra：KV Cache!FLOPs 计算-截屏2026-04-27 23.42.03-1.png>)

## 1. V3.2/V4 对比 KV Cache 计算

### 1.1 DeepSeek V3.2

推荐先阅读[ DeepSeek-V3.2-EXP](https://my.feishu.cn/wiki/PLQOwFrjjiPqG7kPV9Bc4TxxnCf)、[ GLM-5](https://my.feishu.cn/wiki/KNFXwJABVitrw7kB3odcnpednXh)（第一节）

![DS V3.2 的 DSA 架构，关注红框内的K/V分支需要cache、右侧绿色Lightning本质也是MLA也需要Cache](<images/DeepSeek V4 Infra：KV Cache!FLOPs 计算-截屏2026-02-25 21.38.35.png>)

首先参考 V3.2 的 [config.json](https://huggingface.co/deepseek-ai/DeepSeek-V3.2/blob/main/config.json) 关键配置：

* `num_hidden_layers = 61`（隐藏层数）

* `kv_lora_rank = 512`（MLA 的 latent KV 维度）

* `qk_rope_head_dim = 64`（MLA 的 RoPE 部分维度）

* `index_topk = 2048`、`index_n_heads = 64`、`index_head_dim = 128`（DSA Lightning Indexer）

* `dtype = "fp8"`、`scale dtype = FP32`（精度、量化scale精度）

**然后来看 V3.2 的 MLA + DSA 的架构：**

* MLA 架构：把 K / V 共享压成 latent 向量 $$\mathbf{c}_t^{K V}$$（不持久存原始 K/V），<span style="color: rgb(216,57,49); background-color: inherit">并且由于 decoupled RoPE，需要同时缓存 </span>$$\mathbf{c}_t^{K V}$$<span style="color: rgb(216,57,49); background-color: inherit">以及 </span>$$\mathbf{k}_t^R$$<span style="color: rgb(216,57,49); background-color: inherit">。并且在多头间是共用的（参考上图）。</span>

> DeepSeek V3.2 K/V分支的公式可以表示为：
>
> $$\begin{aligned}
> \mathbf{c}_t^{K V} & =W^{D K V} \mathbf{h}_t, \\
> {\left[\mathbf{k}_{t, 1}^C ; \mathbf{k}_{t, 2}^C ; \ldots ; \mathbf{k}_{t, n_h}^C\right]=\mathbf{k}_t^C } & =W^{U K} \mathbf{c}_t^{K V}, \\
> \mathbf{k}_t^R & =\operatorname{RoPE}\left(W^{K R} \mathbf{h}_t\right), \\
> \mathbf{k}_{t, i} & =\left[\mathbf{k}_{t, i}^C;\mathbf{k}_t^R\right], \\
> {\left[\mathbf{v}_{t, 1}^C ; \mathbf{v}_{t, 2}^C ; \ldots ; \mathbf{v}_{t, n_h}^C\right]=\mathbf{v}_t^C } & =W^{U V} \mathbf{c}_t^{K V}
> \end{aligned}$$
>
> DeepSeek V3.2 K/V分支本质上做的事情：先降维得到 $$\mathbf{c}_t^{KV}$$*，再升维得到&#x20;*$$\mathbf{k}_t^C$$和 $$\mathbf{v}_t^C$$，对另外一个分支的$$W^{KR}\mathbf{h}_t$$做 RoPE，最后$$\mathbf{k}$$进行拼接，分别输出分头后的$$\mathbf{k}$$和$$\mathbf{v}$$。

* DSA 架构：DSA 在 MLA 之上叠了一层 sparse：每次 attention 前先用 Lightning Indexer 在所有 KV 上算 index score，选出 top-k=2048 个 token 进 core attention。关键点：<span style="color: rgb(216,57,49); background-color: inherit">Indexer 选出的 top-k 是「计算时只算这 2048 个」，但 KV cache 仍然要存全部 token，因为下一个 query 选谁是动态的。在多头间是共用的。</span>

每 token 每层的 cache 由三部分组成（PE-Cache 用 FP16，其余 FP8）：

| **统计项**                                   | 形状                 | FP32 scale                 | 字节数                    |
| ----------------------------------------- | ------------------ | -------------------------- | ---------------------- |
| **MLA KV-Cache ($$\mathbf{c}_t^{K V}$$)** | `[L, 61, 512]` FP8 | `(512/128) × 4 = 16` bytes | `512` bytes + 16 bytes |
| **MLA PE-Cache ($$\mathbf{k}_t^R$$)**     | `[L, 61, 64]` FP16 | None                       | `64 × 2 = 128` bytes   |
| **DSA Indexer Cache**                     | `[L, 61, 128]` FP8 | `(128/128) × 4 = 4` bytes  | `128` bytes + 4 bytes  |

单层单 token 合计 `528 + 128 + 132 = 788` bytes。

61 层全模型每 token：`61 × 788 = 48068 bytes`。

**<span style="color: rgb(216,57,49); background-color: inherit">因此最终可以得到</span>** $$\mathrm{KV}_{\mathrm{V3.2}}(L) = 48068 \cdot L \text{ bytes}$$



### 1.2 DeepSeek V4 Pro

> 推荐先阅读 [ DeepSeek-V4 架构：技术报告/源码解析](https://scnajei2ds6y.feishu.cn/wiki/WnflwmRGAihi7Qkj0qLcwZLWnIj)

![DeepSeek-V4 KV 缓存布局示意图｜KV 缓存由两个主要部分组成：用于 CSA/HCA 的传统 KV 缓存，以及用于 SWA 和 CSA/HCA 中尚未准备好压缩的 token 的state cache。](<images/DeepSeek V4 Infra：KV Cache!FLOPs 计算-截屏2026-04-27 23.42.45.png>)

必须先读完 [ DeepSeek-V4 架构：技术报告/源码解析](https://scnajei2ds6y.feishu.cn/wiki/WnflwmRGAihi7Qkj0qLcwZLWnIj)了解 V4架构，然后来思考在这个架构里需要缓存什么，回顾CSA（Compressed Sparse Attention）/ HCA（Heavily Compressed Attention）压缩公式<span style="color: rgb(216,57,49); background-color: inherit">并且对应上面缓存布局</span>：

* **CSA 的 KV 压缩公式：**

$$C^a = H \cdot W^{aKV},\quad C^b = H \cdot W^{bKV}$$

$$Z^a = H \cdot W^{aZ},\quad Z^b = H \cdot W^{bZ} $$

$$[S^a;\ S^b] = \mathrm{Softmax}_{\mathrm{row}}([Z^a + B^a;\ Z^b + B^b]) $$

$$C^{\mathrm{Comp}}_i = \sum_{j=mi}^{m(i+1)-1} S^a_j \odot C^a_j + \sum_{j=m(i-1)}^{mi-1} S^b_j \odot C^b_j$$

* **HCA 的压缩公式复用了 CSA，去掉了 a/b 双通道：**

$$C = H \cdot W^{KV},\quad Z = H \cdot W^Z,\quad S = \mathrm{Softmax}_{\mathrm{row}}(Z + B),\quad C^{\mathrm{Comp}}_i = \sum_{j=m'i}^{m'(i+1)-1} S_j \odot C_j$$

**<span style="color: rgb(216,57,49); background-color: inherit">读这几条公式可以梳理出除了 Indexer 之外「每层每 request 的 cache 应该存什么」：</span>**

* **Compressed entry&#x20;**$$C^{Comp}$$**&#x20;要进长期 KV cache**。每 `m`（CSA）或 `m'`（HCA）个 token 算出一条压缩后的 `c = head_dim` 维的 entry，永久保留供后续 query attend。

* **Scale Z / S 是压缩瞬间的中间量，不进 cache**。每攒够 `m` 个 token 触发一次公式压缩，原始的 `Z` / `S` 立即可以丢弃。

* **State Cache 是「下一次压缩还没攒够输入」的临时 KV State**。参考 V4 论文： "all pending tokens and their associated hidden states must be retained in a buffer until the compression operation can be executed"。

参考 V4-Pro 的 [config.json](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/config.json) 获取关键参数：

* `num_hidden_layers = 61`、`head_dim = 512`、`n_heads = 128`、`num_key_value_heads = 1`（所有 query head 共享同一个 KV head，shared-KV MQA 是底层配置）

* `window_size = 128`（SWA 分支）

* `index_topk = 1024`、`index_n_heads = 64`、`index_head_dim = 128`（CSA 自己的 Lightning Indexer）

* `compress_ratios = [128, 128, 4, 128, 4, ..., 128, 4, 0]`，前 2 层是 HCA（128）、后续 CSA/HCA 交替（4/128），末尾的 `0` 是 MTP 层。61 个非 MTP 层中，HCA 层 = 2 + 29 = 31 层（前 2 层 + 后续交替里一半），CSA 层 = 30 层。



#### 1.2.1 HCA 层 Cache 计算

![](<images/DeepSeek V4 Infra：KV Cache!FLOPs 计算-截屏2026-04-28 00.23.36.png>)

看过  [ DeepSeek-V4 架构：技术报告/源码解析](https://scnajei2ds6y.feishu.cn/wiki/WnflwmRGAihi7Qkj0qLcwZLWnIj) 应该了解了，HCA 其实是简化的非稀疏 CSA，甚至还是类复用了，因此我们先来计算 HCA 层的 Cache。首先计算 HCA 压缩后的单条 Compressed entry $$C^{Comp}$$的储存占用，有两个需要关注的细节：

* **Main KV partial RoPE 切分**：V4 使用了partial RoPE，KV entry 是 `head_dim = 512` 的单一 vector，把 RoPE 和 NoPE 合并到一起，最后 64 维做 RoPE、前 448 维做 NoPE / FP8 量化。参考[源码](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/blob/main/inference/model.py)中的`apply_rotary_emb(kv[..., -rd:], freqs_cis)`，即给最后 64 维做 RoPE 旋转、保持 BF16。把前 448 维做 FP8 量化（block 64）。

* **Main KV scale dtype = UE8M0（1 byte E8M0）**：V4-Pro 全局 scale\_dtype 设成 UE8M0。

因此每条 Compressed Main KV entry （图中单个 <span style="color: inherit; background-color: rgba(255,246,122,0.8)">Heavily Compressed KV Entries</span>）大小（其实后面的 CSA 的一条 Entry 的大小也等于 HCA 的）：

$$\text{S\_main\_entry} = \underbrace{64 \times 2}_{\text{RoPE BF16}} + \underbrace{448 \times 1}_{\text{NoPE FP8}} + \underbrace{(448/64) \times 1}_{\text{UE8M0 scale (block 64)}} = 128 + 448 + 7 = 583 \text{ bytes}$$

每个 HCA 层有三类 cache：

* **SWA KV**（图中全部 <span style="color: inherit; background-color: rgba(255,246,122,0.8)">Sliding Window KV Entries</span>）：`window_size × head_dim = 128 × 512 = 65536` bytes（这部分是 sliding window 内的未压缩 KV，简化按 FP8 算且忽略 scale，如果是 BF16 reference impl 下应是乘 2 倍）

* **HCA KV**（图中全部 <span style="color: inherit; background-color: rgba(255,246,122,0.8)">Heavily Compressed KV Entries</span>，随序列增长）：`L / m' × S_main_entry = L/128 × 583` bytes

* **HCA State Cache**（压缩 Buffer，FP32）：HCA 无 overlap，buffer 上界 = 正在累积、还没攒够 128 个 token 的中间状态 `(C, Z)` 各一份，形状 `[m', c] = [128, 512]` FP32 → `2 × 128 × 512 × 4 = 512 KB`

单层 HCA：`SWA + HCA KV Cache + State Cache = 0.5625 MB + 4.55 × L bytes`。

31 个 HCA 层总计：`31 × 0.5625 MB = 17.4375 MB` + `31 × 4.55L = 141.05L` bytes。



#### 1.2.2 CSA 层 Cache 计算

![](<images/DeepSeek V4 Infra：KV Cache!FLOPs 计算-截屏2026-04-28 00.52.27.png>)

相比 HCA，CSA 会变得复杂一些，首先是 Compressed Entry 就分为 Compressed KV Entry 和 Compressed Indexer K entry （Compressed Indexer Key），Compressed KV Entry 每一个条目的大小和 HCA 是一样的，即：

$$\text{S\_main\_entry} = \underbrace{64 \times 2}_{\text{RoPE BF16}} + \underbrace{448 \times 1}_{\text{NoPE FP8}} + \underbrace{(448/64) \times 1}_{\text{UE8M0 scale (block 64)}} = 128 + 448 + 7 = 583 \text{ bytes}$$

参考V4技术报告，每条 Compressed Indexer K entry 大小（MXFP4 + UE8M0）：

$$\text{Indexer entry} = \underbrace{128 \times 0.5}_{\text{MXFP4}} + \underbrace{(128/32) \times 1}_{\text{UE8M0 (block 32)}} = 64 + 4 = 68 \text{ bytes}$$

CSA 层的五类 cache：

* **Compressed Main KV**：每 `m=4`  token seq 压成 `583 bytes` ，单层总大小 `583/4*L bytes`

* **Compressed Indexer K**：每 `m=4`  token seq 压成 `68 bytes` ，单层总大小 `68/4 = 17 bytes`

* **SWA KV**：`64 KB`（同 HCA）

* **CSA State Cache**（FP32 Buffer）：CSA 有 overlap，每条 entry 由 `2m` 个 token 派生（前 `m` 走 `(C^a, Z^a)`，后 `m` 走 `(C^b, Z^b)`）。buffer 形状 = `[2m, 2c] = [8, 1024]` FP32，KV / Score 各一份：

  `2 × (2m × 2c × 4 byte) = 2 × (8 × 1024 × 4) = 64 KB`

* **Indexer State Cache**（FP32 Buffer）：同样的 `[2m, 2c^I] = [8, 256]` FP32，KV / Score 各一份：

  `2 × (2m × 2c^I × 4) = 2 × (8 × 256 × 4) = 16 KB`

单层 CSA：`(64 + 64 + 16) KB + (583/4 + 17) × L = 0.140625 MB + 162.75 × L bytes`。

30 个 CSA 层合计：`30 × 0.140625 = 4.21875 MB` + `30 × 162.75 = 4882.5 × L` bytes。



#### 1.2.3 CSA+HCA 层 Cache 总计

**<span style="color: rgb(216,57,49); background-color: inherit">DeepSeek V4 KV总计</span>$$\mathrm{KV}_{\mathrm{V4-Pro}}(L) = 21.65625 \text{ MB} + 5,023.55 \cdot L \text{ bytes}$$**。L 系数里 97% 来自 CSA 的 Compressed KV + Indexer KV，HCA 在 KV 上的占比很小，目标只在于长程性能保底。

**<span style="color: rgb(216,57,49); background-color: inherit">因此最终可以得到</span>** $$\mathrm{KV}_{\mathrm{V3.2}}(L) = 48068 \cdot L \text{ bytes}$$



### 1.3 1M 上下文长度下 V3.2 vs V4-Pro Cache 效率对比

| 序列长度 | V3.2        | V4-Pro     | V4-Pro / V3.2 |
| ---- | ----------- | ---------- | ------------- |
| 8K   | 375.53 MB   | 60.90 MB   | 16.22%        |
| 32K  | 1502.12 MB  | 178.65 MB  | 11.89%        |
| 128K | 6008.50 MB  | 649.62 MB  | 10.81%        |
| 256K | 12017.00 MB | 1277.58 MB | 10.63%        |
| 512K | 24034.00 MB | 2533.50 MB | 10.54%        |
| 1M   | 48068.00 MB | 5045.35 MB | 10.50%        |

可以得出几个结论：

* 1M 时 V4-Pro / V3.2 = 10.50%，与原V4论文摘要「10%」匹配。

* 短序列（8K）V4-Pro 占比反而高到 16%，因为 \~21.7 MiB 的常数项（State Cache）在短序列里占主导。**<span style="color: rgb(216,57,49); background-color: inherit">可见 CSA + HCA 的 State Cache 是固定开销，序列越短占比越大</span>**<span style="color: rgb(216,57,49); background-color: inherit">。</span>

* 32K 后 V4-Pro / V3.2 稳定在 10.5%\~11.9% 之间，256K 上下文之后基本就～10.5%，可见V4架构确实在KV储存效率上远超 V3.2 的 DSA架构。

![](<images/DeepSeek V4 Infra：KV Cache!FLOPs 计算-截屏2026-04-27 23.42.09.png>)



## 2. V3.2/V4 对比 Inference FLOPs 计算

FLOPs 这里采用估算，首先需要知道一个来自《[<u>Scaling Laws for Neural Language Models</u>](https://arxiv.org/abs/2001.08361)》的结论：`inference FLOPs ≈ 2 × N` ，`N` 是 dense model 参数量或者 MoE model 的激活量。

这个结论把 Transformer 看作若干个 `y = W x + b` 形式的线性层：

矩阵向量乘 `W x` 需要 `M × K` 次 multiply-accumulate，所以这层 forward 的 FLOPs = `2 × M × K`，而这层的参数量正好是 `M × K`，**<span style="color: rgb(216,57,49); background-color: inherit">因此对每个参数，每 token 在 forward 里贡献 ≈ 2 FLOPs</span>**（一次 mul + 一次 add）。

把所有线性层求和：`Σ 2 × params_i × N_tokens = 2 × N × N_tokens`。每 token = `2 × N`。

但是这个估计忽略了两个点：

1. **未考虑 Vocab Embedding：**&#x56;ocab Embedding 本质是 lookup table，对比下 Output LM Head 是个真正的 matmul。

2. **Attention 是序列长度主导的**：QK 的计算的 FLOPs 是 `O(L^2 × d)` 跟序列长度走，因此**必须单独算**。

<span style="color: rgb(216,57,49); background-color: inherit">因此 Inference FLOPs 可以拆成「Weight 参数相关」+「Attention 计算」两块，前者可以估计成 2 倍激活参数。</span>



### 2.1 DeepSeek V3.2

DeepSeek V3.2 总参数量 685B，每 Token 激活参数量约 37B。

Weight 参数相关 FLOPs 为 `37*2 = 74B`。

DSA 有两块 attention 计算：

* **Lightning Indexer**：在全部 `L` 个 KV 上算分数。每层 `index_n_heads × index_head_dim × L × 2 = 64 × 128 × L × 2 = 16384 × L` FLOPs。61 层共 `999424 × L` FLOPs。

* **Top-k MQA core attention**：选出 `top-k = 2048` 个 token 后做 attention。每层 `n_heads × (k_dim + v_dim) × top_k × 2 = 128 × (512+64+512) × 2048 × 2`，61 层共约 `34.8B` FLOPs。

V3.2 总计算量（估计）为：$$F_{\mathrm{V3.2}}(L) = 74 \text{B} + 999424 \cdot L + 34.8 \text{B} = 999424 \cdot L + 108.8 \text{B}$$



### 2.2 DeepSeek V4 Pro

CSA 和 HCA 都是 shared-KV MQA，主要计算量是 `n_heads × head_dim × num_kv_entries × 2`。

**HCA 层（31 层）**：每个 query attend 到 `n_win + L/m' = 128 + L/128` 个 KV entry。

* 单层：`2 × 128 × 512 × (128 + L/128) × 2 ≈ 33.55 M + 2048 L` FLOPs

* 31 层共 `1.04B + 63488 × L` FLOPs

**CSA 层（30 个）**：

* Lightning Indexer：在 `L/m = L/4` 个压缩 KV 上打分。每层 `64 × 128 × L/4 × 2 = 4096 × L`，30 层共 `122880 × L`。

* Top-k MQA：每个 query attend `n_win + top_k = 128 + 1024 = 1152` 个 entry。每层 `2 × 128 × 512 × 1152 × 2 ≈ 0.302B`，30 层共 `9.06B`。

V4-Pro 总计算量（估计）为：$$F_{\mathrm{V4-Pro}}(L) = 98 \text{B} + 1.04 \text{B} + 63{,}488 L + 122{,}880 L + 9.06 \text{B} = 186{,}368 \cdot L + 108.1 \text{B}$$



### 2.3 1M 上下文长度下 V3.2 vs V4-Pro FLOPs 对比

| 序列长度 | V3.2      | V4-Pro   | V4-Pro / V3.2 |
| ---- | --------- | -------- | ------------- |
| 8K   | 116.99 B  | 109.63 B | 93.71%        |
| 32K  | 141.55 B  | 114.21 B | 80.68%        |
| 128K | 239.80 B  | 132.53 B | 55.27%        |
| 256K | 370.79 B  | 156.96 B | 42.33%        |
| 512K | 632.79 B  | 205.81 B | 32.52%        |
| 1M   | 1156.77 B | 303.52 B | 26.24%        |

* 1M 时 V4-Pro / V3.2 ≈ 26.24%，对应论文摘要的「27%」。

* **FLOPs 改进比低于 KV cache**：1M 时 KV cache 是 V3.2 的 10.50%，FLOPs 是 26.24%。因为 V4-Pro 用了更大激活参数（49B vs 37B），抵消了 attention 改进的收益。

* **CSA Indexer 是 V4 attention 节约的最大单一来源**：V3.2 Indexer 在原始 `L` 上算，V4 Indexer 在压缩后 `L/4` 上算，单这个改进就把 attention 计算的主导项压到了原来的 1/8。

![](<images/DeepSeek V4 Infra：KV Cache!FLOPs 计算-截屏2026-04-27 23.42.03.png>)

