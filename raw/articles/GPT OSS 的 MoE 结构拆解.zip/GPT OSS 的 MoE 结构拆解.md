> <span style="color: rgb(143,149,158); background-color: inherit">本节解析最近OpenAI开源的GPT OSS模型的MoE结构🌹</span>
>
> 现在MoE结构已经成为各家文本大模型的标配，那么OSS的MoE和最近的[ GLM-4.5](https://swfvqxo30ma.feishu.cn/wiki/FDScweKlXiSXWXkSGzRcAnlenpg?from=from_copylink)、[ Kimi K2](https://swfvqxo30ma.feishu.cn/wiki/PF7gwXTB6iROFIkCpvgccjwInoW?from=from_copylink)有什么区别和联系？
>
> 本篇逐步去拆解这个MoE网络，主&#x8981;**<span style="color: rgb(216,57,49); background-color: inherit">解答以下三个问题：</span>**
>
> * <span style="color: rgb(216,57,49); background-color: inherit">TopK Router 是怎么进行 token-level 的路由的，策略是什么？</span>
>
> * <span style="color: rgb(216,57,49); background-color: inherit">Expert 网络的结构是什么样的？</span>
>
> * <span style="color: rgb(216,57,49); background-color: inherit">MoE 网络训练时候 怎么实现 Loss 平衡？</span>

![](<images/GPT OSS 的 MoE 结构拆解-gpt.png>)

首先我们从`GptOssDecoderLayer`中找到MLP：

```python
class GptOssDecoderLayer(GradientCheckpointingLayer):
    def __init__(self, config: GptOssConfig, layer_idx: int):
        super().__init__()
        self.hidden_size = config.hidden_size
        self.self_attn = GptOssAttention(config=config, layer_idx=layer_idx)
        self.mlp = GptOssMLP(config)
        self.input_layernorm = GptOssRMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.post_attention_layernorm = GptOssRMSNorm(config.hidden_size, eps=config.rms_norm_eps)
        self.attention_type = config.layer_types[layer_idx]

    def forward(
        ...
    ) -> tuple[torch.Tensor]:
        residual = hidden_states
        hidden_states = self.input_layernorm(hidden_states)
        # Self Attention
        hidden_states, _ = self.self_attn(
            hidden_states=hidden_states,
            ...
        )
        hidden_states = residual + hidden_states

        # Fully Connected
        residual = hidden_states
        hidden_states = self.post_attention_layernorm(hidden_states)
        hidden_states, _ = self.mlp(hidden_states)  # diff with llama: router scores
        hidden_states = residual + hidden_states
        return hidden_states
```

然后我们定位&#x5230;**`GptOssMLP`**&#x7C7B;，可以看到这个MoE网络是十分简洁的，最近的大模型如[ GLM-4.5](https://swfvqxo30ma.feishu.cn/wiki/FDScweKlXiSXWXkSGzRcAnlenpg?from=from_copylink)、[ Kimi K2](https://swfvqxo30ma.feishu.cn/wiki/PF7gwXTB6iROFIkCpvgccjwInoW?from=from_copylink)都会使用 `first_k_dense`的网络结构，即前k层MLP是dense网络，>k的深层才使用MoE网络。

而[ GPT oss Preview版](https://swfvqxo30ma.feishu.cn/wiki/LirwwP0AZiAfoIkaKKrcio4Cncd?from=from_copylink)使用的是统一的MoE网络：

```python
class GptOssMLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.router = GptOssTopKRouter(config)
        self.experts = GptOssExperts(config)

    def forward(self, hidden_states):
        router_scores, router_indices = self.router(hidden_states)  # (num_experts, seq_len)
        routed_out = self.experts(hidden_states, router_indices=router_indices, routing_weights=router_scores)
        return routed_out, router_scores
```

![GLM4.5架构](<images/GPT OSS 的 MoE 结构拆解-GLM4p5.png>)

那么我们逐步去拆解这个MoE网络，主&#x8981;**<span style="color: rgb(216,57,49); background-color: inherit">解答以下三个问题：</span>**

* <span style="color: rgb(216,57,49); background-color: inherit">TopK Router 是怎么进行 token-level 的路由的，策略是什么？</span>

* <span style="color: rgb(216,57,49); background-color: inherit">Expert 网络的结构是什么样的？</span>

* <span style="color: rgb(216,57,49); background-color: inherit">MoE 网络训练时候 怎么实现 Loss 平衡？</span>

下面就逐步深入代码，OpenAI不发Technical Report，我们自己研究！

## 1. TopK Router 是怎么进行 token-level 的路由的，策略是什么？

这个路由十分简洁，本质就是一个带有Bias的Linear层：<span style="color: rgb(216,57,49); background-color: inherit">将每个token的hidden_dim映射到num_experts维度，并且取top-K的logits对应的expert，logits通过softmax构成权重，最终加权对应expert输出：</span>

![](<images/GPT OSS 的 MoE 结构拆解-MLP.png>)

完整`GptOssTopKRouter`代码参考：

```python
class GptOssTopKRouter(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.top_k       = config.num_experts_per_tok   # 每个 token 选中的专家数 k
        self.num_experts = config.num_local_experts     # 专家总数 N
        self.hidden_dim  = config.hidden_size           # 隐层维度 D

        # 路由器权重：W \in [N, D]
        self.weight = nn.Parameter(torch.empty(self.num_experts, self.hidden_dim))
        self.bias   = nn.Parameter(torch.empty(self.num_experts))

    def forward(self, hidden_states):
        # hidden_states 原形状: (batch, seq_len, D)
        hidden_states = hidden_states.reshape(-1, self.hidden_dim)            # -> (tokens, D)，tokens = batch*seq_len
        # 全连接: logits = x·Wᵀ + b
        router_logits = F.linear(hidden_states, self.weight, self.bias)       # (tokens, N)
        # 取 expert 维上的 top-k
        router_top_value, router_indices = torch.topk(                       
            router_logits, self.top_k, dim=-1)                                # (tokens, k), (tokens, k)
        # 只对 top-k 做 softmax 得到概率
        router_top_value = F.softmax(router_top_value, dim=1,                 
                                     dtype=router_top_value.dtype)            # (tokens, k)，行和=1
        # 把概率写回到 N 维度的稀疏向量
        router_scores = torch.zeros_like(router_logits)                       # (tokens, N) 全 0
        router_scores.scatter_(1, router_indices, router_top_value)           # 把 k 个概率填进对应列
        return router_scores, router_indices                                   # (tokens, N), (tokens, k)
```



## 2. Expert 网络的结构是什么样的？

Expert 网络是一个SiGLU（sigmoid激活）网络，在实现上，有两点需要注意的：

1）Expert并不是单独实现的，<span style="color: rgb(216,57,49); background-color: inherit">所有Expert权重是一个整体</span>，Expert只是体现在参数矩阵的一个维度上，参考`self.gate_up_proj`：

```python
class GptOssExperts(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.intermediate_size = config.intermediate_size
        self.num_experts = config.num_local_experts
        self.hidden_size = config.hidden_size
        self.expert_dim = self.intermediate_size
        self.gate_up_proj = nn.Parameter(torch.empty(self.num_experts, self.hidden_size, 2 * self.expert_dim))
        self.gate_up_proj_bias = nn.Parameter(torch.empty(self.num_experts, 2 * self.expert_dim))
        self.down_proj = nn.Parameter(torch.empty((self.num_experts, self.expert_dim, self.hidden_size)))
        self.down_proj_bias = nn.Parameter(torch.empty(self.num_experts, self.hidden_size))
        self.alpha = 1.702
        self.limit = 7.0
```

2）为平衡显存消耗，Expert计算过程对训练和推理进行了分类：

* 训练时为了降低显存开销，<span style="color: rgb(216,57,49); background-color: inherit">逐 expert 处理</span>，累加被命中的 token 的激活。

* 推理时显存压力可接受，直接把输入复制 `E` 份，牺牲显存进行<span style="color: rgb(216,57,49); background-color: inherit">并行计算</span>。

训练时的MoE网络可以看到是遍历expert，对结果进行累加：

```python
 if self.training:
    next_states = torch.zeros_like(hidden_states) # 占位输出，用来累积所有 token 的输出
    with torch.no_grad():
        # 1) # one-hot(router_indices) -> (N, top_k, E) —> 置换成 (E, top_k, N)
        expert_mask = torch.nn.functional.one_hot(
            router_indices, num_classes=num_experts
        ).permute(2, 1, 0) 

        # 对 top_k 和 N 维度求和，>0 的 expert 表示被命中
        expert_hitted = torch.greater(
            expert_mask.sum(dim=(-1, -2)), 0
        ).nonzero()      

    # ------- 按 expert 分批计算，以节省显存 ------- #
    for expert_idx in expert_hitted:
        e = expert_idx[0]

        # 找到属于该 expert 的 token 下标 token_idx
        with torch.no_grad():
            _, token_idx = torch.where(expert_mask[e])      # token_idx : (Nt,)

        current_state = hidden_states[token_idx]
        gate_up = current_state @ self.gate_up_proj[e] + self.gate_up_proj_bias[e]

        # 拆分 GLU：偶数位置 gate，奇数位置 up
        gate, up = gate_up[..., ::2], gate_up[..., 1::2]

        # clamp 限制数值范围
        gate = gate.clamp(max=self.limit)           # [0, limit]
        up   = up.clamp(min=-self.limit, max=self.limit)
        glu  = gate * torch.sigmoid(self.alpha * gate)
        gated_output = (up + 1) * glu               # (Nt, D)

        # (Nt, D) @ (D, H) → (Nt, H)
        out = gated_output @ self.down_proj[e] + self.down_proj_bias[e]

        # --------- 加权聚合到对应 token -------- #
        # routing_weights[token_idx, e] : (Nt,)
        weighted_output = out * routing_weights[token_idx, e].unsqueeze(-1)  # (Nt, H)

        next_states.index_add_(0, token_idx, weighted_output.to(hidden_states.dtype))

    # 恢复成 (B, L, H)
    next_states = next_states.view(batch_size, -1, self.hidden_size)
```

推理侧代码因为不需要遍历expert，因此会更简洁：

```python
num_experts = routing_weights.shape[1]

# 把输入复制 E 份，然后 reshape 成 (E, N, d_model)
hidden_states = hidden_states.repeat(num_experts, 1)
hidden_states = hidden_states.view(num_experts, -1, self.hidden_size)

# batched matmul：(E, N, d_model) @ (E, d_model, 2*d_ff)
gate_up = torch.bmm(hidden_states, self.gate_up_proj) + \
          self.gate_up_proj_bias[..., None, :]         # → (E, N, 2*d_ff)

gate, up = gate_up[..., ::2], gate_up[..., 1::2]
gate = gate.clamp(max=self.limit)
up   = up  .clamp(min=-self.limit, max=self.limit)

glu = gate * torch.sigmoid(gate * self.alpha)          # (E, N, d_ff)
next_states = torch.bmm((up + 1) * glu, self.down_proj) # (E, N, d_model)
next_states = next_states + self.down_proj_bias[..., None, :]

# 乘以 Router 权重
next_states = next_states.view(num_experts, batch_size, -1, self.hidden_size)
next_states = next_states * \
              routing_weights.transpose(0, 1).view(num_experts,
                                                   batch_size, -1)[..., None]
# 所有 expert 的求和
next_states = next_states.sum(dim=0)   # (B, S, d_model)
```

完整代码参考：

```python
class GptOssExperts(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.intermediate_size = config.intermediate_size
        self.num_experts = config.num_local_experts
        self.hidden_size = config.hidden_size
        self.expert_dim = self.intermediate_size
        self.gate_up_proj = nn.Parameter(torch.empty(self.num_experts, self.hidden_size, 2 * self.expert_dim))
        self.gate_up_proj_bias = nn.Parameter(torch.empty(self.num_experts, 2 * self.expert_dim))
        self.down_proj = nn.Parameter(torch.empty((self.num_experts, self.expert_dim, self.hidden_size)))
        self.down_proj_bias = nn.Parameter(torch.empty(self.num_experts, self.hidden_size))
        self.alpha = 1.702
        self.limit = 7.0

    def forward(self, hidden_states: torch.Tensor, router_indices=None, routing_weights=None) -> torch.Tensor:
        """
        When training is is more efficient to just loop over the experts and compute the output for each expert
        as otherwise the memory would explode.

        For inference we can sacrifice some memory and compute the output for all experts at once. By repeating the inputs.

        Args:
            hidden_states (torch.Tensor): (batch_size, seq_len, hidden_size)
            selected_experts (torch.Tensor): (batch_size * token_num, top_k)
            routing_weights (torch.Tensor): (batch_size * token_num, num_experts)
        Returns:
            torch.Tensor
        """
        batch_size = hidden_states.shape[0]
        hidden_states = hidden_states.reshape(-1, self.hidden_size)  # (num_tokens, hidden_size)
        num_experts = routing_weights.shape[1]
        if self.training:
            next_states = torch.zeros_like(hidden_states, dtype=hidden_states.dtype, device=hidden_states.device)
            with torch.no_grad():
                expert_mask = torch.nn.functional.one_hot(router_indices, num_classes=num_experts)
                expert_mask = expert_mask.permute(2, 1, 0)
                # we sum on the top_k and on the sequence lenght to get which experts
                # are hit this time around
                expert_hitted = torch.greater(expert_mask.sum(dim=(-1, -2)), 0).nonzero()
            for expert_idx in expert_hitted[:]:
                with torch.no_grad():
                    _, token_idx = torch.where(expert_mask[expert_idx[0]])
                current_state = hidden_states[token_idx]
                gate_up = current_state @ self.gate_up_proj[expert_idx] + self.gate_up_proj_bias[expert_idx]
                gate, up = gate_up[..., ::2], gate_up[..., 1::2]
                gate = gate.clamp(min=None, max=self.limit)
                up = up.clamp(min=-self.limit, max=self.limit)
                glu = gate * torch.sigmoid(gate * self.alpha)
                gated_output = (up + 1) * glu
                out = gated_output @ self.down_proj[expert_idx] + self.down_proj_bias[expert_idx]
                weighted_output = out[0] * routing_weights[token_idx, expert_idx, None]
                next_states.index_add_(0, token_idx, weighted_output.to(hidden_states.dtype))
            next_states = next_states.view(batch_size, -1, self.hidden_size)
        else:
            hidden_states = hidden_states.repeat(num_experts, 1)
            hidden_states = hidden_states.view(num_experts, -1, self.hidden_size)
            gate_up = torch.bmm(hidden_states, self.gate_up_proj) + self.gate_up_proj_bias[..., None, :]
            gate, up = gate_up[..., ::2], gate_up[..., 1::2]
            gate = gate.clamp(min=None, max=self.limit)
            up = up.clamp(min=-self.limit, max=self.limit)
            glu = gate * torch.sigmoid(gate * self.alpha)
            next_states = torch.bmm(((up + 1) * glu), self.down_proj)
            next_states = next_states + self.down_proj_bias[..., None, :]
            next_states = next_states.view(num_experts, batch_size, -1, self.hidden_size)
            next_states = next_states * routing_weights.transpose(0, 1).view(num_experts, batch_size, -1)[..., None]
            next_states = next_states.sum(dim=0)
        return next_states
```



## 3. MoE 网络训练时候 怎么实现 Loss 平衡？

Loss设计这部分官方没怎么说，但是我们可以查看计算Loss代码的部分，Loss由两部分组成：

* Label 预测任务的 Cross Entropy Loss

* 平衡MoE的辅助Loss：aux\_loss

最终两者加权构成完整Loss：$$Loss = KL\_Loss+\alpha\cdot Aux\_Loss$$，其中$$\alpha$$为平衡系数。

```python
loss = None
if labels is not None:
    loss = self.loss_function(logits, labels, self.vocab_size, **kwargs)

aux_loss = None
if output_router_logits:
    aux_loss = load_balancing_loss_func(
        outputs.router_logits,
        self.num_experts,
        self.num_experts_per_tok,
        attention_mask,
    )
    if labels is not None:
        loss += self.router_aux_loss_coef * aux_loss.to(loss.device)  # make sure to reside in the same device

```

* 平衡MoE的辅助Loss直接参考的是Switch Transformer的设计：

即在每个 MoE 层加入如下辅助损失：

$$\mathcal{L}_{\text{load}}
  \;=\;
  \alpha \, N \sum_{i=1}^{N} f_i \, P_i$$

* $$N$$ — 专家总数 &#x20;

* $$\alpha$$ — 缩放系数

* $$f_i$$ — 第 $$i$$ 个专家实际接收到的 **Token 比例** &#x20;

* $$P_i$$ — 路由器为第 $$i$$ 个专家分配的 **概率** &#x20;

其中，

$$f_i \;=\;
\frac{1}{T}\sum_{x\in\mathcal{B}}
\mathbf{1}\!\bigl\{\arg\max p(x)=i\bigr\},$$

$$\mathcal{B}$$ 表示当前批次，共 $$T$$ 个 token；$$p(x)$$ 为路由器 softmax 输出。

$$P_i \;=\;
\frac{1}{T}\sum_{x\in\mathcal{B}} p_i(x),$$

即第 $$i$$ 个专家在整批样本中获得的平均概率份额。

<span style="color: rgb(216,57,49); background-color: inherit">就是说，当两组向量 </span>$$\{f_i\}$$<span style="color: rgb(216,57,49); background-color: inherit"> 与 </span>$$\{P_i\}$$<span style="color: rgb(216,57,49); background-color: inherit"> 同时趋于均匀分布（理想值均为 </span>$$1/N$$<span style="color: rgb(216,57,49); background-color: inherit">）时，平衡Loss取得最小值。训练过程因此被鼓励把 token 均匀地路由到所有专家，防止少数专家过载。  </span>

load\_balancing\_loss\_func 完整代码参考：

```python
def load_balancing_loss_func(
    gate_logits: Union[torch.Tensor, tuple[torch.Tensor], None],
    num_experts: Optional[int] = None,
    top_k=2,
    attention_mask: Optional[torch.Tensor] = None,
) -> Union[torch.Tensor, int]:
    r"""
    Computes auxiliary load balancing loss as in Switch Transformer - implemented in Pytorch.

    See Switch Transformer (https://huggingface.co/papers/2101.03961) for more details. This function implements the loss
    function presented in equations (4) - (6) of the paper. It aims at penalizing cases where the routing between
    experts is too unbalanced.

    Args:
        gate_logits:
            Logits from the `gate`, should be a tuple of model.config.num_hidden_layers tensors of
            shape [batch_size X sequence_length, num_experts].
        num_experts:
            Number of experts
        top_k:
            The number of experts to route per-token, can be also interpreted as the `top-k` routing
            parameter.
        attention_mask (`torch.Tensor`, *optional*):
            The attention_mask used in forward function
            shape [batch_size X sequence_length] if not None.

    Returns:
        The auxiliary loss.
    """
    if gate_logits is None or not isinstance(gate_logits, tuple):
        return 0

    if isinstance(gate_logits, tuple):
        compute_device = gate_logits[0].device
        concatenated_gate_logits = torch.cat([layer_gate.to(compute_device) for layer_gate in gate_logits], dim=0)

    routing_weights = torch.nn.functional.softmax(concatenated_gate_logits, dim=-1)

    _, selected_experts = torch.topk(routing_weights, top_k, dim=-1)

    expert_mask = torch.nn.functional.one_hot(selected_experts, num_experts)

    if attention_mask is None:
        # Compute the percentage of tokens routed to each experts
        tokens_per_expert = torch.mean(expert_mask.float(), dim=0)

        # Compute the average probability of routing to these experts
        router_prob_per_expert = torch.mean(routing_weights, dim=0)
    else:
        batch_size, sequence_length = attention_mask.shape
        num_hidden_layers = concatenated_gate_logits.shape[0] // (batch_size * sequence_length)

        # Compute the mask that masks all padding tokens as 0 with the same shape of expert_mask
        expert_attention_mask = (
            attention_mask[None, :, :, None, None]
            .expand((num_hidden_layers, batch_size, sequence_length, top_k, num_experts))
            .reshape(-1, top_k, num_experts)
            .to(compute_device)
        )

        # Compute the percentage of tokens routed to each experts
        tokens_per_expert = torch.sum(expert_mask.float() * expert_attention_mask, dim=0) / torch.sum(
            expert_attention_mask, dim=0
        )

        # Compute the mask that masks all padding tokens as 0 with the same shape of tokens_per_expert
        router_per_expert_attention_mask = (
            attention_mask[None, :, :, None]
            .expand((num_hidden_layers, batch_size, sequence_length, num_experts))
            .reshape(-1, num_experts)
            .to(compute_device)
        )

        # Compute the average probability of routing to these experts
        router_prob_per_expert = torch.sum(routing_weights * router_per_expert_attention_mask, dim=0) / torch.sum(
            router_per_expert_attention_mask, dim=0
        )

    overall_loss = torch.sum(tokens_per_expert * router_prob_per_expert.unsqueeze(0))
    return overall_loss * num_experts
```

> **<span style="color: rgb(216,57,49); background-color: inherit">欢迎加入大模型学习圈：</span>[<span style="color: rgb(216,57,49); background-color: inherit"> 代码熊大模型学习圈加入指南 🧭 </span>](https://swfvqxo30ma.feishu.cn/wiki/KVKAwBOY1iMLRZko6yYcVmYYnff?from=from_copylink)**
>
> 各位宝子参考以上文档申请学习圈权限，<span style="color: rgb(216,57,49); background-color: inherit">务必填写准确</span>，方便工作人员校验。
>
> 由于学习圈功能刚刚开启，每日申请量较大，申请会在<span style="color: rgb(216,57,49); background-color: inherit">当周通过</span>，麻烦各位宝子耐心等待

